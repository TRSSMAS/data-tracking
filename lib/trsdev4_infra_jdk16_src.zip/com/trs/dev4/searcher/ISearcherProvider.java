/**
 * 
 */
package com.trs.dev4.searcher;

import java.util.Map;

/**
 * @author chuchanglin
 *
 */
public interface ISearcherProvider {
	
	/**
	 * 获取将Map转换成对应的ISearchable对象
	 * 
	 * @param objectProperties
	 * @return ISearchable的实现类
	 */
	public ISearchable buildSearchedObject(Map<String, String> objectProperties);

	/**
	 * 获取检索的table名
	 * 
	 * @return 欲查询的TRS库名
	 */
	public String getSearcherDatabase();
}
