/**
 * Created: chuchanglin@2010-2-23 上午11:30:21
 */
package com.trs.dev4.searcher;

import java.util.List;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 全文检索工具实现的接口，如lucence、TRS Server
 * @author chuchanglin
 */
public interface ISearcher {
	
	/**
	 * 进行TRS检索，并返回带分页的检索结果
	 * 
	 * @param searchFilter SearchFilter对象，含有检索条件
	 * @param searcherProvider ISearcherProvider类型对象，主要提供检索的表名，将中间产物Map还原为ISeachable对象
	 * @return 含有ISearchable对象的PagedList对象
	 */
	PagedList<ISearchable> search(SearchFilter searchFilter,ISearcherProvider searcherProvider);
	
	/**
	 * 设置命中词范围截取长度，默认为200字。需要在检索前设置。
	 * 
	 * @param iCutsize 设置范围
	 */
	void setICutsize(int iCutsize);
	
	/**
	 * 设置命中词标注的颜色。需要在检索前设置。默认为红色。
	 * 
	 * @param strHitColor 标注的颜色
	 */
	void setStrHitColor(String strHitColor);
	
	/**
	 * 设置关键字段集合，设置后这些字段将进行标注颜色和截取长度处理。如果没有关键字段，则不需要设置
	 * 
	 * @param fieldName
	 */
	void setKeywordFileds(List<String> fieldNames);
}
