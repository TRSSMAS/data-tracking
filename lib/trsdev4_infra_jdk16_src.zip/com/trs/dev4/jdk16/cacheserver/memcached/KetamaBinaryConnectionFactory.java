package com.trs.dev4.jdk16.cacheserver.memcached;

import java.util.List;

import net.spy.memcached.BinaryConnectionFactory;
import net.spy.memcached.HashAlgorithm;
import net.spy.memcached.KetamaNodeLocator;
import net.spy.memcached.MemcachedNode;
import net.spy.memcached.NodeLocator;

/**
 * Ketama的策略（多个Memcached服务点根据key的hash值分配到某个点的策略）<br>
 * 同时采用二进制的连接方式（与char型对应，由于存储的是序列号的结果，故选择二进制方式）
 * 
 */
public class KetamaBinaryConnectionFactory extends BinaryConnectionFactory {
	public KetamaBinaryConnectionFactory() {
		this(DEFAULT_OP_QUEUE_LEN, DEFAULT_READ_BUFFER_SIZE);
	}

	public KetamaBinaryConnectionFactory(int qLen, int bufSize) {
		super(qLen, bufSize, HashAlgorithm.KETAMA_HASH);
	}

	@Override
	public NodeLocator createLocator(List<MemcachedNode> nodes) {
		return new KetamaNodeLocator(nodes, getHashAlg());
	}
}
