/*
 * Created: fangxiang@Nov 11, 2010 1:46:54 PM
 */
package com.trs.dev4.jdk16.cacheserver.memcached;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;

import javax.annotation.Resource;

import net.rubyeye.xmemcached.KeyIterator;
import net.rubyeye.xmemcached.MemcachedClient;
import net.rubyeye.xmemcached.MemcachedClientBuilder;
import net.rubyeye.xmemcached.MemcachedClientStateListener;
import net.rubyeye.xmemcached.XMemcachedClientBuilder;
import net.rubyeye.xmemcached.exception.MemcachedException;
import net.rubyeye.xmemcached.impl.KetamaMemcachedSessionLocator;
import net.rubyeye.xmemcached.utils.AddrUtil;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 基于XMemcached的memcached客户端
 *
 */
public class MemcachedClientXImpl implements IMemcachedClient {

	private final static Logger logger = Logger
			.getLogger(MemcachedClientXImpl.class);
	/**
	 *
	 */
	MemcachedClient memcachedClient = null;
	/**
	 *
	 */
	@Resource(name = "memcachedClientStateListeners")
	private List<MemcachedClientStateListener> memcachedClientStateListeners = new ArrayList<MemcachedClientStateListener>();

	/**
	 *
	 */
	private String clientAddresses = "";

	/**
	 * 
	 * @param addresses
	 */
	public MemcachedClientXImpl() {
	}
	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#set(java.lang.String, int, java.lang.Object)
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public void set(String key, int expr, Object value) {
		try {
			if (memcachedClient != null) {
				boolean success = memcachedClient.set(key, expr, value);
				logger.debug("set key-value(" + key + "-" + value + ")[" + expr
						+ "] is (" + success + ")");
			} else {
				logger.error("memcachedClient == null.");
			}
		} catch (TimeoutException e) {
			logger.error(e.getMessage(), e);
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (MemcachedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#add(java.lang.String, int, java.lang.Object)
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public void add(String key, int expr, Object value) {
		try {
			if (memcachedClient != null) {
				memcachedClient.add(key, expr, value);
			} else {
				logger.error("memcachedClient == null.");
			}
		} catch (TimeoutException e) {
			logger.error(e.getMessage(), e);
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (MemcachedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#replace(java.lang.String, int, java.lang.Object)
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public void replace(String key, int expr, Object value) {
		try {
			if (memcachedClient != null) {
				memcachedClient.replace(key, expr, value);
			} else {
				logger.error("memcachedClient == null.");
			}
		} catch (TimeoutException e) {
			logger.error(e.getMessage(), e);
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (MemcachedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#delete(java.lang.String)
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public void delete(String key) {
		try {
			if (memcachedClient != null) {
				memcachedClient.deleteWithNoReply(key);
			} else {
				logger.error("memcachedClient == null.");
			}
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (MemcachedException e) {
			logger.error(e.getMessage(), e);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#get(java.lang.String)
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public Object get(String key) {
		try {
			if (memcachedClient != null) {
				return memcachedClient.get(key);
			} else {
				logger.error("memcachedClient == null.");
			}
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (MemcachedException e) {
			logger.error(e.getMessage(), e);
		} catch (TimeoutException e) {
			logger.error(e.getMessage(), e);
		}
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getStats()
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public Map<String, String> getStats(String server) {
		try {
			Map<InetSocketAddress, Map<String, String>> result = memcachedClient
					.getStats();
			for (InetSocketAddress inetSocketAddress : result.keySet()) {
				if (inetSocketAddress.equals(AddrUtil.getAddresses(server))) {
					return result.get(inetSocketAddress);
				}
			}
		} catch (MemcachedException e) {
			logger.error(e.getMessage(), e);
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (TimeoutException e) {
			logger.error(e.getMessage(), e);
		}
		return new HashMap<String, String>();
	}

	/**
	 *
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public Collection<InetSocketAddress> getAvaliableServers() {
		return memcachedClient.getAvaliableServers();
	}

	/**
	 *
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public List<String> getServersDescription() {
		return memcachedClient.getServersDescription();
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getStat(java.lang.String)
	 * @since fangxiang @ Nov 11, 2010
	 */
	@Override
	public Map<String, String> getStats(String server, String itemName) {
		try {
			Map<InetSocketAddress, Map<String, String>> result = memcachedClient
					.getStatsByItem(itemName);
			for (InetSocketAddress inetSocketAddress : result.keySet()) {
				if (inetSocketAddress.equals(AddrUtil.getAddresses(server))) {
					return result.get(inetSocketAddress);
				}
			}
		} catch (MemcachedException e) {
			logger.error(e.getMessage(), e);
		} catch (InterruptedException e) {
			logger.error(e.getMessage(), e);
		} catch (TimeoutException e) {
			logger.error(e.getMessage(), e);
		}
		return new HashMap<String, String>();
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#asynGet(java.lang.String)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public Object asynGet(String key) {
		return get(key);
	}

	/**
	 * @return the {@link #memcachedClientStateListeners}
	 */
	public List<MemcachedClientStateListener> getMemcachedClientStateListeners() {
		return memcachedClientStateListeners;
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public List<String> listAllKeys(String server){
		KeyIterator keyIterator = null;
		try {
			keyIterator = memcachedClient.getKeyIterator(AddrUtil
					.getOneAddress(server));
		} catch (MemcachedException e) {
			logger.error(
					"server(" + server + ") listAllKeys:" + e.getMessage(), e);
		} catch (InterruptedException e) {
			logger.error(
					"server(" + server + ") listAllKeys:" + e.getMessage(), e);
		} catch (TimeoutException e) {
			logger.error(
					"server(" + server + ") listAllKeys:" + e.getMessage(), e);
		}
		List<String> keys = new LinkedList<String>();
		if (keyIterator != null) {
		while(keyIterator.hasNext()) {
				try {
					keys.add(keyIterator.next());
				} catch (MemcachedException e) {
					logger.error(
							"server(" + server + ") key next:"
									+ e.getMessage(), e);
				} catch (TimeoutException e) {
					logger.error(
							"server(" + server + ") key next:"
									+ e.getMessage(), e);
				} catch (InterruptedException e) {
					logger.error(
							"server(" + server + ") key next:"
									+ e.getMessage(), e);
				}
			}
		}
		return keys;
	}

	/**
	 * @param memcachedClientStateListeners
	 *            the {@link #memcachedClientStateListeners} to set
	 */
	public void setMemcachedClientStateListeners(
			List<MemcachedClientStateListener> memcachedClientStateListeners) {
		this.memcachedClientStateListeners = memcachedClientStateListeners;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#getName()
	 * @since TRS @ Oct 9, 2011
	 */
	@Override
	public String getName() {
		return this.getClass().getName();
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#connect(java.util.Map)
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public void connect(Map<String, String> configurations) {
		String confServers = configurations.get("addresses");
		if (StringHelper.isEmpty(confServers)) {
			confServers = "";
		}
		// 如果servers配置和当前的使用一致的话，则不需要重新连接
		if (confServers.equalsIgnoreCase(clientAddresses)) {
			logger.error("Can't configurated Memcached Server.");
			return;
		}
		clientAddresses = confServers;
		if (StringHelper.isEmpty(clientAddresses)) {
			logger.error("Can't configurated Memcached Server.");
			return;
		}
		//
		try {
			// 停止旧的客户端
			this.close();
			// 启动新的客户端
			MemcachedClientBuilder builder = new XMemcachedClientBuilder(AddrUtil.getAddresses(clientAddresses));
			builder.setSessionLocator(new KetamaMemcachedSessionLocator());
			for (MemcachedClientStateListener memcachedClientStateListener : memcachedClientStateListeners) {
				builder.addStateListener(memcachedClientStateListener);
			}
			builder.setConnectionPoolSize(5);
			// builder.getConfiguration().setHandleReadWriteConcurrently(true);
			// builder.getConfiguration().setWriteThreadCount(3);
			// builder.getConfiguration().setReadThreadCount(3);
			// builder.setCommandFactory(new BinaryCommandFactory());
			// builder.setSocketOption(StandardSocketOption.SO_RCVBUF, 32 *
			// 1024); // 设置接收缓存区为32K，默认16K
			// builder.setSocketOption(StandardSocketOption.SO_SNDBUF, 16 *
			// 1024); // 设置发送缓冲区为16K，默认为8K
			// builder.setSocketOption(StandardSocketOption.TCP_NODELAY, false);
			// // 启用nagle算法，提高吞吐量，默认关闭
			memcachedClient = builder.build();
			// memcachedClient.setOptimizeGet(true);
			// memcachedClient.setOptimizeMergeBuffer(true);
			memcachedClient.setOpTimeout(5000L);
			//
			logger.info("MemechacedClient(" + memcachedClient + ") started successfully by address(" + clientAddresses + ").");
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			memcachedClient = null;
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient#close()
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public void close() {
		if (memcachedClient != null) {
			try {
				memcachedClient.shutdown();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
			memcachedClient = null;
		}
	}
}
