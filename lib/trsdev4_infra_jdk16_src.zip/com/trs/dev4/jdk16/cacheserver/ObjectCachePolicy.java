/*
 * Created: TRS@Feb 9, 2012 6:52:40 AM
 */
package com.trs.dev4.jdk16.cacheserver;

/**
 * 职责: 定义缓存对象的缓存策略<br>
 * 
 * 由{@link ICacheServer}的接口注入，根据前缀{@link ObjectCachePolicy#keyPrefix}
 * 来判断是否采用相应的缓存策略。<br>
 * 缓存策略包括：1）是否同时使用本地缓存和远程缓存；2）缓存的默认有效期；<br>
 */
public class ObjectCachePolicy {
	/**
	 * 缓存Key的前缀，缓存Key建议采用keyPrefix@keyIdentifier的格式
	 * 
	 */
	private String keyPrefix;

	/**
	 * @return the {@link #keyPrefix}
	 */
	public String getKeyPrefix() {
		return keyPrefix;
	}

	/**
	 * @param keyPrefix
	 *            the {@link #keyPrefix} to set
	 */
	public void setKeyPrefix(String keyPrefix) {
		this.keyPrefix = keyPrefix;
	}

	/**
	 * 是否使用本地Cache
	 */
	private boolean usedLocalCache = true;
	/**
	 * 是否使用远程Cache
	 */
	private boolean usedRemoteCache = false;

	/**
	 * @return the {@link #usedlocalCache}
	 */
	public boolean isUsedLocalCache() {
		return usedLocalCache;
	}

	/**
	 * @param usedlocalCache
	 *            the {@link #usedlocalCache} to set
	 */
	public void setUsedLocalCache(boolean usedLocalCache) {
		this.usedLocalCache = usedLocalCache;
	}

	/**
	 * @return the {@link #usedRemoteCache}
	 */
	public boolean isUsedRemoteCache() {
		return usedRemoteCache;
	}

	/**
	 * @param usedRemoteCache
	 *            the {@link #usedRemoteCache} to set
	 */
	public void setUsedRemoteCache(boolean usedRemoteCache) {
		this.usedRemoteCache = usedRemoteCache;
	}

	/**
	 * 本地缓存失效时间，单位是秒，默认是600秒
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	public int getLocalExpiration() {
		return 600;
	}

	/**
	 * 远程服务器失效时间，单位是秒，默认是600秒
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	public int getRemoteExpiration() {
		return 600;
	}
}
