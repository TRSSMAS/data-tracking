package com.trs.dev4.jdk16.cacheserver.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;
import com.trs.dev4.jdk16.cacheserver.memcached.IMemcachedClient;
import com.trs.dev4.jdk16.model.Configuration;
import com.trs.dev4.jdk16.model.IConfigurable;
import com.trs.dev4.jdk16.model.IConfigurationManager;
import com.trs.dev4.jdk16.model.IModuleLifecycle;
import com.trs.dev4.jdk16.model.ValidationErrors;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 缓存服务器的Memcached实现
 * 
 */
public class MemcachedCacheServer implements ICacheServer, IConfigurable {

	protected static Logger logger = Logger
			.getLogger(MemcachedCacheServer.class);
	/**
	 * 初始化使用的MemcachedClient
	 */
	IMemcachedClient memcachedClient;
	/**
	 * 
	 */
	private String usedMemcachedClientName = "";
	/**
	 * 
	 */
	private IConfigurationManager configurationManager;
	/**
	 * 可用的客户端列表
	 */
	List<IMemcachedClient> availableClients;
	/**
	 * 当前应用的缓存前缀
	 */
	String appKey = "trs:";
	/**
	 * 当前选择的客户端名称
	 */
	String selectedClientName;
	/**
	 * 最长过期时间
	 */
	int maxExpire = 20 * 60;

	/**
	 * 设置最长过期时间
	 * 
	 * @param maxExpire
	 * @since liuyou @ 2010-5-23
	 */
	public void setMaxExpire(int maxExpire) {
		this.maxExpire = maxExpire;
	}

	/**
	 * 过期时间的处理，超长或者为负时设置为最长过期时间
	 * 
	 * @param expire
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	public int getExpire(int expire) {
		return (expire <= 0 || expire > maxExpire) ? maxExpire : expire;
	}

	public void setMemcachedClient(IMemcachedClient client) {
		this.memcachedClient = client;
	}

	public IMemcachedClient getMemcachedClient() {
		return this.memcachedClient;
	}

	/**
	 * 获取当前可用的MemcachedClient
	 * 
	 * @return 可用的MemcachedClient
	 * @since TRS @ Oct 9, 2011
	 */
	IMemcachedClient getCurrentMemecachedClient() {
		// 如果设置了memcachedClient，则使用设置的（兼容旧版本）
		if (memcachedClient != null) {
			return memcachedClient;
		}
		// 如果没有设置memcachedClient，则根据selectedClientName获取指定的MemcachedClient
		for (IMemcachedClient memcachedClient : availableClients) {
			if (memcachedClient.getName().equals(selectedClientName)) {
				this.memcachedClient = memcachedClient;
				break;
			}
		}
		//
		return memcachedClient;
	}

	/**
	 * 设置当前应用的缓存前缀
	 * 
	 * @param appKey
	 * @since liuyou @ 2010-5-23
	 */
	public void setAppKey(String appKey) {
		this.appKey = appKey + ":";
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#getAppKey()
	 * @since liuyou @ 2010-5-23
	 */
	public String getAppKey() {
		return this.appKey;
	}

	/**
	 * key可能需要包装，提取为方法，便于覆盖
	 * 
	 * @param key
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	public String buildKey(String key) {
		return key;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void add(String key, int expr, Object value) {
		if (logger.isDebugEnabled()) {
			logger.debug("add cache:"
					+ StringHelper.join(new Object[] { key, expr, value }));
		}
		memcachedClient.add(buildKey(key), getExpire(expr), value);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#delete(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void delete(String key) {
		memcachedClient.delete(buildKey(key));
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public Object get(String key) {
		return memcachedClient.get(buildKey(key));
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void replace(String key, int expr, Object value) {
		if (logger.isDebugEnabled()) {
			logger.debug("replace cache:"
					+ StringHelper.join(new Object[] { key, expr, value }));
		}
		memcachedClient.replace(buildKey(key), getExpire(expr), value);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String,
	 *      int, java.lang.Object)
	 * @since liuyou @ 2010-5-23
	 */
	@Override
	public void set(String key, int expr, Object value) {
		if (logger.isDebugEnabled()) {
			logger.debug("set cache:"
					+ StringHelper.join(new Object[] { key, expr, value }));
		}
		memcachedClient.set(buildKey(key), getExpire(expr), value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void set(String key, Object value) {
		this.set(key, maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void add(String key, Object value) {
		this.add(key, maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public void replace(String key, Object value) {
		this.replace(key, maxExpire, value);
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 21, 2011
	 */
	@Override
	public Object get(String key, Object defaultVal) {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since TRS @ Sep 28, 2011
	 */
	public String getModuleName() {
		return "MemcachedCacheServer";
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#start()
	 * @since TRS @ Sep 28, 2011
	 */
	public void start() {
		//
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#stop()
	 * @since TRS @ Sep 28, 2011
	 */
	public void stop() {

	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since TRS @ Sep 28, 2011
	 */
	public void restart() {
	}

	/**
	 * 
	 * @param confMemcachedClientName
	 * @since TRS @ Oct 21, 2011
	 */
	private IMemcachedClient getMemcachedClient(String confMemcachedClientName) {
		IMemcachedClient newMemcachedClient = null;
		for (IMemcachedClient memcachedClient : availableClients) {
			if (confMemcachedClientName.equals(memcachedClient.getName())) {
				newMemcachedClient = memcachedClient;
			}
		}
		return newMemcachedClient;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#getPrefix()
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public String getPrefix() {
		return "memcachedServer";
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#refreshConfigs()
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public void refreshConfigs() {
		String confMemcachedClientName = configurationManager.getConfiguration(this, "memcachedServer", "");
		if (StringHelper.isEmpty(confMemcachedClientName)) {
			confMemcachedClientName = "";
		}
		// 如果配置和现在的地址一样，不用修改
		if (usedMemcachedClientName.equalsIgnoreCase(confMemcachedClientName)) {
			return;
		}
		// 停止旧的客户端
		if (memcachedClient != null) {
			((IModuleLifecycle) memcachedClient).stop();
			memcachedClient = null;
		}
		// 启动新的客户端
		IMemcachedClient newMemcachedClient = getMemcachedClient(confMemcachedClientName);
		if (newMemcachedClient != null) {
			((IModuleLifecycle) newMemcachedClient).start();
			memcachedClient = newMemcachedClient;
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#validateConfigs(java.util.Map)
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public ValidationErrors validateConfigs(Map<String, Configuration> configs) {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#clearAll()
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void clearAll() {
	}
}
