package com.trs.dev4.jdk16.cacheserver.impl;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;
import com.trs.dev4.jdk16.cacheserver.IObjectCachePolicyRegister;
import com.trs.dev4.jdk16.cacheserver.ObjectCachePolicy;
import com.trs.dev4.jdk16.model.Configuration;
import com.trs.dev4.jdk16.model.IConfigurable;
import com.trs.dev4.jdk16.model.IConfigurationManager;
import com.trs.dev4.jdk16.model.IModuleLifecycle;
import com.trs.dev4.jdk16.model.ValidationErrors;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 缓存服务器调用方代理接口
 * 
 * @since 2010-6-25
 */
public class CacheServerFactoryBean implements ICacheServer, IConfigurable, IModuleLifecycle, IObjectCachePolicyRegister {

	/**
	 * 当前使用的CacheServer
	 */
	private ICacheServer remoteCacheServer;
	/**
	 * 本地缓存服务器，不管是否使用，都会启动
	 */
	private ICacheServer localCacheServer;
	/**
	 * 默认的对象缓存策略，如果没有找到与{@link ObjectCachePolicy#getKeyPrefix()}相匹配的策略，则使用此策略
	 */
	private final static ObjectCachePolicy DEFAULT_POLICY = new ObjectCachePolicy();
	/**
	 * 对象缓存策略集合，主键是{@link ObjectCachePolicy#getKeyPrefix()}
	 */
	private Map<String, ObjectCachePolicy> objectCachePolicies = new ConcurrentHashMap<String, ObjectCachePolicy>();
	/**
	 * 
	 */
	private IConfigurationManager configurationManager;
	/**
	 * 可用的CacheServer服务器
	 */
	private Map<String, ICacheServer> availableCacheServers = new ConcurrentHashMap<String, ICacheServer>();
	/**
	 * 
	 */
	private final static Logger LOG = Logger.getLogger(CacheServerFactoryBean.class);

	/**
	 * 
	 * @param key
	 * @return
	 * @since TRS @ Feb 9, 2012
	 */
	protected ObjectCachePolicy findPolicy(String key) {
		String keyPrefix = getKeyPrefix(key);
		ObjectCachePolicy objectCachePolicy = null;
		if (!StringHelper.isEmpty(keyPrefix)) {
			objectCachePolicy = objectCachePolicies.get(keyPrefix);
		}
		return (objectCachePolicy != null) ? objectCachePolicy : DEFAULT_POLICY;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 28, 2011
	 */
	public void add(String key, Object value) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		if (objectCachePolicy.isUsedLocalCache()) {
			setLocalCache(key, objectCachePolicy.getLocalExpiration(), value);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			setRemoteCache(key, objectCachePolicy.getRemoteExpiration(), value);
		}
	}

	/**
	 * 缓存到远程服务器
	 * 
	 * @param key
	 * @param value
	 * @since TRS @ Feb 13, 2012
	 */
	protected void setRemoteCache(String key, int expr, Object value) {
		if (remoteCacheServer == null) {
			return;
		}
		remoteCacheServer.add(key, expr, value);
	}

	/**
	 * 缓存到远程服务器
	 * 
	 * @param key
	 * @param value
	 * @since TRS @ Feb 13, 2012
	 */
	protected void setLocalCache(String key, int expr, Object value) {
		if (localCacheServer == null) {
			return;
		}
		localCacheServer.add(key, expr, value);
	}

	/**
	 * 
	 * @param key
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	String getKeyPrefix(String key) {
		int keyPrefixIndex = key.indexOf("@");
		if (keyPrefixIndex != -1) {
			return key.substring(0, keyPrefixIndex);
		}
		return "";
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#delete(java.lang.String)
	 * @since TRS @ Sep 28, 2011
	 */
	public void delete(String key) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		if (objectCachePolicy.isUsedLocalCache()) {
			deleteLocalCache(key);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			deleteRemoteCache(key);
		}
	}

	/**
	 * 从本地缓存中删除缓存对象
	 * 
	 * @param key
	 * @since TRS @ Feb 13, 2012
	 */
	protected void deleteLocalCache(String key) {
		if (localCacheServer == null) {
			return;
		}
		localCacheServer.delete(key);
	}

	/**
	 * 从远程的服务器删除缓存对象
	 * 
	 * @param key
	 * @since TRS @ Feb 13, 2012
	 */
	protected void deleteRemoteCache(String key) {
		if (remoteCacheServer == null) {
			return;
		}
		remoteCacheServer.delete(key);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String)
	 * @since TRS @ Sep 28, 2011
	 */
	public Object get(String key) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		Object cachedObject = null;
		if (objectCachePolicy.isUsedLocalCache()) {
			cachedObject = getLocalCache(key);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			cachedObject = getRemoteCache(key);
		}
		return cachedObject;
	}

	/**
	 * 从本地缓存获取缓存对象
	 * 
	 * @param key
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected Object getLocalCache(String key) {
		if (localCacheServer == null) {
			return null;
		}
		return localCacheServer.get(key);
	}

	/**
	 * 从远程服务器获取缓存对象
	 * 
	 * @param key
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected Object getRemoteCache(String key) {
		if (remoteCacheServer == null) {
			return null;
		}
		return remoteCacheServer.get(key);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#get(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 28, 2011
	 */
	public Object get(String key, Object defaultVal) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		Object cachedObject = null;
		if (objectCachePolicy.isUsedLocalCache()) {
			cachedObject = getLocalCache(key);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			cachedObject = getRemoteCache(key);
		}
		return (cachedObject == null) ? defaultVal : cachedObject;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 28, 2011
	 */
	public void replace(String key, Object value) {
		this.set(key, value);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String,
	 *      java.lang.Object)
	 * @since TRS @ Sep 28, 2011
	 */
	public void set(String key, Object value) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		if (objectCachePolicy.isUsedLocalCache()) {
			setLocalCache(key, objectCachePolicy.getLocalExpiration(), value);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			setRemoteCache(key, objectCachePolicy.getRemoteExpiration(), value);
		}
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#add(java.lang.String,
	 *      int, java.lang.Object)
	 * @since TRS @ Sep 28, 2011
	 */
	@Override
	public void add(String key, int expr, Object value) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		if (objectCachePolicy.isUsedLocalCache()) {
			setLocalCache(key, expr, value);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			setRemoteCache(key, expr, value);
		}
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#replace(java.lang.String,
	 *      int, java.lang.Object)
	 * @since TRS @ Sep 28, 2011
	 */
	@Override
	public void replace(String key, int expr, Object value) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		if (objectCachePolicy.isUsedLocalCache()) {
			setLocalCache(key, expr, value);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			setRemoteCache(key, expr, value);
		}
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#set(java.lang.String,
	 *      int, java.lang.Object)
	 * @since TRS @ Sep 28, 2011
	 */
	@Override
	public void set(String key, int expr, Object value) {
		ObjectCachePolicy objectCachePolicy = findPolicy(key);
		if (objectCachePolicy.isUsedLocalCache()) {
			setLocalCache(key, expr, value);
		}
		if (objectCachePolicy.isUsedRemoteCache()) {
			setRemoteCache(key, expr, value);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#start()
	 * @since TRS @ Sep 28, 2011
	 */
	@Override
	public void start() {
		if (!configurationManager.existsOrConfigured(this, "cacheServerType")) {
			configurationManager.addConfigKey(this, "cacheServerType", "缓存服务器类型", "配置缓存服务器", "");
		}
		// 初始化默认的缓存对象；
		this.refreshConfigs();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#stop()
	 * @since TRS @ Sep 28, 2011
	 */
	@Override
	public void stop() {
		if (remoteCacheServer != null) {
			LOG.info("CacheServer(" + remoteCacheServer + ") stopped successfully.");
			remoteCacheServer = null;
		}
		if (localCacheServer != null) {
			localCacheServer = null;
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since TRS @ Sep 28, 2011
	 */
	@Override
	public void restart() {

	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public String getModuleName() {
		return this.getClass().getSimpleName();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#getPrefix()
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public String getPrefix() {
		return "cacheserver";
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#refreshConfigs()
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public void refreshConfigs() {
		String configuredCacheServerType = configurationManager.getConfiguration(this, "cacheServerType");
		// 没有设置或者设置的不同，则重新获取CacheServer
		if (remoteCacheServer == null || !this.remoteCacheServer.getClass().getSimpleName().equalsIgnoreCase(configuredCacheServerType)) {
			remoteCacheServer = this.availableCacheServers.get(configuredCacheServerType);
			if (remoteCacheServer != null) {
				LOG.info("Found the CacheServer with configuredCacheServerType[" + configuredCacheServerType + "].");
			} else {
				LOG.error("Can't found the CacheServer with configuredCacheServerType[" + configuredCacheServerType + "].");
				remoteCacheServer = null;
			}
			return;
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#validateConfigs(java.util.Map)
	 * @since TRS @ Nov 4, 2011
	 */
	@Override
	public ValidationErrors validateConfigs(Map<String, Configuration> configs) {
		return null;
	}

	/**
	 * @param configurationManager
	 *            the {@link #configurationManager} to set
	 */
	void setConfigurationManager(IConfigurationManager configurationManager) {
		this.configurationManager = configurationManager;
	}

	/**
	 * @param availableCacheServers
	 *            the {@link #availableCacheServers} to set
	 */
	void setAvailableCacheServers(Map<String, ICacheServer> availableCacheServers) {
		if (availableCacheServers == null) {
			LOG.error("availableCacheServers is null,discarded.");
			return;
		}
		if (this.availableCacheServers == null) {
			return;
		}
		for (ICacheServer cacheServer : availableCacheServers.values()) {
			if (cacheServer == null)
				continue;
			this.availableCacheServers.put(cacheServer.getClass().getSimpleName(), cacheServer);
		}
	}

	/**
	 * @return the {@link #remoteCacheServer}
	 */
	public ICacheServer getRemoteCacheServer() {
		return remoteCacheServer;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#register(com.trs.dev4.jdk16.cacheserver.ObjectCachePolicy)
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public ObjectCachePolicy register(ObjectCachePolicy objectCachePolicy) {
		if (objectCachePolicy == null) {
			throw new NullPointerException("ObjectCachePolicy is null.");
		}
		if (StringHelper.isEmpty(objectCachePolicy.getKeyPrefix())) {
			throw new NullPointerException("ObjectCachePolicy(" + objectCachePolicy + "): KeyPrefix is null.");
		}
		ObjectCachePolicy oldObjectCachePolicy = objectCachePolicies.get(objectCachePolicy.getKeyPrefix());
		objectCachePolicies.put(objectCachePolicy.getKeyPrefix(), objectCachePolicy);
		return oldObjectCachePolicy;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#unregister(java.lang.String)
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public ObjectCachePolicy unregister(String keyPrefix) {
		if (StringHelper.isEmpty(keyPrefix)) {
			throw new NullPointerException("KeyPrefix is null.");
		}
		ObjectCachePolicy oldObjectCachePolicy = objectCachePolicies.get(keyPrefix);
		objectCachePolicies.remove(keyPrefix);
		return oldObjectCachePolicy;
	}

	/**
	 * @param localCacheServer
	 *            the {@link #localCacheServer} to set
	 */
	public void setLocalCacheServer(ICacheServer localCacheServer) {
		this.localCacheServer = localCacheServer;
	}

	/**
	 * @see com.trs.dev4.jdk16.cacheserver.ICacheServer#clearAll()
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void clearAll() {
		this.localCacheServer.clearAll();
	}
}
