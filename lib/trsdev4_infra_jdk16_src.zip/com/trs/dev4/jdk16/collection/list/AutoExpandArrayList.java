/*
 * Created: yaonengjun@2011-5-31 下午02:19:06
 */
package com.trs.dev4.jdk16.collection.list;

import java.util.ArrayList;

import org.apache.log4j.Logger;

/**
 * 职责: <br>
 * 重写ArrayList的get方法，提供一个永远不会越界的List实现类。
 * 
 */
public class AutoExpandArrayList<T> extends ArrayList<T> {

	private static final Logger logger = Logger.getLogger(AutoExpandArrayList.class);

	private static final long serialVersionUID = 1L;

	private Class<T> itemClass;

	public AutoExpandArrayList(Class<T> itemClass) {
		this.itemClass = itemClass;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.ArrayList#get(int)
	 */
	@Override
	public T get(int index) {
		try {
			while (index >= size()) {
				add(itemClass.newInstance());
			}
		} catch (Exception e) {
			logger.error("Try to expand List size in get method fail", e);
		}
		return super.get(index);
	}

}
