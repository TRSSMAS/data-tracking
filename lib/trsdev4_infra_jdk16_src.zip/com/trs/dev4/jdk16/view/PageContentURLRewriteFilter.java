/*
 * Created: TRS@Sep 27, 2011 2:40:26 PM
 */
package com.trs.dev4.jdk16.view;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: 将页面内容中的动态URL改写成静态URL<br>
 * 
 */
public class PageContentURLRewriteFilter implements Filter {

	private final static Logger LOG = Logger.getLogger(PageContentURLRewriteFilter.class);

	/**
	 * @see javax.servlet.Filter#destroy()
	 * @since TRS @ Sep 27, 2011
	 */
	@Override
	public void destroy() {

	}

	/**
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 * @since TRS @ Sep 27, 2011
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		//
		if (needRewrite(httpRequest, httpResponse)) {
			URLRewriteResponseWrapper wrapper = new URLRewriteResponseWrapper(httpResponse);
			// request.getRequestDispatcher("").include(request, wapper);
			filterChain.doFilter(httpRequest, wrapper);
			String htmlContent = wrapper.getContent();
			// 输出处理后的数据
			long replaceBegin = System.currentTimeMillis();
			Map<String, String> rewriteRules = this.loadRewriteRules(httpRequest, httpResponse);
			if (rewriteRules != null) {
				for (String findRegex : rewriteRules.keySet()) {
					String replaceRegex = rewriteRules.get(findRegex);
					htmlContent = StringHelper.regexReplace(htmlContent, findRegex, replaceRegex);
				}
				long timeUsed = (System.currentTimeMillis() - replaceBegin);
				if (LOG.isDebugEnabled()) {
					LOG.debug("Request(" + httpRequest.getServletPath() + ")' repsone-rewrited by (" + rewriteRules.size() + ") rules consumed(" + timeUsed
							+ "ms).");
				}
				httpResponse.setHeader("Rewrite-Tags", timeUsed + "ms," + DateUtil.getCurrentDateTime());
			} else {
				if (LOG.isDebugEnabled()) {
					LOG.debug("Request(" + httpRequest.getServletPath() + ")' repsone-rewrited by rewriteRules == null");
				}
			}
			//
			Writer output = response.getWriter();
			output.write(htmlContent);
			output.flush();
		} else {
			filterChain.doFilter(request, response);
		}
	}

	/**
	 * 获取重写规则
	 * 
	 * @param request
	 *            请求
	 * @param response
	 *            响应
	 * @return Map的key是查找规则，value是替换规则
	 * @since TRS @ Sep 28, 2011
	 */
	protected Map<String, String> loadRewriteRules(HttpServletRequest request, HttpServletResponse response) {
		Map<String, String> rewriteRules = new HashMap<String, String>();
		rewriteRules.put("\\/boardList\\.do\\?action=postList&boardId=(\\d*)", "/postList_$1.html");
		rewriteRules.put("\\/userInfo\\.do\\?userNick=(.*)\"", "/userNick_$1.html");
		return rewriteRules;
	}

	/**
	 * 判断请求是否需要进行内容的URL重写，子类需进行覆盖
	 * 
	 * @param request
	 *            请求
	 * @param response
	 *            响应
	 * @return true表示需要重写，false表示不需要重写
	 * @since TRS @ Sep 28, 2011
	 */
	protected boolean needRewrite(HttpServletRequest request, HttpServletResponse response) {
		int urlSEO = RequestUtil.getParameterAsInt(request, "seo", 0);
		return (urlSEO == 1);
	}

	/**
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 * @since TRS @ Sep 27, 2011
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

}
