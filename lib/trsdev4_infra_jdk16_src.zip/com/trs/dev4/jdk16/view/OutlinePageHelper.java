package com.trs.dev4.jdk16.view;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.utils.UrlUtil;

/**
 * 概览页面获取数据和链接/参数处理的助手.<br>
 * 
 * @author TRS信息技术股份有限公司
 * @creator liushen @ Mar 20, 2009
 */
public class OutlinePageHelper {
	/**
	 *
	 */
	private final static Logger logger = Logger
			.getLogger(OutlinePageHelper.class);
	/**
	 *
	 */
	private static final String DEFAULT_PAGENO_PARAMNAME = "pn";

	/**
	 *
	 */
	private static final int DEFAULT_PAGESIZE = 20;

	/**
	 *
	 */
	private String paramPageNo;

	/**
	 *
	 */
	private int pageSize;

	/**
	 *
	 */
	private HttpServletRequest request;

	/**
	 * 客户端原始请求的URL(包括QueryString).
	 */
	private String clientRequestURL;

	/**
	 * 概览的结果集, 分页列表.
	 */
	private PagedList<? extends Object> pagedList;
	/**
	 *
	 */
	private String pagedAttributeName = "";

	/**
	 * 构造当前概览请求对应的助手对象，默认分页结果集名为pagedList.
	 * 
	 * @param request
	 */
	public OutlinePageHelper(HttpServletRequest request) {
		this.request = request;
		this.pagedAttributeName = "articles";
		init(paramPageNo, DEFAULT_PAGESIZE);
	}

	/**
	 * 构造当前概览请求对应的助手对象.
	 * 
	 * @param request
	 *            请求
	 * @param pagedAttributeName
	 *            分页结果集的名称
	 */
	public OutlinePageHelper(HttpServletRequest request,
			String pagedAttributeName) {
		this.request = request;
		this.pagedAttributeName = pagedAttributeName;
		init(paramPageNo, DEFAULT_PAGESIZE);
	}

	/**
	 * 获取当前的页面页码
	 * 
	 * @return 当前的页码
	 */
	public int getCurrentPage() {
		return RequestUtil.getParameterAsInt(request, paramPageNo);
	}

	/**
	 * 获取指定页的链接.
	 * 
	 * @param pageIndex
	 *            页码
	 * 
	 * @return 与页码对应的页面链接
	 */
	public String getPageLink(int pageIndex) {
		return UrlUtil.addOrReplaceParam(clientRequestURL, paramPageNo,
				pageIndex);
	}

	/**
	 * 获取上一页的链接.
	 * 
	 * @return 获取当前页面的上一页链接
	 * 
	 */
	public String getPrevPageLink() {
		return UrlUtil.addOrReplaceParam(clientRequestURL, paramPageNo,
				pagedList.getPrevPage());
	}

	/**
	 * 获取下一页的链接.
	 * 
	 * @return 获取当前页面的下一页链接
	 */
	public String getNextPageLink() {
		return UrlUtil.addOrReplaceParam(clientRequestURL, paramPageNo,
				pagedList.getNextPage());
	}

	/**
	 * 获取首页的链接.
	 * 
	 * @return 获取当前页面的第一页链接
	 * 
	 */
	public String getFirstPageLink() {
		return UrlUtil.addOrReplaceParam(clientRequestURL, paramPageNo,
				pagedList.getFirstPageNo());
	}

	/**
	 * 获取末页的链接.
	 * 
	 * @return 获取当前页面的最后一页链接
	 * 
	 */
	public String getLastPageLink() {
		return UrlUtil.addOrReplaceParam(clientRequestURL, paramPageNo,
				pagedList.getLastPageNo());
	}

	/**
	 * Get the {@link #clientRequestURL}.
	 * 
	 * @return the {@link #clientRequestURL}.
	 */
	public String getClientRequestURL() {
		return clientRequestURL;
	}

	/**
	 * Get the {@link #pageSize}.
	 * 
	 * @return the {@link #pageSize}.
	 */
	public int getPageSize() {
		return pageSize;
	}

	/**
	 * 
	 * @param request
	 *            请求
	 * @param paramName
	 *            参数名
	 * @param pageSize
	 *            每页的记录条数
	 */
	OutlinePageHelper(HttpServletRequest request, String paramName, int pageSize) {
		this.request = request;
		init(paramName, pageSize);
	}

	/**
	 * 初始化
	 * 
	 * @param paramName
	 * @param pageSize
	 * @since fangxiang @ May 22, 2010
	 */
	@SuppressWarnings("unchecked")
	private void init(String paramName, int pageSize) {
		this.paramPageNo = (paramName == null || paramName.isEmpty()) ? DEFAULT_PAGENO_PARAMNAME
		: paramName;
		this.pageSize = (pageSize < 1) ? DEFAULT_PAGESIZE : pageSize;
		pagedList = (PagedList<? extends Object>) request
				.getAttribute(pagedAttributeName);
		clientRequestURL = RequestUtil.getClientRequestURL(request);
		if (logger.isDebugEnabled()) {
			logger.debug("clientRequestURL:" + clientRequestURL
					+ ",pagedAttributeName:" + pagedAttributeName
					+ ",paramPageNo:" + paramPageNo + ",pageSize:" + pageSize);
		}
	}

	/**
	 * Get the {@link #pagedList}.
	 * 
	 * @return the {@link #pagedList}.
	 */
	public PagedList<? extends Object> getOutlineResult() {
		return pagedList;
	}
}
