package com.trs.dev4.jdk16.view;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.log4j.Logger;
import org.springframework.ui.ModelMap;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.xss.SafeHtmlUtil;

/**
 * HttpServletRequestWrapper的扩展类，修改了getParameter和getRemoteAddress的实现，<br>
 * 其中 getParamter参数不区分大小写，getRemoteAddress则能获得Apache等传递过来的地址<br>
 * 此外提供了较为丰富的接口<br>
 * 
 */

public class RequestWrapper extends HttpServletRequestWrapper {

	/**
	 * 
	 * @param request
	 */
	public RequestWrapper(HttpServletRequest request) {
		super(request);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 3, 2010
	 */
	public HttpServletRequest getHttpServletRequest() {
		return _getHttpServletRequest();
	}
	private HttpServletRequest _getHttpServletRequest() {
		return ((HttpServletRequest) super.getRequest());
	}

	/**
	 * 
	 * @param index
	 * @return
	 * @since TRS @ Feb 10, 2012
	 */
	public MultipartFile getMultipartFile(String fileName) {
		if (!(super.getRequest() instanceof MultipartHttpServletRequest)) {
			return null;
		}
		return ((MultipartHttpServletRequest) getRequest()).getFile(fileName);
	}

	/**
	 * 从HttpServletRequest转换为RequestWrapper
	 * 
	 * @param request
	 * @return
	 * @since liuyou @ 2010-4-22
	 */
	public static RequestWrapper getWrapper(HttpServletRequest request) {
		if (request instanceof RequestWrapper) {
			return (RequestWrapper) request;
		}
		return new RequestWrapper(request);
	}

	/**
	 * 从ServletWebRequest转换为RequestWrapper
	 * 
	 * @param webReq
	 * @return
	 * @since liuyou @ 2010-4-22
	 */
	public static RequestWrapper getWrapper(ServletWebRequest webReq) {
		HttpServletRequest request = webReq.getRequest();
		if (request instanceof RequestWrapper) {
			return (RequestWrapper) request;
		}
		return new RequestWrapper(request);
	}

	/**
	 * 返回整形数，为空时返回默认值
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @param defVal
	 * @return
	 */
	public int getInt(String paramName, int defVal) {
		String value = this.getParameter(paramName);
		if (StringHelper.isEmpty(value))
			return defVal;
		try {
			return Integer.parseInt(value);
		} catch (RuntimeException re) {
			return defVal;
		}
	}

	/**
	 * 返回整形数，为空时返回0
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @return
	 */
	public int getInt(String paramName) {
		return getInt(paramName, 0);
	}

	/**
	 * 返回字符串，为空时返回默认值
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @param defVal
	 * @return
	 */
	public String getString(String paramName, String defVal) {
		String value = this.getParameter(paramName);
		return StringHelper.avoidEmpty(value, defVal);
	}

	/**
	 * 返回字符串，为空时返回空字符串
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @return
	 */
	public String getString(String paramName) {
		return getString(paramName, "");
	}

	/**
	 * 返回Double型值，为空时返回默认值
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @param defVal
	 * @return
	 */
	public double getDouble(String paramName, double defVal) {
		String value = this.getParameter(paramName);
		if (StringHelper.isEmpty(value))
			return defVal;
		try {
			return Double.parseDouble(value);
		} catch (RuntimeException re) {
			return defVal;
		}
	}

	/**
	 * 返回Double型值，为空时返回0.0
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @return
	 */
	public double getDouble(String paramName) {
		return getDouble(paramName, 0.0);
	}

	/**
	 * 返回Boolean型值，为空时返回默认值
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @param defVal
	 * @return
	 */
	public boolean getBoolean(String paramName, boolean defVal) {
		String value = this.getParameter(paramName);
		if (StringHelper.isEmpty(value))
			return defVal;
		try {
			return "true".equals(value) || "1".equals(value);
		} catch (RuntimeException re) {
			return defVal;
		}
	}

	/**
	 * 返回Boolean型值，为空时返回false
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param paramName
	 * @return
	 */
	public boolean getBoolean(String paramName) {
		return getBoolean(paramName, false);
	}

	private Map<String, String> ignoreCaseParamNames = new HashMap<String, String>();

	/**
	 * 设置当前请求是否参数大小写敏感
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param ignoreCase
	 */
	public void setIgnoreCase(boolean ignoreCase) {
		ignoreCaseParamNames.clear();
		if (!ignoreCase)
			return;
		Enumeration<?> enums = getParameterNames();
		while (enums.hasMoreElements()) {
			String paramName = (String) enums.nextElement();
			ignoreCaseParamNames.put(paramName.toLowerCase(), paramName);
		}
	}

	// override the default behavior

	@Override
	public String getRemoteAddr() {
		HttpServletRequest request = _getHttpServletRequest();
		String remoteAddr = request.getHeader("x-forwarded-for");
		if (StringHelper.isEmpty(remoteAddr)
				|| "Unknown".equalsIgnoreCase(remoteAddr)) {
			remoteAddr = request.getHeader("Proxy-Client-IP");
		}
		if (StringHelper.isEmpty(remoteAddr)
				|| "Unknown".equalsIgnoreCase(remoteAddr)) {
			remoteAddr = request.getHeader("WL-Proxy-Client-IP");
		}
		if (StringHelper.isEmpty(remoteAddr)
				|| "Unknown".equalsIgnoreCase(remoteAddr)) {
			remoteAddr = request.getRemoteAddr();
		}
		return remoteAddr;
	}

	@Override
	public String getParameter(String arg0) {
		HttpServletRequest request = _getHttpServletRequest();
		String value = null;
		try {
			value = request.getParameter(arg0);
			if (value != null)
				return value;
			String newParamName = ignoreCaseParamNames.get(arg0.toLowerCase());
			if (newParamName != null && !arg0.equals(newParamName)) {
				return value = request.getParameter(newParamName);
			}
		} finally {
		}
		return null;
	}

	/**
	 * 指定长度，并且做XSS检查
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param arg0
	 * @param maxLen
	 * @return
	 */
	public String getParameter(String arg0, int maxLen) {
		return getParameter(arg0, maxLen, true);
	}

	/**
	 * 指定长度，并且可以设定XSS检查
	 * 
	 * @since 2010-4-9
	 * @creator liuyou
	 * @param arg0
	 * @param maxLen
	 * @param xssCheck
	 * @return
	 */
	public String getParameter(String arg0, int maxLen, boolean xssCheck) {
		String value = getParameter(arg0);
		value = xssCheck ? SafeHtmlUtil.getSafeHtml(value) : value;
		if (value.length() > maxLen)
			return value.substring(0, maxLen - 1);
		return value;
	}

	@Override
	public String[] getParameterValues(String arg0) {
		HttpServletRequest request = _getHttpServletRequest();
		String[] result = request.getParameterValues(arg0);
		if (result != null && result.length > 0)
			return result;
		String newParamName = ignoreCaseParamNames.get(arg0.toLowerCase());
		if (newParamName != null && !arg0.equals(newParamName)) {
			return request.getParameterValues(newParamName);
		}
		return result;
	}

	/**
	 *
	 */
	private static final int DEFAULT_PAGESIZE = 20;
	/**
		 *
		 */
	private static final int DEFAULT_PAGENO = 0;
	/**
	 * 日志
	 */
	private static final Logger LOG = Logger.getLogger(RequestWrapper.class);

	/**
	 * 从Request中获取分页查询条件.
	 * 
	 * @return
	 */
	public SearchFilter getSearchFilter(boolean isOwner) {
		SearchFilter sf = getPageSearchFiler();
		String key = getSearchField();
		String value = getSearchWord();
		String opreator = StringHelper.avoidEmpty(getSearchOperator(), "=");
		if (!StringHelper.isEmpty(key) && !StringHelper.isEmpty(value)) {
			// 不缓存检索条件下的数据
			// by liuyou @2010-05-17
			sf.setCacheable(false);
			sf.addCondition(opreator, key, value);
		}
		// 时间字段
		buildTimeField(sf);
		// 排序字段
		buildOrderField(sf);
		return sf;
	}

	/**
	 * 从Request中获取分页查询条件.
	 * 
	 * @return
	 */
	public SearchFilter getSearchFilter() {
		return this.getSearchFilter(false);
	}

	/**
	 * 
	 * @since fangxiang @ Apr 17, 2010
	 */
	private void buildTimeField(SearchFilter sf) {
		String timeField = getTimeField();
		if (StringHelper.isEmpty(timeField)) {
			return;
		}
		// 开始时间
		long beginTime = DateUtil.getDateAsMillis(getBeginTime());
		long endTime = DateUtil.getDateAsMillis(getEndTime());
		if (beginTime != -1 && endTime != -1) {
			sf.addBetweenCondition(timeField, beginTime, endTime);
		} else if (beginTime != -1) {
			sf.addGreaterThanEquals(timeField, beginTime);
		} else {
			sf.addLesserThanEquals(timeField, endTime);
		}
		// 不缓存检索条件下的数据
		// by liuyou @2010-05-17
		sf.setCacheable(false);
	}

	/**
	 * @param sf
	 * @since fangxiang @ Apr 17, 2010
	 */
	private void buildOrderField(SearchFilter sf) {
		String orderField = getOrderField();
		if (StringHelper.isEmpty(orderField)) {
			return;
		}
		String orderFlag = getOrderFlag();
		sf.setOrderBy(orderField
				+ HQL_SEPARATOR
				+ (orderFlag.equalsIgnoreCase(ORDER_FLAG_ASC) ? ORDER_FLAG_ASC
						: ORDER_FLAG_DESC));
		if (StringHelper.isEmpty(sf.getOrderBy())) {
			sf.setOrderBy(DEFAULT_ORDER_BY);
		}
		// 不缓存非默认排序下的数据
		// by liuyou @2010-05-17
		sf.setCacheable(false);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String getTimeField() {
		return RequestUtil.getParameterAndTrim(this, PARAM_TIME_FIELD);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String getBeginTime() {
		return RequestUtil.getParameterAndTrim(_getHttpServletRequest(),
				PARAM_BEGIN_TIME);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String getEndTime() {
		return RequestUtil.getParameterAndTrim(this, PARAM_END_TIME);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String getOrderField() {
		return RequestUtil.getParameterAndTrim(this, PRAM_ORDER_FIELD);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public String getOrderFlag() {
		return RequestUtil.getParameterAsTrimed(this, PARAM_ORDER_FLAG,
				ORDER_FLAG_ASC);
	}

	/**
	 * 构造只含有pageNo和PageSize的SearchFilter
	 * 
	 * @return
	 * @creator fangxiang @ 2009-12-11
	 */
	public SearchFilter getPageSearchFiler() {
		int pageNo = getPageNo();
		int pageSize = getPageSize();
		SearchFilter sf = SearchFilter.getSearchFilter(pageNo, pageSize);
		// 只缓存第一页固定条数的数据
		// by liuyou @2010-05-17
		if (pageNo != DEFAULT_PAGENO || pageSize != DEFAULT_PAGESIZE) {
			sf.setCacheable(false);
		}
		if (StringHelper.isEmpty(sf.getOrderBy())) {
			sf.setOrderBy(DEFAULT_ORDER_BY);
		}
		return sf;
	}

	/**
	 * @return
	 * @creator liushen @ Apr 3, 2009
	 */
	public String getSearchOperator() {
		return RequestUtil.getParameterAsTrimed(this, "sOpr", null);
	}

	/**
	 * 
	 * @param operator
	 * @return
	 * @creator liushen @ Apr 6, 2009
	 */
	public boolean isSearchOperator(String operator) {
		String actual = getSearchOperator();
		return (actual == null) ? false : actual.equals(operator);
	}

	/**
	 * 获取对象的id属性
	 * 
	 * 指定request
	 * 
	 * @return 参数值的整数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回0.
	 * @creator fangxiang @ Mar 17, 2009
	 */
	public int getId() {
		return RequestUtil.getParameterAsInt(this, PARAM_ID, 0);
	}

	/**
	 * 获取一组id.
	 * 
	 * @return 参数值的整数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回length为0的数组.
	 * @creator liushen @ May 3, 2009
	 */
	public int[] getIdArray() {
		String ids = RequestUtil.getParameterAndTrim(this, PARAM_ID_ARRAY);
		return StringHelper.split2IntArray(ids);
	}

	/**
	 * 从请求中提取检索字段
	 * 
	 * @return 如果检索词不存在, 则返回<code>null</code>.
	 * @creator liushen @ Mar 24, 2009
	 */
	public String getSearchField() {
		return RequestUtil.getParameterAsTrimed(this, PARAM_SEARCH_FIELD, null);
	}

	/**
	 * 
	 * @param field
	 * @return
	 * @creator liushen @ Apr 6, 2009
	 */
	public boolean isSearchField(String field) {
		String actual = getSearchField();
		return (actual == null) ? false : actual.equals(field);
	}

	/**
	 * 从请求中提取检索词.
	 * 
	 * @return 为避免页面显示检索词时显示"null", 所以如果检索词不存在时, 此方法返回<code>""</code>.
	 * @creator liushen @ Mar 24, 2009
	 */
	public String getSearchWord() {
		return RequestUtil.getParameterAsTrimed(this, PARAM_SEARCH_WORD, "");
	}

	/**
	 * 获取分页的页码
	 * 
	 * @return
	 * @creator fangxiang @ Mar 17, 2009
	 */
	public int getPageNo() {
		return RequestUtil
				.getParameterAsInt(this, PARAM_PAGENO, DEFAULT_PAGENO);
	}

	/**
	 * 获取分页的记录条数
	 * 
	 * @return
	 * @creator fangxiang @ Mar 17, 2009
	 */
	public int getPageSize() {
		return RequestUtil.getParameterAsInt(this, PARAM_PAGESIZE,
				DEFAULT_PAGESIZE);
	}

	/**
	 * 获取Form表单绑定对象的id属性.
	 * 
	 * 指定request
	 * 
	 * @return 参数值的整数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回0.
	 * @creator liushen @ Mar 26, 2009
	 */
	public int getFormId() {
		return RequestUtil.getParameterAsInt(this, "element.id", 0);
	}

	/**
	 * 
	 * @param view
	 * @return
	 * @since fangxiang @ Apr 22, 2010
	 */
	public String buildView(String view) {
		return view;
	}

	/**
	 * 
	 * @param viewMessage
	 * @return
	 * @since fangxiang @ Apr 22, 2010
	 */
	public String buildInfoTipView(String title, String message,
			ModelMap model, String flag) {
		model.addAttribute(title);
		model.addAttribute(message);
		return flag + "/" + INFO_TIP_VIEW;
	}

	/**
	 * 
	 * @param viewMessage
	 * @return
	 * @since fangxiang @ Apr 22, 2010
	 */
	public String buildErrorTipView(String title, String message,
			ModelMap model, String flag) {
		model.addAttribute(title);
		model.addAttribute(message);
		return flag + "/" + ERROR_TIP_VIEW;
	}

	/**
	 * 从主机名获取用户名，泛域名的支持
	 * 
	 * @param domain
	 * @return
	 * @since fangxiang @ Dec 13, 2010
	 */
	public String getUserNameFromHost(String domain) {
		// 如果没有配置泛域名的根域名，则不支持；
		LOG.debug("Domain:" + domain);
		if (StringHelper.isEmpty(domain)) {
			return null;
		}
		// 如果域名和配置的域名相同的话，则表示不支持泛域名；
		String serverName = this.getRequest().getServerName();
		LOG.debug("ServerName:" + serverName);
		if (serverName.equalsIgnoreCase(domain)) {
			return null;
		}
		// 如果主机里面包含有域名，获取前面的用户名
		String userName = null;
		if (serverName.endsWith(domain)) {
			int iFirstDot = serverName.indexOf('.');
			if (iFirstDot > 0) {
				userName = serverName.substring(0, iFirstDot);
				LOG.debug("UserName(" + userName + ") parsed from remoteHost("
						+ serverName + ") with domain(" + domain + ").");
			}
		}
		return userName;
	}

	/**
	 *
	 */
	private static final String INFO_TIP_VIEW = "infoTip";
	/**
	 *
	 */
	private static final String ERROR_TIP_VIEW = "errorTip";
	/**
	 *
	 */
	private static final String PARAM_PAGESIZE = "ps";
	/**
	 *
	 */
	private static final String PARAM_PAGENO = "pn";
	/**
	 *
	 */
	private static final String PARAM_ID = "id";
	/**
	 *
	 */
	private static final String PARAM_ID_ARRAY = "ids";
	/**
	 *
	 */
	private static final String PARAM_ORDER_FLAG = "oFlag";
	/**
	 *
	 */
	private static final String PRAM_ORDER_FIELD = "oField";
	/**
	 *
	 */
	private static final String PARAM_END_TIME = "endTime";
	/**
	 *
	 */
	private static final String PARAM_BEGIN_TIME = "beginTime";
	/**
	 *
	 */
	private static final String PARAM_TIME_FIELD = "tField";
	/**
	 *
	 */
	private static final String HQL_SEPARATOR = " ";
	/**
	 *
	 */
	private static final String ORDER_FLAG_DESC = "DESC";
	/**
	 *
	 */
	private static final String ORDER_FLAG_ASC = "ASC";
	/**
	 *
	 */
	private static final String PARAM_SEARCH_WORD = "sWord";
	/**
	 *
	 */
	private static final String PARAM_SEARCH_FIELD = "sField";
	/**
	 *
	 */
	private static final String DEFAULT_ORDER_BY = PARAM_ID + HQL_SEPARATOR
			+ ORDER_FLAG_DESC;
}
