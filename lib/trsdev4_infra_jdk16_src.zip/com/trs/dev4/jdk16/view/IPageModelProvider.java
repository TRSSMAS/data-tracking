/*
 * Created: fangxiang@Nov 3, 2010 9:24:04 PM
 */
package com.trs.dev4.jdk16.view;

import org.springframework.ui.ModelMap;

/**
 * 由Service层实现，用于提供Action的Model数据<br>
 * 
 */
public interface IPageModelProvider {

	/**
	 * 产生数据并放到ModelMap
	 * 
	 * @param request
	 * @param model
	 * @since fangxiang @ Nov 3, 2010
	 */
	public void generate(RequestWrapper request, ModelMap model);

	/**
	 * 是否可以缓存，true表示可以，false表示不可以
	 * 
	 * @return
	 * @since fangxiang @ Nov 30, 2010
	 */
	public boolean canCache();
}
