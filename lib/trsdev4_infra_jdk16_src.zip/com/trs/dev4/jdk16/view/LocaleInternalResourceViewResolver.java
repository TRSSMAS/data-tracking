/*
 * Created: fangxiang@Apr 21, 2010 7:50:50 PM
 */
package com.trs.dev4.jdk16.view;

import java.util.Locale;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

/**
 * 实现支持Locale的ViewResolver
 * 
 * @creator
 * 
 */
public class LocaleInternalResourceViewResolver extends
		InternalResourceViewResolver {

	/**
	 *
	 */
	private static final Logger LOG = Logger
			.getLogger(LocaleInternalResourceViewResolver.class);

	/**
	 *
	 */
	public LocaleInternalResourceViewResolver() {
	}

	/**
	 * 根据locale重新构造View
	 * 
	 * @param viewName
	 *            视图名称
	 * @param locale
	 *            语言
	 * @return 与locale相关的View
	 * 
	 * @since fangxiang @ Apr 21, 2010
	 */
	private String buildViewName(String viewName, Locale locale) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Before buildViewName:" + locale + "/" + viewName + ","
					+ super.getRequestContextAttribute());
		}
		Locale workingLocale = Locale.SIMPLIFIED_CHINESE;
		if (Locale.CHINA.equals(locale) || Locale.CHINESE.equals(locale)
				|| Locale.TAIWAN.equals(locale)) {
			workingLocale = Locale.SIMPLIFIED_CHINESE;
		} else if (Locale.ENGLISH.equals(locale) || Locale.UK.equals(locale)
				|| Locale.CANADA.equals(locale) || Locale.US.equals(locale)) {
			workingLocale = Locale.US;
		} else {
			workingLocale = Locale.SIMPLIFIED_CHINESE;
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("After buildViewName:" + workingLocale + "/" + viewName);
		}
		return Locale.SIMPLIFIED_CHINESE + "/" + viewName;
	}

	/**
	 * @see org.springframework.web.servlet.view.UrlBasedViewResolver#loadView(java.lang.String,
	 *      java.util.Locale)
	 * @since fangxiang @ Apr 21, 2010
	 */
	@Override
	protected View loadView(String viewName, Locale locale) throws Exception {
		return super.loadView(buildViewName(viewName, locale), locale);
	}

}
