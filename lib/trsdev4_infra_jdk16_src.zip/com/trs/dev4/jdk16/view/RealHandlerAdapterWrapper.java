package com.trs.dev4.jdk16.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerAdapter;
import org.springframework.web.servlet.ModelAndView;

/**
 * 对系统提供的HandlerAdapter做了一层包装，为装饰者模式的类，<br>
 * 包装HttpServletRequest类型的参数为com.trs.dev4.jdk16.view.RequestWrapper类型，<br>
 * 而RequestWrapper则增加了常用的一些接口，如getSearchFilter等 职责: <br>
 * 
 */
public class RealHandlerAdapterWrapper implements HandlerAdapter {

	HandlerAdapter handlerAdapter = null;

	public RealHandlerAdapterWrapper(HandlerAdapter adapter) {
		handlerAdapter = adapter;
	}

	public HandlerAdapter getHandlerAdapter() {
		return handlerAdapter;
	}

	@Override
	public long getLastModified(HttpServletRequest request, Object handler) {
		return getHandlerAdapter().getLastModified(request, handler);
	}

	@Override
	public boolean supports(Object handler) {
		return getHandlerAdapter().supports(handler);
	}

	@Override
	public ModelAndView handle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		try {
			RequestWrapper requestWrapper = new RequestWrapper(request);
			requestWrapper.setIgnoreCase(true);
			ModelAndView result = getHandlerAdapter().handle(requestWrapper, response, handler);
			return result;
		} finally {
			//
		}
	}
}
