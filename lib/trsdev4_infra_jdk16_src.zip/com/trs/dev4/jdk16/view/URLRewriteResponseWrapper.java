/**
 * 
 */
package com.trs.dev4.jdk16.view;

import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

/**
 * @author Administrator
 * 
 */
public class URLRewriteResponseWrapper extends HttpServletResponseWrapper {

	private PrintWriter contentWriter;
	private CharArrayWriter output;

	public URLRewriteResponseWrapper(HttpServletResponse response) {
		super(response);
		output = new CharArrayWriter();
		contentWriter = new PrintWriter(output);
	}

	@Override
	public void finalize() throws Throwable {
		super.finalize();
		output.close();
		contentWriter.close();
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Sep 27, 2011
	 */
	public String getContent() {
		contentWriter.flush(); // 刷新该流的缓冲，详看java.io.Writer.flush()
		return output.toString();
	}

	// 覆盖getWriter()方法，使用我们自己定义的Writer
	@Override
	public PrintWriter getWriter() throws IOException {
		return contentWriter;
	}

	public void close() throws IOException {
		contentWriter.close();
	}
}
