/*
 * Created: lichuanjiao@2010-9-8 下午04:34:27
 */
package com.trs.dev4.jdk16.file.impl;

import java.io.File;
import java.util.List;

import com.trs.dev4.jdk16.utils.FileUtil;

/**
 * 职责: 本地目录管理<br>
 * 
 */
public class LocalDirectory extends BaseDirectory {

	private ConnectionInfo connectionInfo;

	LocalDirectory(ConnectionInfo connectionInfo) {
		this.connectionInfo = connectionInfo;
	}


	/**
	 * @see com.trs.dev4.jdk16.file.IDirectory#getFreeSpace()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public long getFreeSpace() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return 0;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IDirectory#getTotalSpace()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public long getTotalSpace() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return 0;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IDirectory#getUsableSpace()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public long getUsableSpace() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return 0;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IDirectory#list()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public String[] list() {
		List<File> files = FileUtil.listFilesInDir(new File(connectionInfo
				.getFile()), false);
		int fileLen = files.size();
		String[] strFiles = new String[fileLen];
		for (int i = 0; i < fileLen; i++) {
			strFiles[i] = files.get(i).getPath();
		}
		return strFiles;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IDirectory#list(java.lang.String)
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public String[] list(String fileExt) {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canExecute()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public boolean canExecute() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return false;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canRead()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public boolean canRead() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return false;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canWrite()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public boolean canWrite() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return false;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getAbsolutePath()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public String getAbsolutePath() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getName()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public String getName() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getParent()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public String getParent() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#isHidden()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public boolean isHidden() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return false;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#lastModified()
	 * @since lichuanjiao @ 2010-9-8
	 */
	@Override
	public long lastModified() {
		// TODO lichuanjiao@2010-9-8 下午04:34:28: Auto-generated method stub
		return 0;
	}

}
