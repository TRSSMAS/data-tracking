/*
 * Created: lichuanjiao@2010-9-7 上午10:37:36
 */
package com.trs.dev4.jdk16.file.impl;

import java.util.Calendar;

import org.apache.commons.net.ftp.FTPFile;

/**
 * FTP文件处理实现; 基于Apache Commons Net.<br>
 * 
 */
public class FtpFileImpl extends BaseFile {

	private FTPFile ftpFile;
	
	/**
	 * 
	 */
	public FtpFileImpl(FTPFile ftpFile) {
		this.ftpFile = ftpFile;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFile#length()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public long length() {
		return ftpFile.getSize();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canExecute()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public boolean canExecute() {
		return ftpFile.hasPermission(FTPFile.USER_ACCESS,
				FTPFile.EXECUTE_PERMISSION);
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canRead()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public boolean canRead() {
		return ftpFile.hasPermission(FTPFile.USER_ACCESS,
				FTPFile.READ_PERMISSION);
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#canWrite()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public boolean canWrite() {
		return ftpFile.hasPermission(FTPFile.USER_ACCESS,
				FTPFile.WRITE_PERMISSION);
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getAbsolutePath()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public String getAbsolutePath() {
		// TODO lichuanjiao@2010-9-7 上午10:37:37: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getName()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public String getName() {
		return ftpFile.getName();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#getParent()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public String getParent() {
		// TODO lichuanjiao@2010-9-7 上午10:37:37: Auto-generated method stub
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#isHidden()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public boolean isHidden() {
		// TODO lichuanjiao@2010-9-7 上午10:37:37: Auto-generated method stub
		return false;
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#lastModified()
	 * @since lichuanjiao @ 2010-9-7
	 */
	@Override
	public long lastModified() {
		Calendar timestamp = ftpFile.getTimestamp();
		return timestamp == null ? 0 : timestamp.getTimeInMillis();
	}

	/**
	 * @see com.trs.dev4.jdk16.file.IFileResource#isFolder()
	 * @since liushen @ Apr 15, 2011
	 */
	@Override
	public boolean isFolder() {
		return ftpFile.isDirectory();
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Mar 29, 2011
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append(" rawListStr: ").append(ftpFile.getRawListing());
		return sb.toString();
	}


}
