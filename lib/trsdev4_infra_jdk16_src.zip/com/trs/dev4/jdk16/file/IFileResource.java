/*
 * Created: liushen@Jun 8, 2010 9:44:06 AM
 */
package com.trs.dev4.jdk16.file;

/**
 * {@link IDirectory}和 {@link IFile} 共同的父接口， 封装文件和目录的共同属性. <br>
 * 
 */
public interface IFileResource {

	/**
	 * 能否执行；对于目录来说，就是是否可列文件.
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	boolean canExecute();

	/**
	 * 能否读取。
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	boolean canRead();

	/**
	 * 能否写入。
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	boolean canWrite();

	/**
	 * 完整路径。
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	String getAbsolutePath();

	/**
	 * 文件名或目录名（不含父目录）。
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	String getName();

	/**
	 * 获取父目录路径.
	 * 
	 * @return 表示父目录路径的字符串； 如果不存在父目录则返回<code>null</code>
	 * @since liushen @ Jun 8, 2010
	 */
	String getParent();

	/**
	 * 是否隐藏。
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	boolean isHidden();

	/**
	 * 最后修改时间.
	 * 
	 * @since liushen @ Jun 8, 2010
	 */
	long lastModified();

	/**
	 * 生成JSON串.
	 * 
	 * @return
	 * @since liushen @ Apr 6, 2011
	 */
	String toJSON();

	/**
	 * 是否为目录.
	 * 
	 * @since liushen @ Apr 15, 2011
	 */
	boolean isFolder();

}
