/*
 * Created: liushen@Apr 6, 2011 2:57:28 PM
 */
package com.trs.dev4.jdk16.file;

/**
 * 文件流操作的进度监听器. <br>
 * 
 */
public interface IProgressListener {

	/**
	 * 
	 * @param totalTransferred
	 *            已经传输了多少
	 * @param transferred
	 *            本次传输了多少
	 * @param totalSize
	 *            总大小
	 * @since liushen @ Apr 6, 2011
	 */
	void bytesTransferred(long totalTransferred, int transferred, long totalSize);

}
