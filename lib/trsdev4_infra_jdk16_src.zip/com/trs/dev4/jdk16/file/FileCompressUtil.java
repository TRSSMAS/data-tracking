/*
 * Created: liushen@May 16, 2010 2:19:20 AM
 */
package com.trs.dev4.jdk16.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.trs.dev4.jdk16.exception.WrappedException;
import com.trs.dev4.jdk16.utils.FileUtil;

/**
 * 文件压缩和解压的便捷工具类（zip, tar.gz, tar.bz2等标准格式），名称待定. <br>
 * 
 */
public class FileCompressUtil {
	
	public static File zip(File folder) {
		// These are the files to include in the ZIP file
		List<File> lstFiles = FileUtil.listFilesInDir(folder, true);

		// Create a buffer for reading the files
		byte[] buf = new byte[1024];

		try {
			// Create the ZIP file
			File zipFile = new File(folder.getParent(), folder.getName()
					+ ".zip");
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(
					zipFile));

			// Compress the files
			for (int i = 0; i < lstFiles.size(); i++) {
				File file = lstFiles.get(i);
				FileInputStream in = new FileInputStream(file);

				// Add ZIP entry to output stream.
				out.putNextEntry(new ZipEntry(file.getName()));

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				// Complete the entry
				out.closeEntry();
				in.close();
			}

			// Complete the ZIP file
			out.close();
			return zipFile;
		} catch (IOException e) {
			throw new WrappedException(e);
		}
	}

}
