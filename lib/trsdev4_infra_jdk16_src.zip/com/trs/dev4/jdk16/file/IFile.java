/*
 * Created: liushen@Jun 8, 2010 9:44:55 AM
 */
package com.trs.dev4.jdk16.file;

/**
 * 各类本地文件、远程文件的统一接口，便于统一获取信息，以及其他处理. <br>
 * 注：增删移等写入操作，由基于此接口的工具类统一提供，不应在该接口中直接提供！
 */
public interface IFile extends IFileResource {

	/**
	 * 文件大小.
	 * 
	 * @return 字节数
	 * @since liushen @ Jun 8, 2010
	 */
	long length();

	/**
	 * 获取文件扩展名.
	 * 
	 * @return 文件扩展名(不含.)；如果没有扩展名则返回<code>null</code>.
	 * @since liushen @ Jun 8, 2010
	 */
	String getExtensionName();

	// /**
	// * 获取文件的输入流
	// *
	// * @return 输入流
	// * @since lichuanjiao @ 2010-9-10
	// */
	// InputStream getInputStream();
	//
	// /**
	// * 获取文件的输出流
	// *
	// * @return 输出流
	// * @since lichuanjiao @ 2010-9-12
	// */
	// OutputStream getOutputStream();

}
