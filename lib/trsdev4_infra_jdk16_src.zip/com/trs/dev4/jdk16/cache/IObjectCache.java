/*
 * Created: liushen@Mar 31, 2010 2:09:14 PM
 */
package com.trs.dev4.jdk16.cache;

/**
 * 对象缓存.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public interface IObjectCache<K, V> {

	/**
	 * 向缓存中添加对象.
	 * 
	 * @param key
	 *            缓存的键
	 * @param value
	 *            要缓存的对象
	 */
	void put(K key, V value);

	/**
	 * 获取缓存对象.
	 * 
	 * @param key
	 *            缓存的键
	 * @return 缓存的对象
	 */
	V get(K key);

	/**
	 * 收回指定的缓存对象，从缓存中清除；通过键指定。
	 * 
	 * @param key
	 *            缓存的键
	 * @return 缓存的对象 如果键已经被收回，再次调用该方法则返回<code>null</code>.
	 */
	V evict(K key);

	/**
	 * 清空缓存.
	 */
	void clear();

}
