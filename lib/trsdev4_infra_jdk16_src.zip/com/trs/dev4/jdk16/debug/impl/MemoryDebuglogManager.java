/*
 * Created: fangxiang@Nov 26, 2010 8:40:33 AM
 */
package com.trs.dev4.jdk16.debug.impl;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.debug.Debuglog;
import com.trs.dev4.jdk16.debug.IDebuglogManager;
import com.trs.dev4.jdk16.model.BaseManager;

/**
 *
 */
@Service
public class MemoryDebuglogManager extends BaseManager<Debuglog> implements
		IDebuglogManager {
	/**
	 *
	 */
	private final static Logger logger = Logger
			.getLogger(MemoryDebuglogManager.class);
	/**
	 *
	 */
	private Debuglog[] debuglogs = null;
	/**
	 *
	 */
	private final static int SIZE = 200;
	/**
	 *
	 */
	private int currentIndex = 0;

	/**
	 *
	 */
	public MemoryDebuglogManager() {
		debuglogs = new Debuglog[SIZE];
		for (int i = 0; i < debuglogs.length; i++) {
			debuglogs[i] = new Debuglog();
		}
	}
	/**
	 * @see com.trs.dev4.jdk16.model.BaseManager#listAllObjects()
	 * @since fangxiang @ Nov 26, 2010
	 */
	@Override
	public List<Debuglog> listAllObjects() {
		return Arrays.asList(debuglogs);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.BaseManager#saveOrUpdate(com.trs.dev4.jdk16.model.IEntity)
	 * @since fangxiang @ Nov 26, 2010
	 */
	@Override
	public void saveOrUpdate(Debuglog debuglog) {
		synchronized (debuglogs) {
			currentIndex = currentIndex % SIZE;
			logger.debug("CurrentIndex(" + currentIndex + ")'s log:" + debuglog);
			debuglogs[currentIndex] = debuglog;
			currentIndex = currentIndex + 1;
		}
	}

}
