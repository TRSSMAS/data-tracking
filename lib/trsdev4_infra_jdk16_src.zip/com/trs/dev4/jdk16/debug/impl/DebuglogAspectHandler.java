/*
 * Created: fangxiang@Nov 25, 2010 10:45:31 PM
 */
package com.trs.dev4.jdk16.debug.impl;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.trs.dev4.jdk16.debug.Debug;
import com.trs.dev4.jdk16.debug.Debuglog;
import com.trs.dev4.jdk16.debug.IDebuglogManager;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: <br>
 *
 */
@Aspect
@Component
public class DebuglogAspectHandler {

	@Autowired
	private IDebuglogManager debuglogManager;

	protected static Logger logger = Logger
			.getLogger(DebuglogAspectHandler.class);

	/**
	 * 切入点：@LogMe注解的方法，其中@LogMe被当成参数处理
	 */
	@Pointcut(value = "@annotation(debug)", argNames = "debug")
	public void annolog(Debug debug) {
	}

	/**
	 * AOP的Around拦截方式，在原执行逻辑前后介入记录操作日志的逻辑
	 * 
	 * @param joinPoint
	 *            被切入点命中的方法
	 * @param logMeAnno
	 *            切入点方法上定义的@LogMe注解
	 * @return 返回原方法正常执行的结果
	 * @throws Throwable
	 * @since liuyou @ 2010-5-23
	 */
	@Around(value = "annolog(debug))", argNames = "debug")
	public Object aroundAnnoLog(ProceedingJoinPoint joinPoint, Debug debug)
			throws Throwable {
		if (logger.isDebugEnabled()) {
			logger.debug("aroundAnnoLog(method:" + joinPoint.getSignature()
					+ " is method signature:"
					+ (joinPoint.getSignature() instanceof MethodSignature)
					+ ",args:" + StringHelper.join(joinPoint.getArgs()));
		}
		MethodSignature methodSignature = (MethodSignature) joinPoint
				.getSignature();
		Method method = methodSignature.getMethod();
		//
		long lStartTime = System.currentTimeMillis();
		Throwable error = null;
		// 创建新记录
		Debuglog debuglog = new Debuglog();
		debuglog.setCreatedTime(DateUtil.getCurrentTimeMillis());
		debuglog.setClassName(joinPoint.getTarget().getClass().getName());
		debuglog.setMethodName(method.getName());
		debuglog.setMethodSignature(methodSignature.toLongString());
		debuglog.setParameterNames("");
		debuglog.setArguments(StringHelper.join(joinPoint.getArgs()));
		try {
			Object object = execute(joinPoint);
			if (object != null) {
				debuglog.setReturnValue(object.toString());
			}
			debuglog.setResult("SUCCESSED");
			return object;
		} catch (Throwable tx) {
			logger.error("LOG error:" + tx.getMessage(), tx);
			error = tx;
			//
			debuglog.setResult("FAILED");
			String errorMessage = error.getMessage();
			if (errorMessage != null && errorMessage.length() > 2000) {
				errorMessage = StringHelper.adjustLength(errorMessage, 1800);
			}
			debuglog.setErrorMessage(errorMessage);
			//
			throw tx;
		} finally {
			long lEndTime = System.currentTimeMillis();
			debuglog.setElapsed((int) (lEndTime - lStartTime));
			debuglogManager.saveOrUpdate(debuglog);
		}
	}

	/**
	 * 执行原方法
	 * 
	 * @param joinPoint
	 * @return
	 * @throws Throwable
	 * @since liuyou @ 2010-5-23
	 */
	private Object execute(ProceedingJoinPoint joinPoint) throws Throwable {
		return joinPoint.proceed(joinPoint.getArgs());
	}
}
