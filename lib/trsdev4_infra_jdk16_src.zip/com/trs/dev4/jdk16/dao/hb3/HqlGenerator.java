/*
 * Created: liushen@May 4, 2010 7:56:05 AM
 */
package com.trs.dev4.jdk16.dao.hb3;

import java.util.Collection;

import org.hibernate.Query;

import com.trs.dev4.jdk16.dao.Condition;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 生成SearchFilter对应的SQL语句. <br>
 * 
 */
public class HqlGenerator {

	private SearchFilter sf;

	/**
	 * 
	 */
	public HqlGenerator(SearchFilter sf) {
		this.sf = sf;
	}

	/**
	 * @return the {@link #sf}
	 */
	public SearchFilter getSearchFilter() {
		return sf;
	}

	/**
	 * 
	 * @return
	 */
	public String buildWhere() {
		int totalConditions = sf.getTotalConditions();
		if (totalConditions <= 0) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		sb.append(" where ");
		for (int i = 0; i < totalConditions; i++) {
			Condition condition = sf.getCondition(i);
			sb.append(condition.getField()).append(' ')
					.append(condition.getOp());
			if (condition.needBindCollectionParam()) {
				sb.append(" (:").append(condition.getBindName()).append(')');
			} else if (condition.isBetweenCondition()) {
				sb.append(" :").append(condition.getBindName()).append("lo");
				sb.append(" and :").append(condition.getBindName()).append("hi");
			} else if (condition.needBindOneParam()) {
				sb.append(" :").append(condition.getBindName());
			}
			if (i < totalConditions - 1) {
				// TODO: liushen@Dec 20, 2011: 如支持Or需考虑括号优先级等
				sb.append(" and ");
			}
		}
		return sb.toString();
	}

	/**
	 * 
	 * @param query
	 * @since liushen @ May 4, 2010
	 */
	public void bindParameters(Query query) {
		bindParameters(query, sf);
	}

	/**
	 * 
	 * @param query
	 * @param sf
	 */
	@SuppressWarnings("rawtypes")
	static void bindParameters(Query query, SearchFilter sf) {
		final int totalConditions = sf.getTotalConditions();
	
		for (int i = 0; i < totalConditions; i++) {
			com.trs.dev4.jdk16.dao.Condition condition = sf.getCondition(i);
			Object value = condition.getValue();
			if (condition.isLikeCondition()) {
				query.setParameter(condition.getBindName(),
						'%' + value.toString() + '%');
			} else if (condition.needBindCollectionParam()) {
				if (value.getClass().isArray()) {
					query.setParameterList(condition.getBindName(),
							(Object[]) value);
				} else {
					query.setParameterList(condition.getBindName(),
							(Collection) value);
				}
			} else if (condition.isBetweenCondition()) {
				query.setParameter(condition.getBindName() + "lo", value);
				query.setParameter(condition.getBindName() + "hi", condition
						.getValue2());
			} else if (condition.needBindOneParam()) {
				query.setParameter(condition.getBindName(), value);
			}
		}
	}

}
