/*
 * Created: TRS@Feb 9, 2012 3:50:53 PM
 */
package com.trs.dev4.jdk16.dao.hb3;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

/**
 * 职责: <br>
 *
 */
public class SharingDataSourceFactory implements DataSource {
	/**
	 * 主数据源
	 */
	private DataSource masterDataSource;

	/**
	 * 启动数据源管理
	 * 
	 * @since TRS @ Feb 9, 2012
	 */
	public void start() {
	}

	/**
	 * 停止数据源管理
	 * 
	 * @since TRS @ Feb 9, 2012
	 */
	public void close() {

	}

	/**
	 * @see javax.sql.CommonDataSource#getLogWriter()
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public PrintWriter getLogWriter() throws SQLException {
		return masterDataSource.getLogWriter();
	}

	/**
	 * @see javax.sql.CommonDataSource#getLoginTimeout()
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public int getLoginTimeout() throws SQLException {
		return masterDataSource.getLoginTimeout();
	}

	/**
	 * @see javax.sql.CommonDataSource#setLogWriter(java.io.PrintWriter)
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public void setLogWriter(PrintWriter printWriter) throws SQLException {
		masterDataSource.setLogWriter(printWriter);
	}

	/**
	 * @see javax.sql.CommonDataSource#setLoginTimeout(int)
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public void setLoginTimeout(int loginTimeout) throws SQLException {
		masterDataSource.setLoginTimeout(loginTimeout);
	}

	/**
	 * @see java.sql.Wrapper#isWrapperFor(java.lang.Class)
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public boolean isWrapperFor(Class<?> clazz) throws SQLException {
		return masterDataSource.isWrapperFor(clazz);
	}

	/**
	 * @see java.sql.Wrapper#unwrap(java.lang.Class)
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public <T> T unwrap(Class<T> clazz) throws SQLException {
		return masterDataSource.unwrap(clazz);
	}

	/**
	 * @see javax.sql.DataSource#getConnection()
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public Connection getConnection() throws SQLException {
		return masterDataSource.getConnection();
	}

	/**
	 * @see javax.sql.DataSource#getConnection(java.lang.String,
	 *      java.lang.String)
	 * @since TRS @ Feb 9, 2012
	 */
	@Override
	public Connection getConnection(String userName, String password) throws SQLException {
		return masterDataSource.getConnection(userName, password);
	}
}
