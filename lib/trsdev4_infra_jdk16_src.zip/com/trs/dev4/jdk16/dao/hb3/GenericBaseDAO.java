/*
 * updated: liushen @ Mar 17, 2009
 */
package com.trs.dev4.jdk16.dao.hb3;

import java.io.Serializable;
import java.sql.Connection;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.metadata.ClassMetadata;
import org.hibernate.persister.entity.AbstractEntityPersister;
import org.hibernate.persister.entity.SingleTableEntityPersister;
import org.hibernate.tuple.entity.EntityMetamodel;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.trs.dev4.jdk16.dao.DBSummary;
import com.trs.dev4.jdk16.dao.DBSummaryUtil;
import com.trs.dev4.jdk16.dao.HQLBuilder;
import com.trs.dev4.jdk16.dao.HQLBuilder.Condition;
import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.DAOException;
import com.trs.dev4.jdk16.exception.ExceptionUtil;
import com.trs.dev4.jdk16.utils.AssertUtil;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 领域对象数据持久化基类.
 * 
 * @see com.trs.dev4.jdk16.dao.IAccessorTest
 */
public class GenericBaseDAO<T> extends HibernateDaoSupport implements
		IAccessor<T> {

	private final static Logger LOG = Logger.getLogger(GenericBaseDAO.class);

	/**
	 *
	 */
	public GenericBaseDAO(Class<T> classType) {
		this.classType = classType;
		if (LOG.isDebugEnabled()) {
			LOG.debug("ClassType(" + classType + ")DAO created,callers: " + ExceptionUtil.getMainCaller(5));
		}
	}

	/**
	 * 
	 */
	protected GenericBaseDAO() {
		if (LOG.isDebugEnabled()) {
			LOG.debug("no-argument constructor invoked, callers: " + ExceptionUtil.getMainCaller(5));
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#insert(java.lang.Object)
	 */
	@Override
	public Serializable insert(T object) throws DAOException {
		AssertUtil.notNull(object, "cannot insert null object!");

		Session session = null;
		Transaction tx = null;
		Serializable serialedId = null;
		//
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			// if (session instanceof )
			serialedId = session.save(object);
			tx.commit();
			return serialedId;
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			LOG.error("save " + getClassType() + " [" + object + "]", ex);
			throw new DAOException("save " + getClassType() + " [" + object + "]", ex);
		} finally {
			releaseHibernateSession(session);
			//
			timer.stopWatch(object, "insert");
		}

	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#delete(java.lang.Object)
	 */
	@Override
	public void delete(T object) throws DAOException {
		if (object == null) {
			throw new DAOException("cannot delete null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		try {
			session = this.getHibernateSession();
			tx = session.beginTransaction();
			session.delete(object);
			tx.commit();
		} catch (Throwable e) {
			LOG.error("obj=" + object, e);
			Hb3Util.rollback(tx);
			throw new DAOException(e);
		} finally {
			this.releaseHibernateSession(session);
			timer.stopWatch(object, "delete");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#update(java.lang.Object)
	 */
	@Override
	public void update(T object) throws DAOException {
		if (object == null) {
			throw new DAOException("cannot update null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		//
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			session.saveOrUpdate(object);
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			LOG.error("saveOrUpdate " + getClassType() + " [" + object + "]", ex);
			throw new DAOException("saveOrUpdate " + getClassType() + " [" + object + "]", ex);
		} finally {
			releaseHibernateSession(session);
			//
			timer.stopWatch(object, "update");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getObject(java.lang.String)
	 */
	@Override
	public T getObject(int objectId) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		try {
			return this.getHibernateTemplate().get(getClassType(),
					new Integer(objectId));
		} catch (Throwable ex) {
			LOG.error("get " + getClassType() + ", id: " + objectId, ex);
			throw new DAOException("get " + getClassType() + ", id: " + objectId, ex);
		} finally {
			timer.stopWatch(objectId);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listObjects()
	 */
	@Override
	public List<T> listObjects() throws DAOException {
		// liushen@Feb 13, 2012: 设定上限，避免大数据量下内存溢出
		SearchFilter sf = SearchFilter.getNoPagedFilter();
		return listObjects(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listObjects(java.lang.String,
	 *      java.lang.Object)
	 * @creator liushen @ Jan 25, 2010
	 */
	@Override
	public List<T> listObjects(String fieldName, Object value)
			throws DAOException {
		SearchFilter sf = SearchFilter.getNoPagedFilter();
		sf.addEqCondition(fieldName, value);
		return listObjects(sf);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#listObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<T> listObjects(SearchFilter sf) throws DAOException {
		StringBuilder sb = buildFromAndWhere(sf);
		sb = appendOrderbyClause(sf, sb);
		Session session = null;
		Query query = null;
		//
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		try {
			session = this.getHibernateSession();
			query = session.createQuery(sb.toString());
			HqlGenerator.bindParameters(query, sf);
			if (sf.getMaxResults() > 0) {
				query.setMaxResults(sf.getMaxResults());
			}
			List<T> list = query.list();
			// LOG.info("hibernate query: " + Hb3Util.getQueryInfoForDump(query)
			// + ", result size: " + list.size());
			timer.stopWatch(sf);
			return list;
		} catch (Throwable ex) {
			LOG.error("query " + getClassType() + " [" + sb + "]", ex);
			timer.stopWatch(sf, ex);
			throw new DAOException("query " + getClassType() + " [" + sb + "]", ex);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#pagedAll()
	 * @creator liushen @ Feb 15, 2010
	 */
	@Override
	public PagedList<T> pagedAll() throws DAOException {
		return pagedObjects(SearchFilter.getDefault());
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#pagedObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public PagedList<T> pagedObjects(SearchFilter sf) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		StringBuilder sb = buildFromAndWhere(sf);
		try {
			int total = total(sf);
			sb = appendOrderbyClause(sf, sb);
			List<T> objects = getPageItems(sb.toString(), sf);
			return new PagedList<T>(objects, sf.getStartPos()
					/ sf.getMaxResults(), sf.getMaxResults(), total);
		} catch (DAOException ex) {
			LOG.error("query " + getClassType() + " [" + sb + "]", ex);
			throw ex;
		} catch (Throwable ex) {
			LOG.error("query " + getClassType() + " [" + sb + "]", ex);
			throw new DAOException(ex);
		} finally {
			timer.stopWatch(sf);
		}
	}

	/**
	 *
	 * @param query
	 * @param startPos
	 * @param maxResults
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<T> getPageItems(String whereExpression, SearchFilter sf) {
		return (List<T>) _getPageItems(whereExpression, sf);
	}

	/**
	 * @param whereExpression
	 * @param sf
	 * @return
	 * @since fangxiang @ Jan 8, 2011
	 */
	private List<?> _getPageItems(String whereExpression, SearchFilter sf) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		Session session = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(whereExpression);
			HqlGenerator.bindParameters(query, sf);
			query.setFirstResult(sf.getStartPos());
			if (sf.getMaxResults() > 0) {
				query.setMaxResults(sf.getMaxResults());
			}
			List<?> list = query.list();
			timer.stopWatch(sf);
			return list;
		} catch (Throwable ex) {
			LOG.error("query " + getClassType() + " [" + sf + "]", ex);
			timer.stopWatch(sf, ex);
			if (ex instanceof DAOException) {
				throw (DAOException) ex;
			} else {
				throw new DAOException(ex);
			}
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @param sf
	 * @param sb
	 */
	private StringBuilder appendOrderbyClause(SearchFilter sf, StringBuilder sb) {
		if (sf.getOrderBy() != null) {
			sb.append(" order by ").append(sf.getOrderBy());
		}
		return sb;
	}

	/**
	 * 构建from和where子句.
	 * 
	 */
	private StringBuilder buildFromAndWhere(SearchFilter sf) {
		return buildFromAndWhere(sf, null);
	}

	/**
	 * 构建from和where子句.
	 * 
	 */
	private StringBuilder buildFromAndWhere(SearchFilter sf, String selectFields) {
		StringBuilder sb = new StringBuilder(160);
		if (!StringHelper.isEmpty(selectFields)) {
			sb.append("select ").append(selectFields).append(" ");
		}
		sb.append("from ").append(this.getClassType().getName());
		sb.append(sf.buildWhere());
		return sb;
	}

	/**
	 * TODO liushen @ Apr 16, 2009: extract to {
	 * {@link HqlGenerator#bindParameters(Query, SearchFilter)} with same base!
	 *
	 * @param query
	 * @param parameters
	 * @creator fangxiang @ Mar 17, 2009
	 */
	static void bindParameters(Query query, List<Condition> parameters) {
		for (int i = 0; i < parameters.size(); i++) {
			Condition condition = parameters.get(i);
			try {
				// 支持HQLBuilder传入值为Object[]或Collection
				Object value = condition.getValue();
				if (value.getClass().isArray())
					query.setParameterList(condition.getField(),
							(Object[]) value);
				else if (Collection.class.isAssignableFrom(value.getClass()))
					query.setParameterList(condition.getField(),
							(Collection<?>) value);
				else
					query.setParameter(condition.getParameterName(), value);
			} catch (org.hibernate.HibernateException e) {
				LOG.error("query: " + query + "; condition: " + condition, e);
				throw e;
			}
		}
	}

	private String buildCountSQL(SearchFilter sf) {
		StringBuilder sCountExp = new StringBuilder(256);
		sCountExp.append("select count(*) ");
		sCountExp.append("from ").append(this.getClassType().getName());
		sCountExp.append(sf.buildWhere());
		return sCountExp.toString();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchInsert(T[])
	 */
	@Override
	public int batchInsert(T[] objects) throws DAOException {
		if (objects == null) {
			return -1;
		}
		int i = 0;
		int total = objects.length;
		for (; i < total; i++) {
			try {
				this.getHibernateTemplate().save(objects[i]);
			} catch (Throwable e) {
				throw new DAOException("batchInsert " + i + " of " + total + ": " + objects[i], e);
			}
		}
		return i;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchUpdate(com.trs.dev4.jdk16.dao.HQLBuilder)
	 */
	@Override
	public int batchUpdate(HQLBuilder builder) throws DAOException {
		return batchWithBuilder(builder);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchDelete(com.trs.dev4.jdk16.dao.HQLBuilder)
	 */
	@Override
	public int batchDelete(HQLBuilder builder) throws DAOException {
		return batchWithBuilder(builder);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#delete(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public int delete(SearchFilter searchFilter) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		StringBuilder sb = new StringBuilder("delete ");
		sb.append(buildFromAndWhere(searchFilter));
		Session session = null;
		Transaction tx = null;
		int count;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(sb.toString());
			HqlGenerator.bindParameters(query, searchFilter);
			tx = session.beginTransaction();
			count = query.executeUpdate();
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(searchFilter);
		}

		return count;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeNativeUpdateSQL(java.lang.String)
	 */
	@Override
	public int executeNativeUpdateSQL(String sql) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		Session session = null;
		Transaction tx = null;
		int result = 0;
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			result = session.createSQLQuery(sql).executeUpdate();
			tx.commit();
			return result;
		} catch (HibernateException e) {
			tx.rollback();
			throw new DAOException(e);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(sql);
		}
	}

	/**
	 * @param builder
	 * @return
	 */
	private int batchWithBuilder(HQLBuilder builder) {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		int count;
		String preparedHQL = "";
		try {
			session = getHibernateSession();
			preparedHQL = builder.getPreparedHQL();
			Query query = session.createQuery(preparedHQL);
			bindParameters(query, builder.getParameterValues());
			if (LOG.isDebugEnabled()) {
				LOG.debug("query: " + query.getQueryString() + "; params: "
						+ Arrays.toString(query.getNamedParameters())
						+ ", called by " + ExceptionUtil.getMainCaller());
			}
			tx = session.beginTransaction();
			count = query.executeUpdate();
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(preparedHQL);
		}

		return count;
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#exists(java.lang.String,
	 *      java.lang.Object)
	 */
	@Override
	public boolean exists(String field, Object value) throws DAOException {
		return exists(field, value, -1);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#findFirst(java.lang.String,
	 *      java.lang.Object)
	 * @since liushen @ Apr 22, 2010
	 */
	@Override
	public T findFirst(String field, Object value) throws DAOException {
		List<T> objects = listObjects(field, value);
		if (objects.size() == 0) {
			return null;
		}
		return objects.get(0);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#exists(java.lang.String,
	 *      java.lang.Object, int)
	 */
	@Override
	public boolean exists(String field, Object value, int excludedId)
			throws DAOException {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition(field, value);
		sf.addNotEqCondition("id", new Integer(excludedId));
		return (total(sf) != 0);
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#total()
	 */
	@Override
	public int total() throws DAOException {
		Session session = null;
		try {
			session = getHibernateSession();
			Query countQry = session.createQuery("select count(*) from "
					+ getClassType().getName());
			return Hb3Util.uniqueResultAsInt(countQry);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#total(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public int total(SearchFilter sf) {
		Session session = getHibernateSession();
		try {
			String countHQL = buildCountSQL(sf);
			Query countQry = session.createQuery(countHQL);
			HqlGenerator.bindParameters(countQry, sf);
			return Hb3Util.uniqueResultAsInt(countQry);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * HQL目前不能支持update ClassA set fieldX=fieldX+delta这种形式, 因此通过update table XX
	 * set fieldX=fieldX+delta这类SQL语句实现.
	 * 
	 * @see com.trs.dev4.jdk16.dao.IAccessor#deltaUpdate(java.lang.String, long,
	 *      int)
	 * @since liushen @ Apr 29, 2010
	 */
	@Override
	public int deltaUpdate(String field, long delta, int whichId) {
		if (delta == 0) {
			return 0;
		}
		// 构造+X还是-X
		String deltaExpression = (delta > 0) ? field + "+" + delta : field
				+ delta;
		// 拼SQL语句
		StringBuilder sb = new StringBuilder();
		sb.append("update ").append(getTableName()).append(" set ").append(
				field).append("=").append(deltaExpression);
		sb.append(" where ").append(getIdFieldName()).append("=").append(
				whichId);

		return executeNativeUpdateSQL(sb.toString());
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeQuery(java.lang.String)
	 * @creator liushen @ May 5, 2009
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<? extends Object> executeQuery(String hql) throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		try {
			session = getHibernateSession();
			Query query = session.createQuery(hql);
			return query.list();
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(hql);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getgetClassType()()
	 */
	@Override
	public Class<T> getClassType() {
		return this.classType;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getTableName()
	 * @since liushen @ Apr 29, 2010
	 */
	@Override
	public String getTableName() {
		ClassMetadata metadata = getHibernateClassMetadata();
		if (metadata instanceof SingleTableEntityPersister) {
			return ((SingleTableEntityPersister) metadata).getTableName();
		}
		throw new DAOException("ClassMetadata of " + getClassType()
				+ " is not a SingleTableEntityPersister, it's " + metadata);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#getIdFieldName()
	 * @since liushen @ Apr 29, 2010
	 */
	@Override
	public String getIdFieldName() {
		ClassMetadata metadata = getHibernateClassMetadata();
		return metadata.getIdentifierPropertyName();
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.dao.IAccessor#retriveDBSummary()
	 * @creator liushen @ Jun 1, 2009
	 */
	@SuppressWarnings("deprecation")
	@Override
	public DBSummary retriveDBSummary() {
		Session session = null;
		try {
			session = getHibernateSession();
			Connection conn = session.connection();
			return DBSummaryUtil.retriveSummary(conn);
		} catch (Throwable ex) {
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * @param session
	 * @throws HibernateException
	 */
	protected void releaseHibernateSession(Session session)
			throws HibernateException {
		if (session != null) {
			try {
				session.close();
			} catch (Throwable e) {
				LOG.error(e.getMessage(), e);
				throw new HibernateException(e.getMessage(), e);
			}
		}
	}

	/**
	 * @return
	 * @throws HibernateException
	 */
	protected Session getHibernateSession() throws HibernateException {
		return this.getSessionFactory().openSession();
	}

	// 以下为hibernate相关的方法，仅供诊断使用；接口中并没有这些方法的定义！
	/**
	 *
	 * @return
	 * @since liushen @ Mar 22, 2010
	 */
	public Map<String, ClassMetadata> getAllEntityClassMetadata() {
		SessionFactory sessionFactory = getSessionFactory();
		return Hb3Util.getAllEntityClassMetadata(sessionFactory);
	}

	/**
	 *
	 * @return
	 * @since liushen @ Jun 23, 2010
	 */
	public IdentifierGenerator getHibernateIdGenerator() {
		SessionFactory sessionFactory = getSessionFactory();
		return Hb3Util.getIdGenerator(sessionFactory, getClassType().getName());
	}

	/**
	 * @return
	 * @since liushen @ Apr 29, 2010
	 */
	ClassMetadata getHibernateClassMetadata() {
		Map<String, ClassMetadata> maps = getAllEntityClassMetadata();
		ClassMetadata metadata = maps.get(getClassType().getName());
		AssertUtil.notNull(metadata, "ClassMetadata of " + getClassType()
				+ " not exist.");
		return metadata;
	}

	/**
	 *
	 * @return
	 * @since liushen @ Jun 23, 2010
	 */
	EntityMetamodel getHibernateEntityMetamodel() {
		ClassMetadata metadata = getHibernateClassMetadata();
		if (false == metadata instanceof AbstractEntityPersister) {
			throw new DAOException("not a AbstractEntityPersister!");
		}
		AbstractEntityPersister persister = (AbstractEntityPersister) metadata;
		return persister.getEntityMetamodel();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#executeNativeUpdateSQL(java.lang.String[])
	 * @since fangxiang @ Jul 1, 2010
	 */
	@Override
	public int executeNativeUpdateSQL(String[] statements) {
		Session session = null;
		Transaction tx = null;
		int result = 0;
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			for (int i = 0; i < statements.length; i++) {
				result += session.createSQLQuery(statements[i]).executeUpdate();
			}
			tx.commit();
			return result;
		} catch (HibernateException e) {
			tx.rollback();
			throw new DAOException(e);
		} finally {
			releaseHibernateSession(session);
		}
	}

	/**
	 * 判断对象是否存在
	 * 
	 * @param obj
	 * @return
	 * @since fangxiang @ Oct 20, 2010
	 */
	public boolean exists(T obj) {
		return true;
	}

	/**
	 * 领域对象类型.
	 */
	private Class<T> classType;

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Jul 26, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString()).append(" (T=");
		builder.append(getClassType().getName());
		builder.append(")");
		return builder.toString();
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchDelete(T[])
	 * @since fangxiang @ Nov 16, 2010
	 */
	@Override
	public void batchDelete(T[] objects) throws DAOException {
		if (objects == null) {
			throw new DAOException("cannot delete null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		try {

			this.getHibernateTemplate().deleteAll(Arrays.asList(objects));
		} catch (Throwable ex) {
			LOG.error(ex.getMessage(), ex);
			throw new DAOException(ex);
		} finally {
			timer.stopWatch(objects, "delete");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchUpdate(T[])
	 * @since fangxiang @ Nov 16, 2010
	 */
	@Override
	public void batchUpdate(T[] objects) throws DAOException {
		this.batchUpdate(Arrays.asList(objects));
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.dao.IAccessor#batchUpdate(java.util.List)
	 */
	@Override
	public void batchUpdate(List<T> objects) throws DAOException {
		if (objects == null) {
			throw new DAOException("cannot update null object!");
		}
		QueryTimer timer = new QueryTimer(this.getClassType());
		Session session = null;
		Transaction tx = null;
		try {
			session = getHibernateSession();
			tx = session.beginTransaction();
			for (T entity : objects) {
				session.saveOrUpdate(entity);
			}
			session.flush();
			session.clear();
			tx.commit();
		} catch (Throwable ex) {
			Hb3Util.rollback(tx);
			LOG.error("fail to update:" + objects, ex);
			throw new DAOException(ex);
		} finally {
			releaseHibernateSession(session);
			timer.stopWatch(objects, "batchUpdate");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#truncate()
	 * @throws DAOException
	 * @since fangxiang @ Nov 16, 2010
	 */
	@Override
	public void truncate() throws DAOException {
		this.executeNativeUpdateSQL("TRUNCATE TABLE " + getTableName());
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IAccesor#findUnique(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public T findUnique(SearchFilter sf) {
		if (sf == null) {
			sf = SearchFilter.getDefault();
		}
		PagedList<T> entities = this.pagedObjects(sf);
		if (entities.getPageItems().size() > 1) {
			throw new DAOException("not unique " + this.getClassType().getName() + ",sf: " + sf);
		}
		return (entities.getPageItems().size() > 0) ? entities.get(0) : null;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IAccesor#findFirst(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public T findFirst(SearchFilter sf) {
		if (sf == null) {
			sf = SearchFilter.getDefault();
		}
		PagedList<T> entities = this.pagedObjects(sf);
		return (entities.getPageItems().size() > 0) ? entities.get(0) : null;
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#pagedObjectIds(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Jan 8, 2011
	 */
	@SuppressWarnings("unchecked")
	@Override
	public PagedList<Integer> pagedObjectIds(SearchFilter sf)
			throws DAOException {
		QueryTimer timer = new QueryTimer(this.getClassType());
		//
		StringBuilder sb = buildFromAndWhere(sf, "id");
		try {
			int total = total(sf);
			sb = appendOrderbyClause(sf, sb);
			List<Integer> objects = (List<Integer>) _getPageItems(
					sb.toString(), sf);
			return new PagedList<Integer>(objects,
					sf.getStartPos()
					/ sf.getMaxResults(), sf.getMaxResults(), total);
		} catch (DAOException ex) {
			LOG.error("query failed: [" + sb + "]", ex);
			throw ex;
		} catch (Throwable ex) {
			LOG.error("query failed: [" + sb + "]", ex);
			throw new DAOException(ex);
		} finally {
			timer.stopWatch(sf);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#update(int, java.util.Map)
	 * @since liushen @ Dec 2, 2011
	 */
	@Override
	public int update(int id, Map<String, Object> updatedFields) {
		// TODO liushen@Dec 2, 2011 2:33:28 PM: Auto-generated method stub
		if (CollectionUtil.isEmpty(updatedFields)) {
			// AssertUtil.notNullOrEmpty(objs, message)
			return 0;
		}
		HQLBuilder hqlBuilder = HQLBuilder.UPDATE(classType);
		for (String field : updatedFields.keySet()) {
			hqlBuilder.setNewValue(field, updatedFields.get(field));
		}
		hqlBuilder.addEqCondition("id", id);
		return batchWithBuilder(hqlBuilder);
	}

	/**
	 * @see com.trs.dev4.jdk16.dao.IAccessor#update(int, java.lang.String,
	 *      java.lang.Object)
	 * @since liushen @ Dec 2, 2011
	 */
	@Override
	public int update(int id, String field, Object value) {
		Map<String, Object> updatedFields = new HashMap<String, Object>();
		updatedFields.put(field, value);
		return update(id, updatedFields);
	}

}
