/*
 * Created: liushen@Jun 22, 2010 5:33:32 PM
 */
package com.trs.dev4.jdk16.dao.hb3;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

/**
 * 示例，仅用于验证该接口的相关机制；不能实际使用。 <br>
 * 
 */
public class PesduoIdGenerator implements IdentifierGenerator {

	/**
	 * @see org.hibernate.id.IdentifierGenerator#generate(org.hibernate.engine.SessionImplementor, java.lang.Object)
	 * @since liushen @ Jun 22, 2010
	 */
	@Override
	public Serializable generate(SessionImplementor session, Object object)
			throws HibernateException {
		System.out.println("=============== generate ===============");
		return null;
	}

}
