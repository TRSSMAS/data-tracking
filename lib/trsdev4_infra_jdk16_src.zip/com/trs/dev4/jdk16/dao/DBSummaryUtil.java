/*
 * Created: liushen@Jun 1, 2009 4:15:19 PM
 */
package com.trs.dev4.jdk16.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Properties;

import com.trs.dev4.jdk16.exception.DAOException;
import com.trs.dev4.jdk16.exception.DBConnectException;

/**
 * 测试数据库连接并返回信息.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class DBSummaryUtil extends DBSummary {

	/**
	 * 
	 * @param driver
	 * @param url
	 * @param user
	 * @param pwd
	 * @return
	 * @since liushen @ Jul 1, 2011
	 */
	public static DBSummary retriveSummary(String driver, String url,
			String user, String pwd) {
		Connection conn;
		try {
			conn = tryConnect(driver, url, user, pwd);
		} catch (Exception e) {
			throw new DBConnectException(e);
		}

		try {
			return retriveSummary(conn, driver, url, user, pwd);
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
			}
		}
	}

	/**
	 * @param conn
	 * @param driver
	 * @param url
	 * @param user
	 * @param pwd
	 * @return
	 * @since liushen @ Jul 1, 2011
	 */
	private static DBSummary retriveSummary(Connection conn, String driver,
			String url, String user, String pwd) {
		DBSummary info = new DBSummary();
		info.setJdbcDriverClassName(driver);
		info.setJdbcUrl(url);
		info.setJdbcUser(user);
		info.setJdbcPassword(pwd);

		try {
			DatabaseMetaData dbMeta = conn.getMetaData();
			setDBSummary(dbMeta, info);
			info.setSqlKeywords(getSQLKeywords(dbMeta));
		} catch (Exception e) {
			throw new DAOException(e);
		}
		return info;
	}

	static DBSummary retriveSummary(DatabaseMetaData dbMeta) {
		DBSummary info = new DBSummary();
		try {
			setDBSummary(dbMeta, info);
		} catch (SQLException e) {
			throw new DAOException(e);
		}
		return info;
	}

	/**
	 * @param dbMeta
	 * @param info
	 * @return
	 * @throws SQLException
	 * @since liushen @ Sep 7, 2011
	 */
	private static void setDBSummary(DatabaseMetaData dbMeta, DBSummary info) throws SQLException {
		info.setDbProductName(dbMeta.getDatabaseProductName());
		info.setDbProductVersion(dbMeta.getDatabaseProductVersion());
		info.setDbProductName(dbMeta.getDatabaseProductName());
		info.setJdbcDriverName(dbMeta.getDriverName());
		info.setJdbcDriverVersion(dbMeta.getDriverMajorVersion() + "."
				+ dbMeta.getDriverMinorVersion());
		try {
			info.setJdbcDriverVersionDetail(dbMeta.getDriverVersion());
		} catch (Exception e) {
		}
		try {
			info.setJdbcVersion(dbMeta.getJDBCMajorVersion() + "."
					+ dbMeta.getJDBCMinorVersion());
		} catch (Throwable t) {
		}
		info.setUrlFromDBMeta(dbMeta.getURL());
		info.setUserFromDBMeta(dbMeta.getUserName());
	}

	/**
	 * 
	 * @param conn
	 * @return
	 * @creator liushen @ Jun 1, 2009
	 */
	public static DBSummary retriveSummary(Connection conn) {
		return retriveSummary(conn, null, null, null, null);
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Jun 23, 2011
	 */
	public static DBSummary connectAndGetSummary(RDBProduct dbProduct,
			String dbHost, int dbPort, String dbName, String dbUser,
			String dbPasswd) {

		StringBuilder sb = new StringBuilder();
		String dbDriver = null;
		if (dbProduct == RDBProduct.MySQL) {
			sb.append("jdbc:");
			sb.append("mysql://");
			sb.append((dbHost == null) ? "localhost" : dbHost);
			sb.append(':');
			sb.append((dbPort == 0) ? 3306 : dbPort);
			sb.append('/').append(dbName);

			dbDriver = "com.mysql.jdbc.Driver";
		} else if (dbProduct == RDBProduct.Oracle) {
			sb.append("jdbc:");
			sb.append("oracle:thin:@");
			sb.append((dbHost == null) ? "localhost" : dbHost);
			sb.append(':');
			sb.append((dbPort == 0) ? 1521 : dbPort);
			sb.append(':').append(dbName);

			dbDriver = "oracle.jdbc.driver.OracleDriver";
		} else if (dbProduct == RDBProduct.SQLServer) {
			sb.append("jdbc:");
			sb.append("jtds:sqlserver://");
			sb.append((dbHost == null) ? "localhost" : dbHost);
			sb.append(':');
			sb.append((dbPort == 0) ? 1433 : dbPort);
			sb.append('/').append(dbName);

			dbDriver = "net.sourceforge.jtds.jdbc.Driver";
		} else if (dbProduct == RDBProduct.H2) {
			// jdbc:h2:tcp://localhost/~/h2datas/mas
			sb.append("jdbc:");
			sb.append("h2:tcp://");
			sb.append((dbHost == null) ? "localhost" : dbHost);
			sb.append("/~/h2datas/").append(dbName);

			dbDriver = "org.h2.Driver";
		} else {
			throw new UnsupportedOperationException("dbProduct: " + dbProduct);
		}
		String jdbcUrl = sb.toString();

		return retriveSummary(dbDriver, jdbcUrl, dbUser, dbPasswd);
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Jun 23, 2011
	 */
	public static Properties connectAndToHibernateProperties(
			RDBProduct dbProduct, String dbHost, int dbPort, String dbName,
			String dbUser, String dbPasswd) {
		DBSummary dbSummary = connectAndGetSummary(dbProduct, dbHost, dbPort,
				dbName, dbUser, dbPasswd);
		Properties props = new Properties();
		props.setProperty("hibernate.connection.url", dbSummary.getJdbcUrl());
		props.setProperty("hibernate.connection.driver_class",
				dbSummary.getJdbcDriverClassName());
		props.setProperty("hibernate.dialect", getHibernateDialect(dbProduct));
		props.setProperty("hibernate.connection.username", dbUser);
		props.setProperty("hibernate.connection.password",
				dbSummary.getJdbcPassword());
		return props;

	}

	/**
	 * @param dbProduct
	 * @return
	 * @since liushen @ Jun 23, 2011
	 */
	static String getHibernateDialect(RDBProduct dbProduct) {
		if (dbProduct == null) {
			return null;
		}
		switch (dbProduct) {
		case MySQL:
			return "org.hibernate.dialect.MySQL5InnoDBDialect";
		case Oracle:
			return "org.hibernate.dialect.Oracle10gDialect";
		case SQLServer:
			return "org.hibernate.dialect.SQLServerDialect";
		case H2:
			return "com.trs.idm.util.hb.H2Dialect";
		default:
			throw new UnsupportedOperationException("dbProduct: " + dbProduct);
		}
	}

	/**
	 * 检测给定的配置参数的准确性(能否取得一个DB连接).<BR>
	 * 调用方需负责关闭此方法返回的<code>Connection</code>对象.
	 * 
	 * @param driver
	 *            JDBC驱动类名
	 * @param url
	 *            数据库URL
	 * @param user
	 *            连接用户
	 * @param pwd
	 *            连接密码
	 * @return 数据库连接
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 *             取不到数据库连接时.
	 */
	public static Connection tryConnect(String driver, String url, String user,
			String pwd) throws ClassNotFoundException, SQLException {
		if (driver == null || driver.trim().length() == 0) {
			throw new IllegalArgumentException(
					"the jdbc driver class is empty!");
		}
		if (url == null || url.trim().length() == 0) {
			throw new IllegalArgumentException("the jdbc url is empty!");
		}

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			throw e;
		}

		try {
			Connection conn = DriverManager.getConnection(url, user, pwd);
			return conn;
		} catch (SQLException e) {
			throw new SQLException("connect db fail! (url, user, driver)=("
					+ url + ", " + user + ", " + driver + "), err: " + e);
		}
	}

	/**
	 * @param dbMeta
	 * @return
	 * @creator liushen @ Jun 1, 2009
	 */
	private static String getSQLKeywords(DatabaseMetaData dbMeta) {
		try {
			return dbMeta.getSQLKeywords();
		} catch (SQLException e) {
			return "unable getSQLKeywords! err: " + e;
		}
	}

	static void connectAndGetIndexInfo(String driver, String url, String user, String pwd, String tableName) throws ClassNotFoundException, SQLException {
		Connection conn = tryConnect(driver, url, user, pwd);
		DatabaseMetaData meta = conn.getMetaData();
		getIndexInfo(meta, null, user, tableName);
	}

	static void getIndexInfo(DatabaseMetaData meta, String catalog, String schema, String tableName) {
		ResultSet rs = null;

		try {
			System.out.println(retriveSummary(meta));
			rs = meta.getIndexInfo(catalog, schema, tableName, false, true);
			ResultSetMetaData rsMeta = rs.getMetaData();
			int columnCount = rsMeta.getColumnCount();
			System.out.println(columnCount);
			while (rs.next()) {
// if ( rs.getShort("TYPE") == DatabaseMetaData.tableIndexStatistic ) continue;
				for (int i = 1; i <= columnCount; i++) {
					System.out.print(rsMeta.getColumnName(i) + ": " + rs.getString(i) + ";  ");
				}
				System.out.println();
			}
		} catch (SQLException e) {
			SQLException nextErr = e.getNextException();
			System.err.println("getIndexInfo fail! catalog=" + catalog + ", schema=" + schema + ", table=" + tableName + ", vendor-code: " + e.getErrorCode()
					+ (nextErr != null ? ", nextErr: " + nextErr : ""));
			e.printStackTrace(System.err);
		} catch (Exception e) {
			System.err.println("getIndexInfo fail! catalog=" + catalog + ", schema=" + schema + ", table=" + tableName + ", fail: " + e.getMessage());
			e.printStackTrace(System.err);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					System.err.println("finally clean fail, ignored: " + e);
				}

			}
		}

	}

}
