/*
 * Created: liushen@Jun 23, 2011 4:56:45 PM
 */
package com.trs.dev4.jdk16.dao;

/**
 * 职责: <br>
 *
 */
public enum RDBProduct {

	MySQL, Oracle, SQLServer, DB2, Sybase, H2;

}
