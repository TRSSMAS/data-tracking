/*
 * Created: Administrator@Mar 10, 2009 11:49:48 PM
 */
package com.trs.dev4.jdk16.dao;

import java.util.ArrayList;
import java.util.List;

import com.trs.dev4.jdk16.utils.ArrayUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责: 构造删除和更新的HQL表达式，传递给{@link IDBAccessor}使用。如果是检索的话，请使用{@link SearchFilter}
 * ，此类主要用于批量数据的处理.<br>
 * 暂时不支持复杂的与/或运算。
 * 
 * 使用方法： HQLBuilder.DELETE(User.class).addEqCondition("userName","userName001");
 * 
 * @author TRS信息技术股份有限公司
 */
// TODO liushen @ Feb 16, 2010: 需要考虑和SearchFilter的Condition等复用.
public class HQLBuilder {

	/**
	 * 
	 */
	private static final String HQL_SEPARATOR_COMMA = ",";
	/**
	 * 
	 */
	private static final String HQL_LEFTBRANKET = "(";
	/**
	 * 
	 */
	private static final String HQL_RIGHTBRANKET = ")";
	/**
	 * 
	 */
	private static final String HQL_DESC = "DESC";
	/**
	 * 
	 */
	private static final String HQL_ASC = "ASC";
	/**
	 * 
	 */
	private static final String HQL_OR = "OR";
	/**
	 * 
	 */
	private static final String HQL_AND = "AND";
	/**
	 * 
	 */
	private static final String HQL_SET = "SET";
	/**
	 * 
	 */
	private static final String HQL_FROM = "FROM";
	/**
	 * 
	 */
	private static final String HQL_ORDERBY = "ORDER BY";
	/**
	 * 
	 */
	private static final String HQL_WHERE = "WHERE";
	/**
	 * 
	 */
	private static final String HQL_SEPARATOR = " ";
	/**
	 * 
	 */
	private static final String PREFIX_UPDATE = "UPDATE";
	/**
	 * 
	 */
	private static final String PREFIX_DELETE = "DELETE";

	/**
	 * 
	 */
	private List<Condition> parameterValues = new ArrayList<Condition>();
	/**
	 * 表达式列表，含有表达式和关系运算符
	 */
	private List<Expression> whereExpressions = new ArrayList<Expression>();
	/**
	 * 当前的一个表达式
	 */
	private Expression currentExpression;
	/**
	 * 
	 */
	private Class<? extends Object> objectClass;
	/**
	 * 前缀
	 */
	private String prefix;
	/**
	 * 
	 */
	private List<OrderBy> orderBys = new ArrayList<OrderBy>();

	/**
	 * 赋值表达式，只提供给Update语句使用
	 */
	private List<Condition> assignExpressions = new ArrayList<Condition>();

	/**
	 * 
	 * @param objectClass
	 */
	protected HQLBuilder(String prefix, Class<? extends Object> objectClass) {
		this.prefix = prefix;
		this.objectClass = objectClass;
	}

	/**
	 * 构造批量删除语句
	 * 
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public static HQLBuilder DELETE(Class<? extends Object> objectClass) {
		HQLBuilder builder = new HQLBuilder(PREFIX_DELETE, objectClass);
		return builder;
	}

	/**
	 * 构造批量更新语句
	 * 
	 * @param objectClass
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public static HQLBuilder UPDATE(Class<? extends Object> objectClass) {
		HQLBuilder builder = new HQLBuilder(PREFIX_UPDATE, objectClass);
		return builder;
	}

	/**
	 * 增加一个字段表达式
	 * 
	 * @param field
	 *            对象的属性名
	 * @param operator
	 * @param value
	 *            取值. 如果value参数为null, 该方法并不会实际添加该条件.
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 * @exception 如果表达式不合法
	 *                ，则抛出IllegalArgumentException；
	 * @deprecated liushen@Jun 17, 2010: 因为第二个参数operator容易导致随意写和出错, 请使用更明确的方法,
	 *             比如对in条件请使用 {@link #addInCondition(String, Object[])};
	 *             此方法将仅作为本类private方法.
	 */
	@Deprecated
	public HQLBuilder addCondition(String field, String operator, Object value) {
		if ("in".equals(operator)) {
			if (!value.getClass().isArray()) {
				value = new Object[] { value };
			}
			return addInCondition(field, (Object[]) value);
		}
		if (currentExpression instanceof Condition) {
			throw new IllegalArgumentException(
					"Can't add Condition.Add relationship(addAND or addOR) first.");
		}
		if (isUpdateHQL() && assignExpressions.size() == 0) {
			throw new IllegalArgumentException(
					"Can't add Condition.Add assignExpression(setNewValue) first.");
		}
		currentExpression = new Condition(field, operator, value);
		whereExpressions.add(currentExpression);
		return this;
	}

	/**
	 * 支持in的条件
	 * 
	 * @param field
	 *            对象的属性名
	 * @param value
	 *            取值. 如果value参数为null, 该方法并不会实际添加该条件.
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 * @since liuyou @ 2010-4-19
	 */
	public HQLBuilder addInCondition(String field, Object[] value) {
		// WHERE id in ()会导致Hibernate抛出错误, 因此必须跳过无意义的空的in条件, 异常类似:
		// org.hibernate.hql.ast.QuerySyntaxException: unexpected end of subtree
		// [UPDATE com.trs.mam.bo.Foo SET status = :newstatus WHERE id in ()]
		 if (value == null || value.length == 0) {
			 return this;
		 }
		if (this.currentExpression instanceof Condition) {
			throw new IllegalArgumentException(
					"Can't add Condition.Add relationship(addAND or addOR) first.");
		}
		if ((isUpdateHQL()) && (this.assignExpressions.size() == 0)) {
			throw new IllegalArgumentException(
					"Can't add Condition.Add assignExpression(setNewValue) first.");
		}
		this.currentExpression = new InCondition(field, value);
		this.whereExpressions.add(this.currentExpression);
		return this;
	}

	/**
	 * 
	 * @param field
	 *            对象的属性名
	 * @param value
	 *            取值. 如果value参数为null, 该方法并不会实际添加该条件.
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 * @since liushen @ Jun 20, 2010
	 */
	public HQLBuilder addInCondition(String field, int[] value) {
		return addInCondition(field, ArrayUtil.toIntegerArray(value));
	}

	/**
	 * 
	 * @param field
	 *            对象的属性名
	 * @param value
	 *            取值. 如果value参数为null, 该方法并不会实际添加该条件.
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 * @since liushen @ Jun 29, 2010
	 */
	public HQLBuilder addGreaterThan(String field, Object value) {
		return addCondition(field, ">", value);
	}

	/**
	 * 
	 * @param field
	 *            对象的属性名
	 * @param value
	 *            取值. 如果value参数为null, 该方法并不会实际添加该条件.
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 * @since liushen @ Jun 29, 2010
	 */
	public HQLBuilder addGreaterThanEquals(String field, Object value) {
		return addCondition(field, ">=", value);
	}

	/**
	 * 
	 * @param field
	 *            对象的属性名
	 * @param value
	 *            取值. 如果value参数为null, 该方法并不会实际添加该条件.
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 * @since liushen @ Jun 29, 2010
	 */
	public HQLBuilder addLesserThan(String field, Object value) {
		return addCondition(field, "<", value);
	}

	/**
	 * 
	 * @param field
	 *            对象的属性名
	 * @param value
	 *            取值. 如果value参数为null, 该方法并不会实际添加该条件.
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 * @since liushen @ Jun 29, 2010
	 */
	public HQLBuilder addLesserThanEquals(String field, Object value) {
		return addCondition(field, "<=", value);
	}

	/**
	 * @return
	 */
	public boolean isUpdateHQL() {
		return prefix.equalsIgnoreCase(PREFIX_UPDATE);
	}

	/**
	 * 增加一个等于的表达式
	 * 
	 * @param field
	 * @param value
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public HQLBuilder addEqCondition(String field, Object value) {
		return addCondition(field, "=", value);
	}

	/**
	 * @deprecated liushen@Jun 29, 2010: 和
	 *             {@link #addEqCondition(String, Object)} 重复！
	 */
	@Deprecated
	public HQLBuilder addExpression(String field, String expression) {
		return addCondition(field, "=", expression);
	}

	/**
	 * 
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public HQLBuilder addAND() {
		return addRelation(HQL_AND);
	}

	/**
	 * 
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public HQLBuilder setNewValue(String field, Object value) {
		if (false == isUpdateHQL()) {
			throw new IllegalArgumentException(
					"Can't assign new Value,only update HQL supported.");
		}
		assignExpressions.add(new ExpressionCondition(field, "=", value));
		return this;
	}

	/**
	 * 
	 * @param relation
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	private HQLBuilder addRelation(String relation) {
		if (currentExpression instanceof Relation) {
			throw new IllegalArgumentException("");
		}
		currentExpression = new Relation(relation);
		whereExpressions.add(currentExpression);
		return this;
	}

	/**
	 * 添加与运算符
	 * 
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public HQLBuilder addOR() {
		return addRelation(HQL_OR);
	}

	/**
	 * 添加升序
	 * 
	 * @param field
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public HQLBuilder addAscOrder(String field) {
		return addOrderBy(field, HQL_ASC);
	}

	/**
	 * 添加降序
	 * 
	 * @param field
	 * @return 当前表达式对象自身(HQLBuilder)，以便于链式调用
	 */
	public HQLBuilder addDescOrder(String field) {
		return addOrderBy(field, HQL_DESC);
	}

	/**
	 * 获取用于PreparedStatement的HQL语句，需要重点测试
	 * 
	 * @return
	 */
	public String getPreparedHQL() {
		parameterValues.clear();
		if (isUpdateHQL()) {
			return getUpdatePreparedHQL();
		}
		return getDeletePreparedHQL();
	}

	/**
	 * @return
	 */
	private String getDeletePreparedHQL() {
		StringBuffer preparedHQL = new StringBuffer();
		preparedHQL.append(prefix).append(HQL_SEPARATOR).append(HQL_FROM)
				.append(HQL_SEPARATOR);
		preparedHQL.append(objectClass.getSimpleName()).append(HQL_SEPARATOR)
				.append(buildWhereHQL());
		return preparedHQL.toString();
	}

	/**
	 * @return
	 */
	private String buildWhereHQL() {
		StringBuilder searchHQL = new StringBuilder();
		if (whereExpressions.size() > 0) {
			searchHQL.append(HQL_WHERE).append(HQL_SEPARATOR).append(
					buildWhereExpression()).append(HQL_SEPARATOR);
		}
		if (orderBys.size() > 0) {
			searchHQL.append(HQL_ORDERBY).append(HQL_SEPARATOR).append(
					buildOrderBy());
		}
		return searchHQL.toString().trim();
	}

	/**
	 * @return
	 */
	private String buildOrderBy() {
		StringBuilder orderBy = new StringBuilder();
		if (orderBys.size() > 0) {
			orderBy.append(orderBys.get(0).toHQL());
			for (int i = 0; i < orderBys.size(); i++) {
				orderBy.append(HQL_SEPARATOR_COMMA).append(
						orderBys.get(i).toHQL());
			}
		}
		return orderBy.toString();
	}

	/**
	 * 
	 * @return
	 */
	private String buildWhereExpression() {
		StringBuffer where = new StringBuffer();
		if (whereExpressions.size() > 0) {
			where.append(whereExpressions.get(0).toHQL());
			parameterValues.add((Condition) whereExpressions.get(0));
			for (int i = 1; i < whereExpressions.size(); i++) {
				where.append(HQL_SEPARATOR).append(
						whereExpressions.get(i).toHQL());
				if (whereExpressions.get(i) instanceof Condition) {
					parameterValues.add((Condition) whereExpressions.get(i));
				}
			}
		}
		return where.toString();
	}

	/**
	 * @return
	 */
	private String getUpdatePreparedHQL() {
		StringBuilder preparedHQL = new StringBuilder();
		preparedHQL.append(prefix).append(HQL_SEPARATOR).append(
				objectClass.getSimpleName()).append(HQL_SEPARATOR);
		preparedHQL.append(buildSetClause());
		preparedHQL.append(buildWhereHQL());
		return preparedHQL.toString().trim();
	}

	/**
	 * 返回SET子句.
	 */
	private Object buildSetClause() {
		StringBuilder setClause = new StringBuilder();
		if (assignExpressions.size() > 0) {
			setClause.append(HQL_SET).append(HQL_SEPARATOR);
			// TODO Hibernate好像不支持多个字段的Bulk-Update, 待测试
			buildSetClause(setClause, assignExpressions.get(0));
			for (int i = 1; i < assignExpressions.size(); i++) {
				setClause.append(HQL_SEPARATOR_COMMA);
				buildSetClause(setClause, assignExpressions.get(i));
			}
		}
		return setClause.toString();
	}

	/**
	 * @param setClause
	 */
	private void buildSetClause(StringBuilder setClause,
			Condition assignmentExpression) {
		parameterValues.add(assignmentExpression);
		setClause.append(assignmentExpression.toHQL());
		setClause.append(HQL_SEPARATOR);
	}

	/**
	 * 获取所有参数调用，供Hibernate绑定参数使用
	 * 
	 * @return
	 */
	public List<Condition> getParameterValues() {
		return parameterValues;
	}

	/**
	 * 
	 * @param field
	 * @param order
	 */
	private HQLBuilder addOrderBy(String field, String order) {
		orderBys.add(new OrderBy(field, order));
		return this;
	}

	/**
	 * 
	 * 职责: 定义表达式的抽象接口.<br>
	 * 
	 * @author TRS信息技术股份有限公司
	 */
	interface Expression {
		String toHQL();
	}

	/**
	 * 
	 * 职责: 定义Where Clause中的表达式元素.<br>
	 * 
	 * @author TRS信息技术股份有限公司
	 */
	public class Condition implements Expression {
		/**
		 * 
		 */
		protected static final String PARAMETER_PREFIX = ":";
		/**
		 * 字段
		 */
		protected String field;
		/**
		 * 操作符
		 */
		protected String operator;
		/**
		 * 值
		 */
		protected Object value;

		/**
		 * 默认构造函数
		 * 
		 * @param field
		 * @param operator
		 * @param value
		 */
		public Condition(String field, String operator, Object value) {
			this.field = field;
			this.operator = operator;
			this.value = value;
		}

		/**
		 * 
		 * @return
		 */
		public String toHQL() {
			StringBuilder sb = new StringBuilder();
			sb.append(field).append(HQL_SEPARATOR).append(operator).append(
					HQL_SEPARATOR).append(PARAMETER_PREFIX).append(
					getParameterName());
			return sb.toString();
		}

		/**
		 * 
		 * @return
		 */
		public Object getValue() {
			return value;
		}

		/**
		 * 获取绑定参数名(不带冒号).
		 * 
		 * @return 绑定参数名(不带冒号).
		 */
		public String getParameterName() {
			return field;
		}

		/**
		 * 
		 * @return
		 */
		public boolean isValueType() {
			return true;
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("(").append(field).append(operator).append(value).append(
					", parameterName: " + getParameterName() + ")");
			sb.append(super.toString());
			return sb.toString();
		}

		/**
		 * Get the {@link #field}.
		 * 
		 * @return the {@link #field}.
		 */
		public String getField() {
			return field;
		}

		/**
		 * Get the {@link #operator}.
		 * 
		 * @return the {@link #operator}.
		 */
		public String getOperator() {
			return operator;
		}
	}

	public class InCondition extends HQLBuilder.Condition {

		public InCondition(String field, Object[] value) {
			super(field, "in", value);
		}

		@Override
		public String toHQL() {
			StringBuilder sb = new StringBuilder();
			sb.append(this.field).append(HQL_SEPARATOR).append(this.operator)
					.append(HQL_SEPARATOR).append(HQL_LEFTBRANKET).append(
							PARAMETER_PREFIX).append(getParameterName())
					.append(HQL_RIGHTBRANKET);
			return sb.toString();
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("(").append(this.field).append(this.operator).append(
					StringHelper.join((Object[]) this.value)).append(
					", parameterName: " + getParameterName() + ")");
			sb.append(super.toString());
			return sb.toString();
		}

	}

	/**
	 * 职责: 定义Set Clause中的表达式元素.<br>
	 * 
	 * @author TRS信息技术股份有限公司
	 */
	class ExpressionCondition extends Condition {
		/**
		 * 
		 * {@inheritDoc}
		 */
		public ExpressionCondition(String field, String operator, Object value) {
			super(field, operator, value);
		}

		/**
		 * 
		 * {@inheritDoc}
		 */
		@Override
		public boolean isValueType() {
			return false;
		}

		/**
		 * 赋值语句使用不同的绑定名称, 避免在和Where子句中的字段有重复时被覆盖.
		 * 
		 * @creator liushen @ Mar 17, 2009
		 */
		@Override
		public String getParameterName() {
			StringBuilder sb = new StringBuilder();
			sb.append(PARAMETER_ASSGIN).append(getField());
			return sb.toString();
		}

		private static final String PARAMETER_ASSGIN = "new";

	}

	/**
	 * 
	 * 职责: 定义关系运算符，主要是AND和OR.<br>
	 * 
	 * @author TRS信息技术股份有限公司
	 */
	class Relation implements Expression {
		/**
		 * 
		 */
		private String name;

		/**
		 * 
		 * @param name
		 */
		public Relation(String name) {
			this.name = name;
		}

		/**
		 * 
		 * {@inheritDoc}
		 */
		public String toHQL() {
			return name;
		}
	}

	class OrderBy {
		/**
		 * 
		 */
		private String field;
		/**
		 * 
		 */
		private String order;

		/**
		 * 
		 * @param field
		 * @param order
		 */
		public OrderBy(String field, String order) {
			this.field = field;
			this.order = order;
		}

		/**
		 * 
		 * @return
		 */
		public String toHQL() {
			StringBuffer sb = new StringBuffer();
			sb.append(field).append(HQL_SEPARATOR).append(order);
			return sb.toString();
		}
	}
}
