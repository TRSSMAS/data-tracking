/**
 * ContainerNode.java. created on 2006-6-1
 */
package com.trs.dev4.jdk16.xml.node;

import java.util.LinkedList;

import com.trs.dev4.jdk16.xml.AbstractNode;
import com.trs.dev4.jdk16.xml.Node;

/**
 * 可以添加子节点的Node。
 * 
 * @author liu kaixuan
 * @date 2006-6-1 16:46:34
 */
public class ContainerNode extends AbstractNode {
	/** 顺序保存 */
	protected LinkedList<Node> children = new LinkedList<Node>();

	/**
	 * 
	 * @param nodeName
	 */
	public ContainerNode(String nodeName) {
		super(nodeName);
	}

	/**
	 * 
	 * @param nodeName
	 * @param nodeValue
	 */
	public void addChildNode(String nodeName, String nodeValue){
		Node node = new SimpleNode(nodeName, nodeValue) ;
		addChildNode(node) ;
	}

	/**
	 * 
	 * @param nodeName
	 * @param nodeValue
	 * @param CDATANeeded
	 */
	public void addChildNode(String nodeName, String nodeValue, boolean CDATANeeded){
		SimpleNode node = new SimpleNode(nodeName, nodeValue) ;
		node.setCDATANeeded(CDATANeeded) ;
		addChildNode(node) ;
	}

	/**
	 * 
	 * @param nodeName
	 * @param nodeValue
	 */
	public void addChildNode(String nodeName, int nodeValue){
		Node node = new SimpleNode(nodeName, nodeValue) ;
		addChildNode(node) ;
	}

	/**
	 * 
	 * @param node
	 */
	public void addChildNode(Node node){
		node.setLevel(getLevel() + 1) ;
		children.addLast(node) ;
	}

	/**
	 * 
	 * @param node
	 * @return
	 */
	public boolean removeChildNode(Node node){
		return children.remove(node) ;
	}

	/* (non-Javadoc)
	 * @see com.trs.common.xml.Node#setLevel(int)
	 */
	@Override
	public void setLevel(int level) {
		super.setLevel(level) ;
		//所有children的位置也降1。
		for(int i = 0 ; i < children.size() ; i++){
			(children.get(i)).setLevel(getLevel() + 1) ;
		}
	}

	@Override
	protected boolean hasNodeValue() {
		return !children.isEmpty();
	}

	/**
	 * 返回子节点生成的xml
	 */
	@Override
	protected String getNodeValue() {
		StringBuffer sb = new StringBuffer(256) ;
		sb.append("\n") ;
		for(int i = 0 ; i < children.size() ; i++){
			Node node = children.get(i) ;
			sb.append(node.toXML()) ;
			sb.append("\n") ;
		}
		sb.append(this.getFmtWhiteSpace()) ;

		return sb.toString() ;
	}
}
