/**
 * XMLGenerator.java. created on 2006-6-1
 */
package com.trs.dev4.jdk16.xml;

/**
 * 帮助生成一个完整的xml文件。
 * 
 */
public class XMLGenerator {
	/**
	 *
	 */
	private String encoding = "UTF-8" ;
	/**
	 *
	 */
	private String version = "1.0" ;
	/**
	 *
	 */
	private Node rootNode ;

	public XMLGenerator(){

	}

	/**
	 * @return
	 */
	public String generateXML(){
		StringBuffer sb = new StringBuffer(4096) ;
		sb.append("<?xml version=\"")
		  .append(version)
		  .append("\" encoding=\"")
		  .append(encoding)
		  .append("\" ?>")
		  .append("\n\n") ;

		sb.append(rootNode.toXML()) ;

		return sb.toString() ;
	}

	/**
	 * 
	 * @param encoding
	 */
	public XMLGenerator(String encoding){
		this.encoding = encoding ;
	}

	/**
	 * 
	 * @return
	 */
	public String getEncoding() {
		return encoding;
	}

	/**
	 * 
	 * @param encoding
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * 
	 * @return
	 */
	public Node getRootNode() {
		return rootNode;
	}

	/**
	 * 
	 * @param rootNode
	 */
	public void setRootNode(Node rootNode) {
		this.rootNode = rootNode;
	}

	/**
	 * 
	 * @return
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * 
	 * @param version
	 */
	public void setVersion(String version) {
		this.version = version;
	}
}
