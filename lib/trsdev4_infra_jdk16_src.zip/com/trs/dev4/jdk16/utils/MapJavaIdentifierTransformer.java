/*
 * Created: fangxiang@Oct 19, 2010 12:05:09 PM
 */
package com.trs.dev4.jdk16.utils;

import java.util.HashMap;
import java.util.Map;

import net.sf.json.util.JavaIdentifierTransformer;

import org.apache.log4j.Logger;

/**
 * 实现对JSON字符串到Java属性的转换
 * 
 */
public class MapJavaIdentifierTransformer extends JavaIdentifierTransformer {
	private final static Logger logger = Logger
			.getLogger(MapJavaIdentifierTransformer.class);
	/**
	 * 
	 */
	private Map<String, String> transformFields = new HashMap<String, String>();

	/**
	 * 
	 * @param transformFields
	 */
	MapJavaIdentifierTransformer(Map<String, String> transformFields) {
		this.transformFields = transformFields;
	}

	/**
	 * @see net.sf.json.util.JavaIdentifierTransformer#transformToJavaIdentifier(java.lang.String)
	 * @since fangxiang @ Oct 19, 2010
	 */
	@Override
	public String transformToJavaIdentifier(String field) {
		String transformField = this.transformFields.get(field);
		if (logger.isDebugEnabled()) {
			logger.debug("field(" + field + ") transform to ("
					+ (transformField != null ? transformField : field)
					+ ")[transformField:"
					+ transformField + "]");
		}
		if (StringHelper.isEmpty(transformField)) {
			return field;
		}
		return transformField;
	}
}