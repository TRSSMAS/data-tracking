/*
 * Created: liushen@Mar 10, 2009 4:28:19 PM
 */
package com.trs.dev4.jdk16.utils;

import java.io.File;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.trs.dev4.jdk16.exception.NoSuchResourceException;
import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * Class工具类.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class ClassUtil {

	/**
	 * 根据完整类名得到对应的Class对象.
	 * 
	 * @return
	 * @creator liushen @ May 21, 2009
	 */
	public static Class<? extends Object> getClassByName(String className) {
		try {
			return Class.forName(className);
		} catch (Exception e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * 获取给定对象的完整类名(含package名的形式).
	 */
	public static String getClassName(Object obj) {
		if (obj == null) {
			return null;
		}
		return obj.getClass().getName();
	}

	/**
	 * 获取给定对象的简单类名, 即不含package名的形式.
	 * 
	 * @since JDK1.5
	 */
	public static String getSimpleName(Object obj) {
		if (obj == null) {
			return null;
		}
		return obj.getClass().getSimpleName();
	}

	/**
	 * 列出指定的类实现的所有接口（包括接口的父接口）。
	 * 
	 * @param clazz
	 * @return Class对象组成的List
	 */
	public static List<Class<?>> listAllInterfaces(Class<?> clazz) {
		List<Class<?>> list = new ArrayList<Class<?>>();
		Class<?>[] directInterfaces = clazz.getInterfaces();
		list.addAll(Arrays.asList(directInterfaces));
		for (int i = 0; i < directInterfaces.length; i++) {
			list.addAll(listAllInterfaces(directInterfaces[i]));
		}
		return list;
	}

	/**
	 * 判断给定的类是否实现了给定的接口.
	 * 
	 * @param clazz
	 * @param interFace
	 * @return
	 * @creator liushen @ Dec 24, 2009
	 */
	public static boolean isImplementedInterface(Class<?> clazz,
			Class<?> interFace) {
		List<Class<?>> allInterfaces = listAllInterfaces(clazz);
		return allInterfaces.contains(interFace);
	}

	/**
	 * 获取给定对象的类源位置.
	 * 
	 * @param obj
	 *            给定对象
	 */
	public static String getSourceLocation(Object obj) {
		if (obj == null) {
			return null;
		}
		return getSourceLocation(obj.getClass());
	}

	/**
	 * 获取指定类的源位置.
	 * 
	 * @return 该clazz的源位置.
	 * @since JDK1.4
	 */
	public static String getSourceLocation(Class<? extends Object> clazz) {
		if (clazz == null) {
			return null;
		}

		try {
			ProtectionDomain pd = clazz.getProtectionDomain();
			CodeSource cs = pd.getCodeSource();
			if (cs != null) {
				return cs.getLocation().toString();
			} else {
				return null;
			}
		} catch (RuntimeException e) {
			return e.toString();
		}
	}

	/**
	 * 断定给定的资源文件存在，并返回其URL. <BR>
	 * 资源文件是指位于classpath中的文件.
	 * 
	 * @param clazz
	 *            从哪个类的classpath中寻找该资源文件
	 * @param resourcePath
	 *            资源文件在classpath中的路径
	 * @return 该资源文件的URL对象.
	 * @throws IllegalArgumentException
	 *             参数无效时(任一为<code>null</code>时)
	 * @throws NoSuchResourceException
	 *             该资源文件不存在时
	 * @since liushen @ Aug 27, 2010
	 */
	public static URL assertAndLocateResource(Class<?> clazz,
			String resourcePath) {
		AssertUtil.notNull(resourcePath, "the resource name is null!");
		AssertUtil.notNull(clazz, "the class object is null!");
		URL resUrl = clazz.getResource(resourcePath);
		if (resUrl == null) {
			if (resourcePath.startsWith("/")) {
				throw new NoSuchResourceException("resource [ " + resourcePath
						+ " ] not found in [ " + clazz.getResource("/") + " ]!");
			} else {
				throw new NoSuchResourceException("resource [ " + resourcePath
						+ " ] not found in [ " + clazz.getResource("/")
						+ getFSPathFormOfPackage(clazz) + " ]!");
			}
		}
		return resUrl;
	}

	/**
	 * 
	 * @param clazz
	 * @param resourcePath
	 * @return
	 * @since liushen @ Sep 15, 2010
	 */
	public static File assertAndLocateResourceFile(Class<?> clazz,
			String resourcePath) {
		URL resourceUrl = assertAndLocateResource(clazz, resourcePath);
		return new File(UrlUtil.decode(resourceUrl.getFile()));
	}

	/**
	 * 获取该类所在package的文件系统表示形式，即将<code>.</code>替换为<code>/</code>.
	 * 
	 * @param clazz
	 * @return
	 * @since liushen @ Aug 27, 2010
	 */
	public static String getFSPathFormOfPackage(Class<?> clazz) {
		Class<?> c = clazz;
		while (c.isArray()) {
			c = c.getComponentType();
		}
		String baseName = c.getName();
		int index = baseName.lastIndexOf('.');
		if (index != -1) {
			return baseName.substring(0, index).replace('.', '/');
		} else {
			return baseName;
		}
	}
}
