/*
 * Title: TRS 身份服务器 Copyright: Copyright (c) 2004-2005, TRS信息技术有限公司. All rights reserved. License: see the license file.
 * Company: TRS信息技术有限公司(www.trs.com.cn)
 * 
 * Created on 2006-2-17 15:35:27, by liushen
 */
package com.trs.dev4.jdk16.utils;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;

/**
 * IP工具类. <BR>
 * 
 * @author TRS信息技术有限公司
 */
public class IPUtil {

	public static final String IP_SEGMENT_SPLITTER = "-";
	private static final String REG_IP_V4 = "((25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)";
	private static final String REG_IP_V4_SEG = REG_IP_V4 + "\\-" + REG_IP_V4;

	/**
	 * 验证IP是否有效
	 * 
	 * @param ip
	 *            IP地址，如192.9.200.10，不支持通配符
	 * @return true if valid or empty, false otherwise.
	 */
	public static boolean isValidV4IP(String ip) {
		if (ip == null) {
			return false;
		}
		ip = ip.trim();
		if (ip.length() == 0) {
			return false;
		}
		String[] part_IP = ip.split("\\.");
		if (part_IP.length != 4) {
			return false;
		}
		int int_IP;
		for (int i = 0; i < 4; i++) {
			try {
				int_IP = Integer.parseInt(part_IP[i]);
				if (int_IP < 0 || int_IP > 255) {
					return false;
				}
			} catch (NumberFormatException e) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 是否是合法的IPV4或者IPV4段地址，以-为分隔符
	 * 
	 * @param ip
	 *            如192.9.200.10， 或者192.9.200.0-192.9.200.255，不支持通配符
	 * @return
	 * @since v3.5
	 * @creator shixin @ 2010-6-25
	 */
	public static boolean isValidV4IPOrSegment(String ip) {
		if (StringHelper.isEmpty(ip)) {
			return false;
		}
		if (ip.matches(REG_IP_V4_SEG) || ip.matches(REG_IP_V4)) {
			return true;
		}
		return false;
	}

	/**
	 * 处理代理模式下获取原始客户端IP，优先获取Header里面X-Forwarded-For属性
	 * 
	 * @param request
	 * @return
	 * @creator fangxiang @ Sep 1, 2009
	 */
	public static String getRemoteAddr(HttpServletRequest request) {
		String xForwardedFor = request.getHeader("X-Forwarded-For");
		String remoteAddr = request.getRemoteAddr();
		// System.out.println("xForwardedFor:"+xForwardedFor+",remoteAddr:"+remoteAddr);
		if (xForwardedFor != null && xForwardedFor.length() > 4) {
			int index = xForwardedFor.indexOf(",");
			if (index != -1) {
				remoteAddr = xForwardedFor.substring(0, index);
			} else {
				remoteAddr = xForwardedFor;
			}
		}
		return remoteAddr;
	}

	/**
	 * IP或者IP段是否包含IP地址
	 * 
	 * @param ipOrIpSegment
	 *            IP或者IP段 ， 如192.9.200.10， 或者192.9.200.0-192.9.200.255，不支持通配符
	 * @param ipAddress
	 *            IP地址，如192.9.200.10，不支持通配符
	 * @return
	 * @since v3.5
	 * @creator shixin @ 2010-6-24
	 */
	public static boolean isIpOrSegmentContainsIpAddr(String ipOrIpSegment, String ipAddress) {
		if (ipOrIpSegment == null) {
			return false;
		}

		if (ipAddress == null) {
			return false;
		}
		// 如果是IP值，且相等
		if (-1 == ipOrIpSegment.indexOf(IP_SEGMENT_SPLITTER) && ipOrIpSegment.equals(ipAddress)) {
			return true;
		}
		// 如果是IP段
		if (-1 != ipOrIpSegment.indexOf(IP_SEGMENT_SPLITTER)) {
			return isIpInSegment(ipOrIpSegment, ipAddress);
		}
		return false;
	}

	/**
	 * IP集合是否包含当前IP
	 * 
	 * @param ipSet
	 *            IP或者IP段集合
	 * @param ipAddress
	 *            IP地址
	 * @return 包含返回true，否则返回false
	 */
	public static boolean containIpAddr(Set ipSet, String ipAddress) {
		if (ipSet == null || ipSet.size() == 0) {
			return false;
		}
		Object[] ipArray = ipSet.toArray();
		for (int i = 0; i < ipArray.length; i++) {
			String ipOrSegment = (String) ipArray[i];
			if (isIpOrSegmentContainsIpAddr(ipOrSegment, ipAddress)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 两个IP段内是否有重复交叉，或者包含对方IP段；<br>
	 * 例如：192.9.1.10-192.9.1.20和192.9.1.15-192.9.1.30有交叉；<br>
	 * 如果IP段格式不合法，直接返回false；<br>
	 * 
	 * @param ipSegment1
	 *            IP段一，格式如：192.9.1.10-192.9.1.20，不支持通配符
	 * @param ipSegment2
	 *            IP段二，格式如：192.9.1.15-192.9.1.30，不支持通配符
	 * @return 有交叉返回true，不交叉返回false
	 * @since v3.5
	 * @creator shixin @ 2011-8-12
	 */
	public static boolean containsOrCross(String ipSegment1, String ipSegment2) {
		if (StringHelper.isEmpty(ipSegment1) || StringHelper.isEmpty(ipSegment2)) {
			return false;
		}
		if (false == ipSegment1.matches(REG_IP_V4_SEG) || false == ipSegment2.matches(REG_IP_V4_SEG)) {
			return false;
		}
		// 取IP段的前三位数字判断，如果前三位不相同，则直接返回false
		String[] segmentArray1 = StringHelper.split(ipSegment1, "-");
		if (segmentArray1 == null || segmentArray1.length != 2) {
			return false;
		}
		String prefixThreeLetterStr1 = segmentArray1[0].substring(0, segmentArray1[0].lastIndexOf("."));
		String tailThreeLetterStr1 = segmentArray1[1].substring(0, segmentArray1[1].lastIndexOf("."));

		String[] segmentArray2 = StringHelper.split(ipSegment2, "-");
		if (segmentArray2 == null || segmentArray2.length != 2) {
			return false;
		}
		String prefixThreeLetterStr2 = segmentArray2[0].substring(0, segmentArray2[0].lastIndexOf("."));
		String tailThreeLetterStr2 = segmentArray2[1].substring(0, segmentArray2[1].lastIndexOf("."));

		// 如果前三位数字没有相等的情况，直接返回false
		if (false == prefixThreeLetterStr1.equals(prefixThreeLetterStr2)
				&& false == prefixThreeLetterStr1.equals(tailThreeLetterStr2)
				&& false == tailThreeLetterStr1.equals(prefixThreeLetterStr2)
				&& false == tailThreeLetterStr1.equals(tailThreeLetterStr2)) {
			return false;
		}

		String lastMinLetterOfStr1 = segmentArray1[0].substring(segmentArray1[0].lastIndexOf(".") + 1);
		String lastMaxLetterOfStr1 = segmentArray1[1].substring(segmentArray1[1].lastIndexOf(".") + 1);

		String lastMinLetterOfStr2 = segmentArray2[0].substring(segmentArray2[0].lastIndexOf(".") + 1);
		String lastMaxLetterOfStr2 = segmentArray2[1].substring(segmentArray2[1].lastIndexOf(".") + 1);
		// 如果IP段1的最大值小于IP段2的最小值，或者IP段2的最大值小于IP段１的最小值，则不重复交叉
		if (Integer.parseInt(lastMaxLetterOfStr1) < Integer.parseInt(lastMinLetterOfStr2)
				|| Integer.parseInt(lastMaxLetterOfStr2) < Integer.parseInt(lastMinLetterOfStr1)) {
			return false;
		}
		return true;
	}

	/**
	 * 判断IP是否在指定IP段范围内
	 * 
	 * @param ipSegment
	 *            IP段，如192.9.200.0-192.9.200.255，不支持通配符
	 * @param ipAddr
	 *            IP地址，如192.9.200.10，不支持通配符
	 * @return IP地址在IP段范围内，返回true，否则返回false
	 * @since v3.5
	 * @creator shixin @ 2010-6-24
	 */
	public static boolean isIpInSegment(String ipSegment, String ipAddr) {
		if (ipSegment == null) {
			return false;
		}
		if (ipAddr == null) {
			return false;
		}
		ipSegment = ipSegment.trim();
		ipAddr = ipAddr.trim();
		if (!ipSegment.matches(REG_IP_V4_SEG) || !ipAddr.matches(REG_IP_V4)) {
			return false;
		}
		int splitterIndex = ipSegment.indexOf('-');
		String[] ipSegBeforeArray = ipSegment.substring(0, splitterIndex).split("\\.");
		String[] ipSegEndArray = ipSegment.substring(splitterIndex + 1).split("\\.");
		String[] ipAddrArray = ipAddr.split("\\.");
		long ipSegBeforeLongValue = 0L, ipSegEndLongValue = 0L, ipAddrLongValue = 0L;
		for (int i = 0; i < 4; ++i) {
			ipSegBeforeLongValue = ipSegBeforeLongValue << 8 | Integer.parseInt(ipSegBeforeArray[i]);
			ipSegEndLongValue = ipSegEndLongValue << 8 | Integer.parseInt(ipSegEndArray[i]);
			ipAddrLongValue = ipAddrLongValue << 8 | Integer.parseInt(ipAddrArray[i]);
		}
		if (ipSegBeforeLongValue > ipSegEndLongValue) {
			long t = ipSegBeforeLongValue;
			ipSegBeforeLongValue = ipSegEndLongValue;
			ipSegEndLongValue = t;
		}
		return ipSegBeforeLongValue <= ipAddrLongValue && ipAddrLongValue <= ipSegEndLongValue;
	}

}
