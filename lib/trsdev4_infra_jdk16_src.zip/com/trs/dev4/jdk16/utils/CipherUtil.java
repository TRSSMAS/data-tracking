
package com.trs.dev4.jdk16.utils;

/**
 * 对称加密工具
 * 
 */
public class CipherUtil {

	// 定义以什么字符开始算是加密
	public String startCode="^`" ;

	private static final char ENCODE_ARRAY[] = {
 'A', 'B', 'C', 'D', 'E', 'F',
			'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S',
			'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
			'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
			't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5',
			'6', '7',
		'8', '9', '-', '_'
	};
	private static final byte DECODE_ARRAY[];
	static
	{
		DECODE_ARRAY = new byte[256];
		for (int i = 0; i < 255; i++)
			DECODE_ARRAY[i] = -1;

		for (int i = 0; i < ENCODE_ARRAY.length; i++)
			DECODE_ARRAY[ENCODE_ARRAY[i]] = (byte)i;

	}

	/**
	 * 加密
	 * 
	 * @param inbuf
	 * @return
	 */
	private static String encode(byte inbuf[])
	{
		if (inbuf.length == 0)
			return "";
		byte outbuf[] = new byte[((inbuf.length + 2) / 3) * 4];
		int inpos = 0;
		int outpos = 0;
		for (int size = inbuf.length; size > 0; size -= 3)
			if (size == 1)
			{
				byte a = inbuf[inpos++];
				byte b = 0;
				// byte c = 0;
				outbuf[outpos++] = (byte)ENCODE_ARRAY[a >>> 2 & 0x3f];
				outbuf[outpos++] = (byte)ENCODE_ARRAY[(a << 4 & 0x30) + (b >>> 4 & 0xf)];
				outbuf[outpos++] = 46;
				outbuf[outpos++] = 46;
			} else
			if (size == 2)
			{
				byte a = inbuf[inpos++];
				byte b = inbuf[inpos++];
				byte c = 0;
				outbuf[outpos++] = (byte)ENCODE_ARRAY[a >>> 2 & 0x3f];
				outbuf[outpos++] = (byte)ENCODE_ARRAY[(a << 4 & 0x30) + (b >>> 4 & 0xf)];
				outbuf[outpos++] = (byte)ENCODE_ARRAY[(b << 2 & 0x3c) + (c >>> 6 & 3)];
				outbuf[outpos++] = 46;
			} else
			{
				byte a = inbuf[inpos++];
				byte b = inbuf[inpos++];
				byte c = inbuf[inpos++];
				outbuf[outpos++] = (byte)ENCODE_ARRAY[a >>> 2 & 0x3f];
				outbuf[outpos++] = (byte)ENCODE_ARRAY[(a << 4 & 0x30) + (b >>> 4 & 0xf)];
				outbuf[outpos++] = (byte)ENCODE_ARRAY[(b << 2 & 0x3c) + (c >>> 6 & 3)];
				outbuf[outpos++] = (byte)ENCODE_ARRAY[c & 0x3f];
			}

		return new String(outbuf);
	}

	/**
	 * 解密
	 * 
	 * @param inbuf
	 * @return
	 */
	private static byte[] decode(byte inbuf[])
	{
		int size = (inbuf.length / 4) * 3;
		if (size == 0)
			return inbuf;
		if (inbuf[inbuf.length - 1] == 46)
		{
			size--;
			if (inbuf[inbuf.length - 2] == 46)
				size--;
		}
		byte outbuf[] = new byte[size];
		int inpos = 0;
		int outpos = 0;
		for (size = inbuf.length; size > 0; size -= 4)
		{
			byte a = DECODE_ARRAY[inbuf[inpos++] & 0xff];
			byte b = DECODE_ARRAY[inbuf[inpos++] & 0xff];
			outbuf[outpos++] = (byte)(a << 2 & 0xfc | b >>> 4 & 3);
			if (inbuf[inpos] == 46)
				return outbuf;
			a = b;
			b = DECODE_ARRAY[inbuf[inpos++] & 0xff];
			outbuf[outpos++] = (byte)(a << 4 & 0xf0 | b >>> 2 & 0xf);
			if (inbuf[inpos] == 46)
				return outbuf;
			a = b;
			b = DECODE_ARRAY[inbuf[inpos++] & 0xff];
			outbuf[outpos++] = (byte)(a << 6 & 0xc0 | b & 0x3f);
		}

		return outbuf;
	}

	/**
	 * 封装加密，对外公开
	 */
	public String doEnCode(String sUnCoded){
		return startCode + encode(strToByteArr(sUnCoded));
	}

	/**
	 * 封装解密，对外公开
	 * 
	 * @param sEnCoded
	 * @return
	 */
	public String doDeCode(String sEnCoded) {
		if (sEnCoded == null) {
			return null;
		}
		return byteArrToStr(decode(strToByteArr(sEnCoded.substring(2))));
	}

	/**
	 * 判断是否已经加密,^`为新添加的判断是否加密的字符串
	 * 
	 * @param filed
	 * @return
	 */
	public boolean isEnCoded(String filed){
		return filed.startsWith(startCode);
	}

	/**
	 * 将String转化为byte[]
	 * 
	 * @param str
	 * @return
	 */
	public byte[] strToByteArr(String str){
		return str.getBytes();
	}

	/**
	 * 将byte[]转化为String值
	 * 
	 * @param byteArr
	 * @return
	 */
	public String byteArrToStr(byte[] byteArr){
		return new String(byteArr);
	}
}
