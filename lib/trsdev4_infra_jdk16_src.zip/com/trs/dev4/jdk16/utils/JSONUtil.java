/*
 * Created: liushen@Jun 5, 2009 5:15:31 PM
 */
package com.trs.dev4.jdk16.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;
import net.sf.json.util.PropertyFilter;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.exception.ExceptionUtil;
import com.trs.dev4.jdk16.exception.JsonException;
import com.trs.dev4.jdk16.exception.WrappedException;

/**
 * JSON工具类.<br>
 * 如果本工具类不能更细粒度控制JSON生成的需要，可以看看 {@link JSONBuilder}.
 * 
 * @author TRS信息技术股份有限公司
 * @since 2012/3/6 将集合转JSON串时，空集合从[{}]改为[]；
 */
public class JSONUtil {

	private static final Logger LOG = Logger.getLogger(JSONUtil.class);

	/**
	 * 将数组类型的对象转换成JSON数组格式的字符串.
	 * 
	 * @param objArray
	 *            待转换的数组对象
	 * @return JSON数组格式的字符串
	 * @since liushen @ May 31, 2010
	 */
	public static final String toJSONArray(Object[] objArray) {
		if (objArray == null || objArray.length == 0) {
			return null;
		}
		JSONArray jsonArray = new JSONArray();
		for (Object obj : objArray) {
			try {
				jsonArray.add(obj);
			} catch (JSONException e) {
				throw new WrappedException(e);
			}
		}
		return jsonArray.toString();
	}

	/**
	 * 将集合对象转换成JSON数组格式的字符串.
	 * 
	 * @param entities
	 *            待转换的对象
	 * @return JSON数组格式的字符串
	 * @since fangxiang @ May 31, 2010
	 */
	public static String toJSONArray(List<? extends Object> entities) {
		if (entities == null || entities.size() == 0) {
			return "[]";
		}
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(entities.get(0).getClass());
		return JSONArray.fromObject(entities, jsonConfig).toString();
	}

	/**
	 * 将集合对象转换成JSON数组格式的字符串.
	 * 
	 * @param entities
	 *            待转换的对象
	 * @return JSON数组格式的字符串
	 * @since fangxiang @ May 31, 2010
	 */
	public static String toJSONArray(List<? extends Object> entities,
			String[] fields) {
		if (entities == null || entities.size() == 0) {
			return "[]";
		}
		if (fields == null) {
			fields = ReflectUtil.getAllFieldName(entities.get(0).getClass());
		}
		final List<String> fieldIndexes = new ArrayList<String>();
		for (int i = 0; i < fields.length; i++) {
			fieldIndexes.add(fields[i]);
		}
		//
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(entities.get(0).getClass());
		jsonConfig.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return !fieldIndexes.contains(name);
			}
		});
		return JSONArray.fromObject(entities, jsonConfig).toString();
	}

	/**
	 * 将集合对象转换成JSON数组格式的字符串.
	 * 
	 * @param entities
	 *            待转换的对象
	 * @return JSON数组格式的字符串
	 * @since fangxiang @ May 31, 2010
	 */
	public static String toJSONArray(PagedList<? extends Object> entities,
			String[] fields) {
		if (entities == null || entities.size() == 0) {
			return "[]";
		}
		if (fields == null) {
			fields = ReflectUtil.getAllFieldName(entities.get(0).getClass());
		}
		final List<String> fieldIndexes = new ArrayList<String>();
		for (int i = 0; i < fields.length; i++) {
			fieldIndexes.add(fields[i]);
		}
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return !fieldIndexes.contains(name);
			}
		});
		Map<String, Object> mapEntities = new TreeMap<String, Object>();
		mapEntities.put("firstPageNo", entities.getFirstPageNo());
		mapEntities.put("lastPageNo", entities.getLastPageNo());
		mapEntities.put("startPage", entities.getStartPage());
		mapEntities.put("endPage", entities.getEndPage());
		mapEntities.put("pageIndex", entities.getPageIndex());
		mapEntities.put("pageTotal", entities.getPageTotal());
		mapEntities.put("pageSize", entities.getPageSize());
		mapEntities.put("step", entities.getStep());
		mapEntities.put("thisPageTotal", entities.getThisPageTotal());
		mapEntities.put("totalItemCount", entities.getTotalItemCount());
		mapEntities.put("totalPageCount", entities.getTotalPageCount());
		mapEntities.put("items",
 JSONArray.fromObject(entities.getPageItems(), jsonConfig).toString());
		//
		return JSONArray.fromObject(mapEntities).toString();
	}

	/**
	 * 将对象转换成JSON格式的字符串.
	 * 
	 * @param obj
	 *            待转换的对象
	 * @return JSON格式的字符串
	 * @creator liushen @ Jun 5, 2009
	 */
	@SuppressWarnings("unchecked")
	public static String toJSON(Object obj) {
		if (obj instanceof Map) { // 防止把Map直接JSON化
			return toMapJSON((Map<String, Object>) obj);
		}
		Map<String, Object> map = ReflectUtil.toMap(obj);
		return toJSON(map);
	}

	/**
	 * 根据对象的指定属性列表生成JSON字符串
	 * 
	 * @param object
	 *            对象
	 * @param fields
	 *            属性列表
	 * @return JSON字符串
	 * @since fangxiang @ Oct 12, 2010
	 */
	public static String toJSON(Object object, String... fields) {
		JsonConfig jsonConfig = new JsonConfig();
		if (fields != null) {
			final List<String> fieldIndexes = new ArrayList<String>();
			for (int i = 0; i < fields.length; i++) {
				fieldIndexes.add(fields[i]);
			}
			// Arrays.asList(a)
			jsonConfig.setRootClass(object.getClass());
			jsonConfig.setJsonPropertyFilter(new PropertyFilter() {
				public boolean apply(Object source, String name, Object value) {
					return !fieldIndexes.contains(name);
				}
			});
			// jsonConfig.registerJsonValueProcessor(Date.class,
			// new DateJsonValueProcessor());
		}
		return JSONObject.fromObject(object, jsonConfig).toString();
	}

	/**
	 * 
	 * @param obj
	 * @param excludeFields
	 * @return
	 * @since liushen @ Mar 31, 2011
	 */
	public static String toJSONExclude(Object obj, String... excludeFields) {
		JsonConfig jsonConfig = new JsonConfig();
		if (excludeFields != null) {
			final List<String> fieldIndexes = Arrays.asList(excludeFields);
			jsonConfig.setRootClass(obj.getClass());
			jsonConfig.setJsonPropertyFilter(new PropertyFilter() {
				public boolean apply(Object source, String name, Object value) {
					return fieldIndexes.contains(name);
				}
			});
			// jsonConfig.registerJsonValueProcessor(Date.class, null);
		}
		return JSONObject.fromObject(obj, jsonConfig).toString();
	}

	/**
	 * 
	 * @param obj
	 * @param timestampFields
	 * @param excludeFields
	 * @return
	 * @since liushen @ Jul 4, 2011
	 */
	public static String toJSONWithTimestampAndExclude(Object obj,
			final String[] timestampFields, String[] excludeFields) {
		JsonConfig jsonConfig = new JsonConfig();
		if (timestampFields != null) {
			Arrays.sort(timestampFields);
			jsonConfig.registerJsonValueProcessor(long.class,
					new JsonValueProcessor() {

						@Override
						public Object processObjectValue(String key,
								Object value, JsonConfig jsonConfig) {
							if (LOG.isDebugEnabled()) {
								LOG.debug("key=" + key + ", value=" + value
										+ "; jsonConfig: " + jsonConfig);
							}
							if (Arrays.binarySearch(timestampFields, key) < 0) {
								return value;
							}
							long ts = (Long) value;
							return DateUtil.formatMillis(ts);
						}

						@Override
						public Object processArrayValue(Object value,
								JsonConfig jsonConfig) {
							return null;
						}
					});
		}
		if (excludeFields != null) {
			final List<String> fieldIndexes = Arrays.asList(excludeFields);
			jsonConfig.setRootClass(obj.getClass());
			jsonConfig.setJsonPropertyFilter(new PropertyFilter() {
				public boolean apply(Object source, String name, Object value) {
					return fieldIndexes.contains(name);
				}
			});
		}
		return JSONObject.fromObject(obj, jsonConfig).toString();
	}

	/**
	 * 将异常对象转换成JSON格式的字符串.
	 * 
	 * @param exception
	 *            待转换的异常对象
	 * @return JSON格式的字符串
	 * @creator liushen @ Feb 1, 2010
	 */
	public static String toJSON(Throwable exception) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("err", exception.toString());
		map.put("errClass", exception.getClass().getName());
		map.put("errMessage", exception.getMessage());
		map.put("mainCaller", ExceptionUtil.getMainCaller(exception));
		return toJSON(map);
	}

	/**
	 * 将给定的map转换为JSON格式的字符串.
	 * 
	 * @param map
	 *            待转换的Map对象
	 * @return JSON格式的字符串.
	 * @creator liushen @ Jun 8, 2009
	 */
	public static String toJSON(Map<String, Object> map) {
		return toMapJSON(map);
	}

	/**
	 * 将PagedList转成json对象
	 * 
	 * @param entities
	 *            pagedlist对象
	 * @param fields
	 *            待转换的对象
	 * @return json对象
	 * @since congli @ 2012-3-5
	 */
	public static String toJSONObj(PagedList<? extends Object> entities, String[] fields) {
		if (entities == null || entities.size() == 0) {
			return "[]";
		}
		if (fields == null) {
			fields = ReflectUtil.getAllFieldName(entities.get(0).getClass());
		}
		final List<String> fieldIndexes = new ArrayList<String>();
		for (int i = 0; i < fields.length; i++) {
			fieldIndexes.add(fields[i]);
		}
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return !fieldIndexes.contains(name);
			}
		});
		Map<String, Object> mapEntities = new TreeMap<String, Object>();
		mapEntities.put("firstPageNo", entities.getFirstPageNo());
		mapEntities.put("lastPageNo", entities.getLastPageNo());
		mapEntities.put("startPage", entities.getStartPage());
		mapEntities.put("endPage", entities.getEndPage());
		mapEntities.put("pageIndex", entities.getPageIndex());
		mapEntities.put("pageTotal", entities.getPageTotal());
		mapEntities.put("pageSize", entities.getPageSize());
		mapEntities.put("step", entities.getStep());
		mapEntities.put("thisPageTotal", entities.getThisPageTotal());
		mapEntities.put("totalItemCount", entities.getTotalItemCount());
		mapEntities.put("totalPageCount", entities.getTotalPageCount());
		mapEntities.put("items", JSONArray.fromObject(entities.getPageItems(), jsonConfig));
		//
		return toMapJSON(mapEntities);
	}

	/**
	 * @param map
	 * @return
	 */
	public static String toMapJSON(Map<String, Object> map) {
		if (map == null || map.isEmpty()) {
			return "{}";
		}
		JSONObject jsonObject = new JSONObject();
		Set<String> keys = map.keySet();
		for (String objKey : keys) {
			try {
				jsonObject.put(objKey, map.get(objKey));
			} catch (JSONException e) {
				throw new WrappedException(e);
			}
		}
		return jsonObject.toString();
	}

	/**
	 * 将数组类型的对象转换成JSON格式
	 * 
	 * @param objArray
	 *            待转换的数组对象
	 * @return 转换后的JSON格式
	 * @creator liushen @ Jun 8, 2009
	 * @deprecated Use {@link #toJSONArray(Object[])} instead
	 */
	@Deprecated
	public static final String toJSON(Object[] objArray) {
		return toJSONArray(objArray);
	}

	/**
	 * 将集合对象转换成JSON字符串；
	 * 
	 * @param entities
	 *            待转换的对象
	 * @return 转换后的JSON字符串
	 * @since fangxiang @ May 31, 2010
	 * @deprecated Use {@link #toJSONArray(List<? extends Object>)} instead
	 */
	@Deprecated
	public static String toJSON(List<? extends Object> entities) {
		return toJSONArray(entities);
	}

	/**
	 * 根据JSON串转换成Java Bean对象
	 * 
	 * JavaBean不能是嵌套类
	 * 
	 * @param json
	 *            JavaBean的JSON串
	 * @param objClazz
	 *            JavaBean对象类
	 * @return 对象
	 * @since fangxiang @ Oct 13, 2010
	 */
	public static Object fromJSON(String json,
			@SuppressWarnings("rawtypes") Class objClazz) {
		if (StringHelper.isEmpty(json)) {
			return null;
		}
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objClazz);
		JSONObject jsonObject = JSONObject.fromObject(json, jsonConfig);
		if (jsonObject == null || jsonObject.isEmpty()) {
			return null;
		}
		return JSONObject.toBean(jsonObject, jsonConfig);
	}

	/**
	 * 根据JSON串转换成JavaBean对象集合
	 * 
	 * @param json
	 *            JavaBean对象集合的JSON串
	 * @param objClazz
	 *            JavaBean对象类
	 * @return 对象集合
	 * @since fangxiang @ Oct 13, 2010
	 */
	public static List<Object> fromJSONArray(String json, Class<?> objClazz) {
		List<Object> objects = new ArrayList<Object>();
		if (StringHelper.isEmpty(json)) {
			return objects;
		}
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objClazz);
		JSONArray jsonArray = JSONArray.fromObject(json, jsonConfig);
		if (jsonArray.isEmpty()) {
			return objects;
		}
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			objects.add(JSONObject.toBean(jsonObject, objClazz));
		}
		return objects;
	}

	/**
	 * 根据JSON串转换成JavaBean对象集合
	 * 
	 * @param json
	 *            JavaBean对象集合的JSON串
	 * @param objClazz
	 *            JavaBean对象类
	 * @param transformFields
	 *            待转换的字段映射关系
	 * @return 对象集合
	 * @since fangxiang @ Oct 13, 2010
	 */
	public static List<Object> fromJSONArray(String json, Class<?> objClazz,
			Map<String, String> transformFields) {
		List<Object> objects = new ArrayList<Object>();
		if (StringHelper.isEmpty(json)) {
			return objects;
		}
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setRootClass(objClazz);
		//
		JSONArray jsonArray = JSONArray.fromObject(json, jsonConfig);
		if (jsonArray.isEmpty()) {
			return objects;
		}
		// 设置字段转换关系
		jsonConfig
				.setJavaIdentifierTransformer(new MapJavaIdentifierTransformer(
						transformFields));
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			objects.add(JSONObject.toBean(jsonObject, jsonConfig));
		}
		return objects;
	}

	/**
	 * 获取JSON串中某个字段的值.
	 * 
	 * @param jsonStr
	 *            完整JSON串
	 * @param fieldName
	 *            字段名
	 * @return 该字段的值
	 * @since liushen @ Feb 17, 2011
	 */
	public static String getValue(String jsonStr, String fieldName) {
		JSONObject jsonObj = JSONObject.fromObject(jsonStr);
		return jsonObj.getString(fieldName);
	}

	/**
	 * 断言所给的字符串符合JSON语法.
	 * 
	 * @param jsonStr
	 *            字符串
	 * @since liushen @ Mar 31, 2011
	 */
	public static void assertValidJSON(String jsonStr) {
		try {
			JSONObject.fromObject(jsonStr);
		} catch (Exception e) {
			throw new JsonException(e);
		}
	}

}
