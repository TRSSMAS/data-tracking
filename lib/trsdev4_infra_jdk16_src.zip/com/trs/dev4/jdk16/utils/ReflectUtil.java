/*
 * Created: liushen@Jun 5, 2009 5:19:43 PM
 */
package com.trs.dev4.jdk16.utils;

import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.ExceptionUtil;
import com.trs.dev4.jdk16.exception.ReflectException;

/**
 * 反射操作工具类; 注意：反射操作应该仅仅在底层和框架上使用, 应避免滥用反射而造成对面向对象的破坏!<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class ReflectUtil {

	private static final Logger LOG = Logger.getLogger(ReflectUtil.class);

	/**
	 * 将给定对象转换为Map对象.
	 * 
	 * @param obj
	 *            给定对象
	 * @return 该对象的所有field构成的Map对象，键为field名称，值为field对象本身.
	 * @creator liushen @ Jun 8, 2009
	 */
	public static Map<String, Object> toMap(Object obj) {
		if (obj == null) {
			return null;
		}

		Map<String, Object> map = new HashMap<String, Object>();
		Class<?> clazz = obj.getClass();
		Field[] fields = clazz.getDeclaredFields();
		for (Field field : fields) {
			if (false == field.isAccessible()) {
				field.setAccessible(true);
			}
			String fieldName = field.getName();
			try {
				map.put(fieldName, field.get(obj));
			} catch (Exception e) {
				LOG.error("skip an error: get value of field [" + fieldName + "] fail: " + ExceptionUtil.getBrief(e));
			}
		}
		return map;
	}

	/**
	 * 获取给定对象给定field的取值.
	 * 
	 * @param obj
	 *            给定对象
	 * @param fieldName
	 *            要获取的field的名称
	 * @return 如果field不存在返回<code>null</code>. 如果该field不为public, 也返回
	 *         <code>null</code>.
	 * @since liushen @ Aug 18, 2010
	 */
	public static Object getFieldValue(Object obj, String fieldName) {
		Class<?> clazz = obj.getClass();
		Field field = getField(clazz, fieldName);

		try {
			field.setAccessible(true);
			return field.get(obj);
		} catch (Exception e) {
			// IllegalArgumentException, IllegalAccessException
			LOG.error("fieldName: " + fieldName + ", obj: " + obj, e);
			return null;
		}
	}

	/**
	 * 设置给定对象给定field的值.
	 * 
	 * @param obj
	 *            给定对象
	 * @param fieldName
	 *            要设置的field的名称
	 * @param value
	 *            要设置的值
	 * @since liushen @ Aug 18, 2010
	 */
	public static void setFieldValue(Object obj, String fieldName, Object value) {
		Class<?> clazz = obj.getClass();
		Field field = getField(clazz, fieldName);
		if (Modifier.isStatic(field.getModifiers())) {
			return;
		}

		try {
			field.setAccessible(true);
			field.set(obj, value);
		} catch (Exception e) {
			LOG.error("fieldName: " + fieldName + ", obj: " + obj, e);
		}
	}

	/**
	 * 获取给定对象的给定名称的field.
	 * 
	 * @param clazz
	 *            给定对象
	 * @param fieldName
	 *            要获取的field的名称
	 * @return 符合条件的field对象. 如不存在则返回<code>null</code>
	 * @creator liushen @ Jun 8, 2009
	 */
	public static Field getField(Class<?> clazz, String fieldName) {
		for (Class<?> superClass = clazz; superClass != Object.class; superClass = superClass
				.getSuperclass()) {
			try {
				return superClass.getDeclaredField(fieldName);
			} catch (Exception e) {
				// SecurityException, NoSuchFieldException
			}
		}
		throw new ReflectException("no such field: " + fieldName + " in "
				+ clazz + " and it's super classes.");
	}

	/**
	 * 
	 * @param clazz
	 * @return
	 * @since liushen @ Jul 15, 2010
	 */
	public static String[] getAllFieldName(Class<?> clazz) {
		String[] saFields = new String[0];
		for (Class<?> superClass = clazz; superClass != Object.class; superClass = superClass
				.getSuperclass()) {
			Field[] fields = superClass.getDeclaredFields();
			saFields = ArrayUtil.expand(saFields, toNames(fields));
		}
		return saFields;
	}

	/**
	 * @param fields
	 * @return
	 * @since liushen @ Jul 16, 2010
	 */
	private static String[] toNames(Field[] fields) {
		String[] saFields = new String[fields.length];
		for (int i = 0; i < fields.length; i++) {
			saFields[i] = fields[i].getName();
		}
		return saFields;
	}

	/**
	 * @param obj
	 * @param methodName
	 * @return
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @creator liushen @ Jun 5, 2009
	 */
	public static Object invokePublicMethod(Object obj, String methodName)
			throws NoSuchMethodException, IllegalAccessException,
			InvocationTargetException {
		Method m = obj.getClass().getMethod(methodName);
		m.setAccessible(true);
		Object v = m.invoke(obj, (Object[]) null);
		return v;
	}

	/**
	 * 获取在给定的可标注元素(类、成员、方法等)上的所有标注。
	 * 
	 * @param annotatedElement
	 *            元素
	 * @return Annotation对象构成的数组
	 * @since liushen @ May 14, 2010
	 */
	public static Annotation[] getAnnotations(AnnotatedElement annotatedElement) {
		AssertUtil.notNull(annotatedElement, null);
		return annotatedElement.getAnnotations();
	}

	/**
	 * 获取在给定的可标注元素(类、成员、方法等)上声明的所有标注。
	 * 
	 * @param annotatedElement
	 *            元素
	 * @return Annotation对象构成的数组
	 * @since liushen @ May 14, 2010
	 */
	public static Annotation[] getDeclaredAnnotations(
			AnnotatedElement annotatedElement) {
		AssertUtil.notNull(annotatedElement, null);
		return annotatedElement.getDeclaredAnnotations();
	}

	/**
	 * 获取在类的给定字段上声明的所有标注。
	 * 
	 * @param clazz
	 *            类
	 * @param fieldName
	 *            字段名
	 * @return Annotation对象构成的数组
	 * @since liushen @ Jun 22, 2010
	 */
	public static Annotation[] getDeclaredAnnotations(Class<?> clazz,
			String fieldName) {
		Field field = getField(clazz, fieldName);
		return getDeclaredAnnotations(field);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List getAllFieldsWithImplementedInterface(Object anObj,
			Class cInterface) {
		List result = new ArrayList();
		Field[] fields = anObj.getClass().getDeclaredFields();
		Object obj = null;
		for (Field field : fields) {
			try {
				field.setAccessible(true);
				obj = field.get(anObj);
			} catch (Exception e) {
				continue;
			}
			if (obj == null) {
				continue;
			}
			if (ClassUtil.isImplementedInterface(obj.getClass(), cInterface)) {
				result.add(obj);
			}
		}
		return result;
	}

	/**
	 * 将字符串转换为对应的枚举对象(根据其字面值).
	 * 
	 * @param <T>
	 *            Enum type
	 * @param c
	 *            enum type.
	 * @param str
	 *            case sensitive
	 * @return corresponding enum, or null
	 * @see Enum#valueOf(Class, String)
	 */
	public static <T extends Enum<T>> T getEnumFromString(Class<T> c,
			String str) {
		if (c == null || str == null || str.length() == 0) {
			return null;
		}
		try {
			return Enum.valueOf(c, str);
		} catch (RuntimeException e) {
			// liushen @ Mar 13, 2011: from JDK 6 java.lang.Enum javadoc:
			// IllegalArgumentException - if the specified enum type has no
			// constant with the specified name, or the specified class
			// object does not represent an enum type
			// NullPointerException - if enumType or name is null
			return null;
		}
	}

}
