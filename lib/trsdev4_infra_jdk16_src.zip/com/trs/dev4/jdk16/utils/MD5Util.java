/*
 * Created: fangxiang@Apr 14, 2010 10:27:41 PM
 */
package com.trs.dev4.jdk16.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

/**
 * MD5加密工具
 * 
 * @deprecated liushen@Dec 12, 2010: 换用 {@link DigestUtil}
 */
@Deprecated
public class MD5Util {
	/**
	 *
	 */
	private static final Logger logger = Logger.getLogger(MD5Util.class);

	/**
	 * 生成给定数据的MD5摘要以完成加密过程.
	 * 
	 * @deprecated liushen@Dec 12, 2010: 换用 {@link DigestUtil#md5Hex(String)};
	 *             本实现已废弃(来自IDS1.0); 原因是方法名不明确，并且内部处理吞了异常
	 */
	@Deprecated
	public static String encrypt(String data) {
		if (data == null) {
			return "";
		}
		return getDigest(data);
	}

	/**
	 * 
	 * @param data
	 * @return
	 */
	private static String getDigest(String data) {
		return StringHelper.toString(getDigestBytes(data.getBytes()));
	}

	/**
	 * 
	 * @param data
	 * @return
	 */
	public static byte[] getDigestBytes(byte[] data) {
		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
		md5.update(data);
		logger.info("data:" + data);
		return md5.digest();
	}
}
