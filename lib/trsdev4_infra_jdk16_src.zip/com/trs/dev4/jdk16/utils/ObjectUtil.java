/*
 * Created: liushen@Mar 13, 2009 4:25:45 PM
 */
package com.trs.dev4.jdk16.utils;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.thoughtworks.xstream.XStream;

/**
 * 对Object的常用操作的封装. <BR>
 *
 * @author TRS信息技术有限公司
 */
public class ObjectUtil {

	/**
	 * 两个对象是否相等. 和obj1.equals(obj2)的区别是避免了obj1的NullPointer.
	 *
	 * @return (obj1 == null) ? (obj2 == null) : obj1.equals(obj2)
	 */
	public static boolean equals(Object obj1, Object obj2) {
		return (obj1 == null) ? (obj2 == null) : obj1.equals(obj2);
	}

	/**
	 *
	 * @param entities
	 * @return
	 * @since fangxiang @ Nov 26, 2010
	 */
	public static String toXML(List<?> entities) {
		XStream xs = new XStream();
		return xs.toXML(entities);
	}

	/**
	 *
	 * @param entities
	 * @return
	 * @since fangxiang @ Nov 26, 2010
	 */
	public static String toXML(Collection<?> entities) {
		return toXML(entities);
	}

	/**
	 *
	 * @param object
	 * @return
	 * @since fangxiang @ Nov 26, 2010
	 */
	public static String toXML(Object object){
		XStream xs = new XStream();
		return xs.toXML(object);
	}

	/**
	 * 
	 * @param entities
	 * @return
	 * @since fangxiang @ Nov 26, 2010
	 */
	public static String toJSON(List<?> entities) {
		return JSONUtil.toJSONArray(entities);
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 26, 2010
	 */
	public static String toJSON(Object object) {
		return JSONUtil.toJSON(object);
	}

	/**
	 * 
	 * @param entities
	 * @return
	 * @since fangxiang @ Nov 26, 2010
	 */
	public static String toJSON(Collection<?> entities) {
		return JSONUtil.toJSONArray(Arrays.asList(entities.toArray()));
	}
}
