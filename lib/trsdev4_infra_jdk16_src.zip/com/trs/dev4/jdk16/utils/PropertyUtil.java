/*
 * Created: liushen@Dec 17, 2008 9:28:54 PM
 */
package com.trs.dev4.jdk16.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.WrappedException;

import de.schlichtherle.io.FileOutputStream;

/**
 * 处理配置属性的工具类. <BR>
 * 
 * @author TRS信息技术有限公司
 */
public class PropertyUtil {

    private static final Logger LOG = Logger.getLogger(PropertyUtil.class);

	/** Prefix for property placeholders: "${" */
	public static final String PLACEHOLDER_PREFIX = "${";

	/** Suffix for property placeholders: "}" */
	public static final String PLACEHOLDER_SUFFIX = "}";

	/**
	 * 从指定文件名的文件中获取属性. <BR>
	 * 文件名参数说明: by converting the given pathname string into an abstract
	 * pathname.
	 * 
	 * @param fileName
	 *            给定的文件名
	 * @return 参见 {@link #loadProperties(File)}方法.
	 */
	public static Properties loadProperties(String fileName) {
		if (fileName == null) {
			return new Properties();
		}
		return loadProperties(new File(fileName));
	}

	/**
	 * 从给定文件中获取属性.
	 * 
	 * @param f
	 *            给定的文件
	 * @return 给定的文件中获取到的属性. 如果有异常发生, 则返回一个empty的属性.
	 */
	public static Properties loadProperties(File f) {
		Properties props = new Properties();
		if (f == null || false == f.isFile()) {
			return props;
		}
		InputStream fis = null;
		try {
			fis = new FileInputStream(f);
			props.load(fis);
		} catch (Exception e) {
			LOG.error("erron on load file: " + f, e);
		} finally {
			CloseUtil.closeInputStream(fis);
		}
		return props;
	}
	/**
	 * 从给定properties文件中读取给定key的属性. 本方法是仅读取一个key的情况时的便捷方法. 如果要读取多个key, 出于效率原因,
	 * 不要使用本方法, 此时请先获取到Properties, 再逐一读取.
	 * 
	 * @param f
	 * @param key
	 * @param defaultValue
	 */
	public static String loadProperty(File f, String key, String defaultValue) {
		Properties props = loadProperties(f);
		return props.getProperty(key, defaultValue);
	}
    /**
     * 从给定的资源文件获取属性. <BR>
     * 资源文件是指位于classpath中的文件.
     * @param resName 给定的资源文件
     * @return 给定的资源文件中获取到的属性. 如果有异常发生, 则返回一个empty的属性.
     */
    public static Properties loadFromResource(String resName) {
        return loadFromResource(PropertyUtil.class, resName);
    }

    /**
     * 从给定的资源文件获取属性. <BR>
     * 资源文件是指位于classpath中的文件.
     * @param resName 给定的资源文件
     * @return 给定的资源文件中获取到的属性. 如果有异常发生, 则返回一个empty的属性.
     */
	public static Properties loadFromResource(Class<?> clazz, String resName) {
        Properties props = new Properties();
        URL resUrl = clazz.getResource(resName);
        if (resUrl == null) {
			LOG.warn("resUrl=null! resName=" + resName);
            return props;
        }
        InputStream fis = null;
        try {
            fis = resUrl.openStream();
        } catch (IOException e) {
			LOG.error("erron on url.openStream(), url=" + resUrl, e);
        }
        
        try {
            props.load(fis);
        } catch (Exception e) {
			LOG.error("erron on load resource: " + resName + ", url=" + resUrl, e);
        } finally {
            // [ls@2005-02-05] The JDK doesn't close the inputstream, so we must close it.
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e1) {
					LOG.error("erron on close resource: " + resName + ", url=" + resUrl, e1);
                }
            }
        }
        return props;
    }
/**
	 * 从给定的资源文件获取以指定前缀开始的配置项的取值属性集合. <BR>
	 * 资源文件是指位于classpath中的文件.
	 * 
	 * @param resName
	 *            给定的资源文件
	 * @return 给定的资源文件中获取到的所有以指定前缀开始的配置项的属性.
	 * @see #assertAndLoadFromResource(Class, String)
	 */
	@SuppressWarnings({ "rawtypes" })
	public static Properties loadFromResource(Class clazz, String resName,
			String keyPrefix) {
		Properties props = assertAndLoadFromResource(clazz, resName);
		Properties result = new Properties();
		synchronized (props) {
			int max = props.size() - 1;
			Iterator it = props.entrySet().iterator();
			for (int i = 0; i <= max; i++) {
				Map.Entry e = (Map.Entry) (it.next());
				String key = (String) e.getKey();
				if (key.startsWith(keyPrefix)) {
					result.put(key, e.getValue());
				}
			}
		}
		return result;
	}
    /**
     * 解决properties中的${}相互引用，并将配置值进行trim处理。
     * @param props 给定的资源
     * @return 处理${}以后的新的资源。处理后的.Properties与参数传入的无关，传入的Properties不做修改。
     */
    public static Properties resovlePlaceHolderAndTrimValue(final Properties props) {
		Enumeration<?> e = props.keys();
    	
    	Properties props2 = new Properties() ;
		
		while(e.hasMoreElements()){
			String key = (String) e.nextElement() ;
			String value = props.getProperty(key) ;
			
			value = getTrimPlaceholdersString(props, key, value) ;
			value = value.trim() ;
			
			props2.put(key, value) ;
		}
		
		return props2 ;
    }

	/**
	 * 以int值返回给定的Properties对象中的指定项的取值. <BR>
	 * 如果Properties对象为null, 或Properties对象中找不到该key, 或该value解析成整数时发生异常, 则返回给定的默认值.
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项
	 * @param defaultValue
	 *            给定的默认值
	 * @return Properties对象中的指定项的取值
	 */
	public static int getPropertyAsInt(Properties props, String key,
			int defaultValue) {
		try {
			return assertAndGetAsInt(props, key);
		} catch (Exception e) {
			return defaultValue;
		}
	}

	/**
	 * 
	 * @param props
	 * @param key
	 * @return
	 * @throws IllegalArgumentException
	 * @throws NumberFormatException
	 * @since liushen @ May 16, 2010
	 */
	public static int assertAndGetAsInt(Properties props, String key) {
		String strValue = assertAndGet(props, key);
		AssertUtil.notNull(strValue, null);
		return Integer.parseInt(strValue.trim());
	}

	/**
	 * 
	 * @param props
	 * @param key
	 * @return 如果key不存在，则返回<code>null</code>.
	 * @since liushen @ May 16, 2010
	 */
	public static String assertAndGet(Properties props, String key) {
		AssertUtil.notNull(props, null);
		AssertUtil.notNull(key, null);

		return props.getProperty(key);
	}

	/**
	 * 以GBK编码的字符串值返回给定的Properties对象中的指定项的取值. <BR>
	 * 如果Properties对象为null或是Properties对象中找不到该key, 则返回空串("").
	 * 该方法用于处理从Properties文件中获取中文值的问题.
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项
	 * @return Properties对象中的指定项的取值
	 */
	public static String getPropertyAsGBK(Properties props, String key) {
		return getPropertyAsGBK(props, key, "");
	}

	/**
	 * 以GBK编码的字符串值返回给定的Properties对象中的指定项的取值. <BR>
	 * 如果Properties对象为null或是Properties对象中找不到该key, 则返回给定的默认值.
	 * 该方法用于处理从Properties文件中获取中文值的问题.
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项
	 * @param defaultValue
	 *            给定的默认值
	 * @return Properties对象中的指定项的取值
	 */
	public static String getPropertyAsGBK(Properties props, String key,
			String defaultValue) {
		if (props == null) {
			return defaultValue;
		}
		String strValue = props.getProperty(key);
		if (strValue == null) {
			return defaultValue;
		}
		try {
			return new String(strValue.getBytes("ISO-8859-1"), "GBK");
		} catch (Exception e) {
			return defaultValue;
		}
	}

	/**
	 * 返回给定的Properties对象中的指定项的字符串取值, 并作trim()处理. <BR>
	 * The method return defaultValue on one of these conditions: <li>props ==
	 * null <li>props.getProperty(key) == null <li>
	 * props.getProperty(key).trim().length() == 0
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项
	 * @param defaultValue
	 *            给定的默认值
	 * @return Properties对象中的指定项trim后的取值
	 */
	public static String getTrimString(Properties props, String key,
			String defaultValue) {
		if (props == null) {
			return defaultValue;
		}
		String strValue = props.getProperty(key);
		if (strValue == null) {
			return defaultValue;
		}
		strValue = strValue.trim();
		return strValue.length() == 0 ? defaultValue : strValue;
	}

	/**
	 * Fetch the value of the given key, and resolve ${...} placeholders , then
	 * trim() the value and return.
	 * 
	 * @param props
	 *            Properties
	 * @param key
	 *            the key to fetch
	 * @param defaultValue
	 *            return defaultValue on props is null or the key doesn't exsits
	 *            in props.
	 * @return the resolved value
	 * 
	 * @see #PLACEHOLDER_PREFIX
	 * @see #PLACEHOLDER_SUFFIX
	 */
	public static String getTrimPlaceholdersString(Properties props,
			String key, String defaultValue) {
		if (props == null) {
			return defaultValue;
		}
		String text = props.getProperty(key);
		if (text == null) {
			return defaultValue;
		}

		StringBuffer buf = new StringBuffer(text);

		// The following code does not use JDK 1.4's
		// StringBuffer.indexOf(String)
		// method to retain JDK 1.3 compatibility. The slight loss in
		// performance
		// is not really relevant, as this code will typically just run on
		// startup.

		int startIndex = text.indexOf(PLACEHOLDER_PREFIX);
		while (startIndex != -1) {
			int endIndex = buf.toString().indexOf(PLACEHOLDER_SUFFIX,
					startIndex + PLACEHOLDER_PREFIX.length());
			if (endIndex != -1) {
				String placeholder = buf.substring(startIndex
						+ PLACEHOLDER_PREFIX.length(), endIndex);
				String propVal = props.getProperty(placeholder);
				if (propVal != null) {
					buf.replace(startIndex, endIndex+ PLACEHOLDER_SUFFIX.length(), propVal);
					startIndex = buf.toString().indexOf(PLACEHOLDER_PREFIX,startIndex + propVal.length());
				}
				else {
					LOG.warn("Could not resolve placeholder '" + placeholder
							+ "' in [" + text + "]");
					startIndex = buf.toString().indexOf(PLACEHOLDER_PREFIX,
							endIndex + PLACEHOLDER_SUFFIX.length());
				}
			} else {
				startIndex = -1;
			}
		}

		return buf.toString().trim();
	}

	/**
	 * Fetch the value of the given key, and resolve ${...} placeholders , then trim() the value and return.
	 * @param refProps Properties
	 * @param stringToResolve the string to resolve
	 * @return the resolved value
	 * 
	 * @see #PLACEHOLDER_PREFIX
	 * @see #PLACEHOLDER_SUFFIX
	 */
	public static String resolvePlaceholdersString(Properties refProps, String stringToResolve) {
		if (refProps == null) {
			return stringToResolve;
	    }
		
	    if (stringToResolve == null) {
	    	return stringToResolve;
	    }	
		
		StringBuffer buf = new StringBuffer(stringToResolve);

		// The following code does not use JDK 1.4's StringBuffer.indexOf(String)
		// method to retain JDK 1.3 compatibility. The slight loss in performance
		// is not really relevant, as this code will typically just run on startup.

		int startIndex = stringToResolve.indexOf(PLACEHOLDER_PREFIX);
		while (startIndex != -1) {
			int endIndex = buf.toString().indexOf(PLACEHOLDER_SUFFIX, startIndex + PLACEHOLDER_PREFIX.length());
			if (endIndex != -1) {
				String placeholder = buf.substring(startIndex + PLACEHOLDER_PREFIX.length(), endIndex);
				String propVal = refProps.getProperty(placeholder);
				
				if(propVal != null){
					propVal = propVal.trim() ;
				}
				
				if (propVal != null) {
					buf.replace(startIndex, endIndex + PLACEHOLDER_SUFFIX.length(), propVal);
					startIndex = buf.toString().indexOf(PLACEHOLDER_PREFIX, startIndex + propVal.length());
				}
				else {
					LOG.warn("Could not resolve placeholder '" + placeholder + "' in [" + stringToResolve + "]");
					startIndex = buf.toString().indexOf(PLACEHOLDER_PREFIX, endIndex + PLACEHOLDER_SUFFIX.length());
				}
			}
			else {
				startIndex = -1;
			}
		}

		return buf.toString().trim();
	}
	
	/**
	 * 以long值返回给定的Properties对象中的指定项的取值. 如果Properties对象中找不到该key, 则返回给定的默认值.
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项
	 * @param defaultValue
	 *            给定的默认值
	 * @return Properties对象中的指定项的取值
	 */
	public static long getPropertyAsLong(Properties props, String key,
			long defaultValue) {
		if (props == null) {
			return defaultValue;
		}
		String strValue = props.getProperty(key);
		if (strValue == null) {
			return defaultValue;
		}
		try {
			return Long.parseLong(strValue.trim());
		} catch (Exception e) {
			return defaultValue;
		}
	}

	/**
	 * 以基本类型boolean值返回给定的Properties对象中的指定项的取值. 如果Properties对象中找不到该key,
	 * 则返回给定的默认值. 表示布尔值的字符串大小写无关. 当且仅当表示布尔值的字符串为"true"时(忽略大小写), 返回true. 例如:
	 * <tt>Boolean.valueOf("True")</tt> returns <tt>true</tt>.<br>
	 * 再如: <tt>Boolean.valueOf("yes")</tt> returns <tt>false</tt>.
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项
	 * @param defaultValue
	 *            给定的默认值
	 * @return Properties对象中的指定项的取值. 当且仅当表示布尔值的字符串为"true"时(忽略大小写), 返回true.
	 */
	public static boolean getPropertyAsBool(Properties props, String key,
			boolean defaultValue) {
		if (props == null) {
			return defaultValue;
		}
		String strValue = props.getProperty(key);
		if (strValue == null || "".equals(strValue)) {
			return defaultValue;
		}
		try {
			// [liushen@2005-02-23]内联方法Boolean.valueOf(strValue).booleanValue()的实现,去除多余操作
			return strValue.trim().equalsIgnoreCase("true");
		} catch (Exception e) {
			return defaultValue;
		}
	}

	/**
	 * 以字符串数组返回给定的Properties对象中的指定项的取值. <BR>
	 * <BR>
	 * 下列情况下, 本方法返回null: <li>给定的Properties对象为null. <li>给定的Properties对象中找不到该key.
	 * <li>给定的Properties对象中该key对应的字符串值为空(即<code>trim().length() == 0</code>).
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项. 不允许为null.
	 * @param token
	 *            将字符串分割为字符串数组的分隔标记. 不允许为null.
	 * @return Properties对象中的指定项的字符串数组取值.
	 */
	public static String[] getPropertyAsStrAry(Properties props, String key,
			String token) {
		if (props == null) {
			return null;
		}
		String value = props.getProperty(key);
		if (value == null) {
			return null;
		}
		value = value.trim();
		if (value.length() == 0) {
			return null;
		}
		return value.split(token);
	}

	/**
	 * 以float值返回给定的Properties对象中的指定项的取值. 如果Properties对象中找不到该key, 则返回给定的默认值.
	 * 
	 * @param props
	 *            给定的Properties对象
	 * @param key
	 *            指定项. 不允许为null.
	 * @param defaultValue
	 *            给定的默认值
	 * @return Properties对象中的指定项的取值
	 */
	public static float getPropertyAsFloat(Properties props, String key,
			float defaultValue) {
		if (props == null) {
			return defaultValue;
		}
		String strValue = props.getProperty(key);
		if (strValue == null) {
			return defaultValue;
		}
		try {
			return Float.parseFloat(strValue.trim());
		} catch (Exception e) {
			return defaultValue;
		}
	}

	/**
	 * 输出给定的JDK Properties对象中以给定字符串为前缀的所有Key及其取值. <BR>
	 * 由于JDK Properties类自己的toString()方法得到的是所有key及其取值, 有时使得调试信息中无用的部分太多, 所以提供本方法.
	 * 
	 * @param props
	 *            给定的JDK Properties对象
	 * @param keyPrefix
	 *            给定的key前缀
	 * @return Properties对象中以给定字符串为前缀的所有Key及其取值组成的字符串.
	 */
	@SuppressWarnings({ "rawtypes" })
	public static String toString(Properties props, String keyPrefix) {
		if (props == null || keyPrefix == null) {
			return "null! keyPrefix=" + keyPrefix;
		}
		final String delit = ", ";
		final int delitLen = delit.length();
		StringBuffer sb = new StringBuffer(64);
		sb.append('{');
		// 添加符合条件(以给定字符串开头)的Key的信息. 借鉴JDK
		// Hashtable类(Properties类的父类)自己的toString过程的算法.
		synchronized (props) {
			int max = props.size() - 1;
			Iterator it = props.entrySet().iterator();
			for (int i = 0; i <= max; i++) {
				Map.Entry e = (Map.Entry) (it.next());
				String key = (String) e.getKey();
				if (key.startsWith(keyPrefix)) {
					sb.append(key).append('=').append(e.getValue());
					sb.append(delit);
				}
			}
		}
		sb.delete((sb.length() > delitLen) ? (sb.length() - delitLen) : 1, sb
				.length());
		sb.append('}');
		return sb.toString();
	}

	/**
	 * 获取给定的JDK Properties对象中以给定字符串为前缀的所有Key及其取值组成的Properties对象. <BR>
	 * 
	 * @param props
	 *            给定的JDK Properties对象
	 * @param keyPrefix
	 *            给定的key前缀
	 * @return Properties对象中以给定字符串为前缀的所有Key及其取值组成的Properties对象.
	 */
	@SuppressWarnings({ "rawtypes" })
	public static Properties getSubProperties(Properties props, String keyPrefix) {
		if (props == null || keyPrefix == null) {
			return props;
		}
		Properties result = new Properties();
		synchronized (props) {
			int max = props.size() - 1;
			Iterator it = props.entrySet().iterator();
			for (int i = 0; i <= max; i++) {
				Map.Entry e = (Map.Entry) (it.next());
				String key = (String) e.getKey();
				if (key.startsWith(keyPrefix)) {
					result.put(key, e.getValue());
				}
			}
		}
		return result;
	}

	/**
	 * 获取给定的JDK Properties对象中以给定字符串为前缀的所有Key及其取值做trim处理后的值组成的Properties对象. <BR>
	 * 
	 * @param props
	 *            给定的JDK Properties对象
	 * @param keyPrefix
	 *            给定的key前缀
	 * @since ls@07-1122
	 */
	@SuppressWarnings({ "rawtypes" })
	public static Properties getTrimedSubProperties(Properties props,
			String keyPrefix) {
		if (props == null || keyPrefix == null) {
			return props;
		}
		Properties result = new Properties();
		synchronized (props) {
			int max = props.size();
			Iterator it = props.keySet().iterator();
			for (int i = 0; i < max; i++) {
				String key = (String) (it.next());
				if (key.startsWith(keyPrefix)) {
					String value = props.getProperty(key);
					if (value != null) {
						result.put(key, value.trim());
					}
				}
			}
		}
		return result;
	}

	/**
	 * 从给定的资源文件加载所有属性. <BR>
	 * 资源文件是指位于classpath中的文件.
	 * 
	 * @param clazz
	 *            从哪个类的classpath中寻找该资源文件
	 * @param resourcePath
	 *            资源文件在classpath中的路径
	 * @return 加载到的所有属性构成的Properties对象.
	 * @see ClassUtil#assertAndLocateResource(Class, String)
	 * @throws WrappedException
	 */
	public static Properties assertAndLoadFromResource(Class<?> clazz,
			String resourcePath) {
		URL resUrl = ClassUtil.assertAndLocateResource(clazz, resourcePath);
		InputStream fis = null;
		try {
			fis = resUrl.openStream();
		} catch (IOException e) {
			throw new WrappedException(
					"erron on url.openStream(), url=" + resUrl, e);
		}

		Properties props = new Properties();
		try {
			props.load(fis);
		} catch (IOException e) {
			throw new WrappedException("erron on load resource: " + resourcePath
					+ ", url=" + resUrl, e);
		} finally {
			// [ls@2005-02-05] JDK doesn't close the stream, so we must close
			// it.
			CloseUtil.closeInputStream(fis);
		}
		return props;
	}

	/**
	 * 从给定的xml格式的资源文件加载所有属性；(从JDK1.5，Properties加入了xml格式的支持). <BR>
	 * 资源文件是指位于classpath中的文件.
	 * 
	 * @param clazz
	 *            从哪个类的classpath中寻找该资源文件
	 * @param resourcePath
	 *            xml格式的资源文件在classpath中的路径
	 * @return 加载到的所有属性构成的Properties对象.
	 * @see ClassUtil#assertAndLocateResource(Class, String)
	 * @throws WrappedException
	 * @since liushen @ Aug 27, 2010
	 */
	public static Properties assertAndLoadFromXmlResource(Class<?> clazz,
			String resourcePath) {
		URL resUrl = ClassUtil.assertAndLocateResource(clazz, resourcePath);
		InputStream fis = null;
		try {
			fis = resUrl.openStream();
		} catch (IOException e) {
			throw new WrappedException("erron on url.openStream(), url="
					+ resUrl, e);
		}
		Properties props = new Properties();
		try {
			props.loadFromXML(fis);
		} catch (IOException e) {
			throw new WrappedException("erron on load resource: " + resourcePath
					+ ", url=" + resUrl, e);
		} finally {
			CloseUtil.closeInputStream(fis);
		}
		return props;
	}

	/**
	 * 从给定的xml格式的Properties文件加载所有属性.
	 * 
	 * @see #assertAndLoadFromXmlResource(Class, String)
	 * @since liushen @ May 23, 2011
	 */
	public static Properties loadFromXmlFile(File xmlFile) {
		Properties props = new Properties();
		if (xmlFile == null || false == xmlFile.isFile()) {
			return props;
		}
		InputStream fis = null;
		try {
			fis = new FileInputStream(xmlFile);
			props.loadFromXML(fis);
		} catch (Exception e) {
			LOG.error("erron on load file: " + xmlFile, e);
		} finally {
			CloseUtil.closeInputStream(fis);
		}
		return props;
	}

	/**
	 * 从给定的资源文件获取属性. <BR>
	 * 资源文件是指位于classpath中的文件.
	 * 
	 * @param resName
	 *            给定的资源文件
	 * @return 给定的资源文件中获取到的属性. 如果有异常发生, 则返回一个empty的属性.
	 * @throws IllegalArgumentException
	 * @throws NoSuchFileException
	 * @throws FailedException
	 */
	public static Properties assertAndLoadFromResource(String resName) {
		return assertAndLoadFromResource(PropertyUtil.class, resName);
	}

	/**
	 * 从JVM系统属性中获取给定开关项的值.
	 * 
	 * @param key
	 * @return 当前仅当存在该开关配置为<code>"true"</code>时返回<code>true</code>.
	 * @since liushen @ Apr 19, 2011
	 */
	public static boolean getSysPropertyAsBool(String key) {
		return getPropertyAsBool(System.getProperties(), key, false);
	}

	/**
	 * 写入给定的Properties到给定的xml文件中; 如果文件不存在会先创建。
	 * 
	 * @since liushen @ Jun 23, 2011
	 */
	public static void storeToXMLFile(Properties props, File file) {
		if (props == null || props.size() == 0) {
			return;
		}
		if (file == null) {
			throw new IllegalArgumentException("file is null!");
		}
		if (false == file.exists()) {
			FileUtil.createNewFile(file);
		}
		OutputStream os = null;
		try {
			os = new FileOutputStream(file);
			props.storeToXML(os, null, "UTF-8");
		} catch (IOException e) {
			LOG.error("fail to store " + props.size() + " properties to "
					+ file + ".", e);
			throw new WrappedException(e);
		} finally {
			CloseUtil.closeOutputStream(os);
		}
	}

}