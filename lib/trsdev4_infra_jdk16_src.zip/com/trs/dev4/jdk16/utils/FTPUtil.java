/*
 * Created: lichuanjiao@2009-12-21 下午03:41:45
 */
package com.trs.dev4.jdk16.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.net.ProtocolCommandEvent;
import org.apache.commons.net.ProtocolCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPFileFilter;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.RemoteException;
import com.trs.dev4.jdk16.exception.WrappedException;
import com.trs.dev4.jdk16.file.IFile;
import com.trs.dev4.jdk16.file.IProgressListener;
import com.trs.dev4.jdk16.file.impl.FtpFileImpl;

/**
 * FTP工具类.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class FTPUtil {

	private static final Logger LOG = Logger.getLogger(FTPUtil.class);

	/**
	 * 测试是否能连接成功；如果提供了帐号信息，则还将测试能否登录成功.
	 * 
	 * @param host
	 * @param port
	 * @param userName
	 *            用户名；如为空则不进行登录测试.
	 * @param passwd
	 * @since liushen @ Apr 3, 2011
	 */
	public static String tryConnectAndLogin(String host, int port,
			String userName, String passwd) {
		FTPClient ftp = makeFTPSession(host, port, userName, passwd, null);
		return ftp.getReplyString();
	}

	/**
	 * @param host
	 * @param port
	 * @return FTP服务端提示信息(一般含有软件名称和版本等)
	 * @since liushen @ Apr 11, 2011
	 */
	public static String tryConnect(String host, int port) {
		FTPClient ftp = makeFTPSession(host, port);
		return ftp.getReplyString();
	}

	/**
	 * 
	 * @param host
	 * @param port
	 * @param userName
	 * @param passwd
	 * @param encoding
	 *            用什么编码来解析文件名；如为空，则为<code>UTF-8</code>.
	 * @return
	 * @since liushen @ Apr 2, 2011
	 */
	static FTPClient makeFTPSession(String host, int port, String userName,
			String passwd, String encoding) {
		FTPClient ftp = makeFTPSession(host, port);
		ftp.setControlEncoding(StringHelper.avoidEmpty(encoding, "UTF-8"));
		if (false == StringHelper.isEmpty(userName)) {
			boolean loginSuccess;
			try {
				loginSuccess = ftp.login(userName, passwd);
			} catch (IOException e) {
				throw new WrappedException(e);
			}
			if (false == loginSuccess) {
				throw new WrappedException("FTP登录失败: " + ftp.getReplyString());
			}
		}
		return ftp;
	}

	private static boolean inDebugMode() {
		return PropertyUtil
				.getSysPropertyAsBool("dev4.infra.ftp.isDebug");
	}

	static void enterDebugMode() {
		System.setProperty("dev4.infra.ftp.isDebug", "true");
	}

	static void leaveDebugMode() {
		System.setProperty("dev4.infra.ftp.isDebug", "");
	}

	/**
	 * @param host
	 * @param port
	 * @return
	 * @since liushen @ Apr 11, 2011
	 */
	static FTPClient makeFTPSession(String host, int port) {
		FTPClient ftp = new FTPClient();
		if (inDebugMode()) {
			ftp.addProtocolCommandListener(new ProtocolCommandListener() {

				@Override
				public void protocolReplyReceived(ProtocolCommandEvent event) {
					System.out.print("Reply: " + event.getReplyCode() + " - "
							+ event.getMessage());
				}

				@Override
				public void protocolCommandSent(ProtocolCommandEvent event) {
					System.out.print("FTP> " + event.getCommand() + " - "
							+ event.getMessage());
				}
			});
		}
		// 只有日期没时间；按https://issues.apache.org/jira/browse/NET-140，也不行
		// FTPClientConfig conf = new FTPClientConfig();
		// conf.setDefaultDateFormatStr("yyyy-MM-dd HH:mm:ss");
		// conf.setRecentDateFormatStr("yyyy-MM-dd HH:mm:ss");
		// conf.setLenientFutureDates(true);
		// ftp.configure(conf);
		final int timeout = 10000;
		ftp.setDefaultTimeout(timeout);
		ftp.setDataTimeout(timeout);
		try {
			ftp.connect(host, port);
		} catch (IOException e) {
			throw new RemoteException("connect ftp://" + host + ":" + port
                    + " fail.", e);
		}
		try {
			ftp.setSoTimeout(timeout);
		} catch (SocketException e) {
			LOG.warn("setSoTimeout failed.");
		}
		return ftp;
	}

	/**
	 * 获取FTP服务器根目录的文件列表.
	 * 
	 * @see #list(String, int, String, String, String, String, String...)
	 */
	public static List<IFile> list(String host, int port,
			String userName, String passwd, String encoding) {
		return list(host, port, userName, passwd, encoding, "/");
	}

	/**
	 * 获取FTP服务器指定目录的文件列表；使用FTP被动模式.
	 * 
	 * @param host
	 *            FTP服务器域名、主机名或IP地址
	 * @param port
	 *            FTP服务器端口
	 * @param userName
	 *            FTP连接帐号; 如为空，则跳过此参数和密码参数
	 * @param passwd
	 *            该连接帐号的密码
	 * @param encoding
	 *            用什么编码来解析文件名；如为空，则为<code>UTF-8</code>.
	 * @param remoteDir
	 *            要获取FTP服务器哪个目录的文件清单
	 * @param exts
	 *            只列出哪些扩展名的文件(不区分大小写); 如果不指定，则列出全部文件；指定扩展名时含不含起始的<code>.</code>
	 *            均可；
	 * @since liushen @ Mar 29, 2011
	 */
	public static List<IFile> list(String host, int port, String userName,
			String passwd, String encoding, String remoteDir,
			final String... exts) {
		FTPClient ftp = makeFTPSession(host, port, userName, passwd, encoding);
		ftp.setListHiddenFiles(true);
		ftp.enterLocalPassiveMode();
		FTPFile[] files;
		String encodedDir = StringHelper.getStringByEncoding(remoteDir,
				encoding, "ISO8859-1");
		try {
			files = ftp.listFiles(encodedDir, new FTPFileFilter() {

				@Override
				public boolean accept(FTPFile ftpFile) {
					String fileName = ftpFile.getName();
					// 排除掉.和..(有些FTP Server如ServU会返回这两个特殊目录)
					if (fileName.equals(".") || fileName.equals("..")) {
						return false;
					}
					if (exts.length == 0) {
						return true;
					}
					for (String ext : exts) {
						// liushen@Dec 26, 2011: 都转为小写再比较
						if (fileName.toLowerCase().endsWith(ext.toLowerCase())) {
							return true;
						}
					}
					return false;
				}
			});
		} catch (IOException e) {
			throw new WrappedException(e);
		}
		List<IFile> list = new ArrayList<IFile>(files.length);
		for (FTPFile ftpFile : files) {
			FtpFileImpl ff = new FtpFileImpl(ftpFile);
			list.add(ff);
		}
		return list;
	}

	/**
	 * @param ftp
	 * @param remoteDir
	 * @param srcFile
	 * @return
	 * @since liushen @ Apr 7, 2011
	 */
	static long getFileSize(FTPClient ftp, String remoteDir,
			final String srcFile, String encoding) {
		ftp.setListHiddenFiles(true); // 某些FTP Servr如TYP必须启用，否则列不出来
		String encodedDir = StringHelper.getStringByEncoding(remoteDir,
				encoding, "ISO8859-1");
		try {
			FTPFile[] files = ftp.listFiles(encodedDir, new FTPFileFilter() {
	
				@Override
				public boolean accept(FTPFile ftpFile) {
					String name = ftpFile.getName();
					return name.equals(srcFile);
				}
			});
			if (files == null || files.length == 0) {
				throw new WrappedException("file not exist: " + srcFile
						+ "; FTPSession encoding: " + ftp.getControlEncoding());
			}
			return files[0].getSize();
		} catch (IOException e) {
			throw new WrappedException(e);
		}
	}

	/**
	 * 
	 * @param host
	 * @param port
	 * @param userName
	 * @param passwd
	 * @param remoteDir
	 * @param remoteFile
	 * @param encoding
	 * @param localDir
	 * @param listener
	 * @return
	 * @since liushen @ Apr 7, 2011
	 */
	public static File download(String host, int port, String userName,
			String passwd, String remoteDir, final String remoteFile,
			String encoding, String localDir, IProgressListener listener) {
		return download(host, port, userName, passwd, remoteDir, remoteFile,
				encoding, localDir, null, listener);
	}

	/**
	 * 
	 * @param host
	 * @param port
	 * @param userName
	 * @param passwd
	 * @param encoding
	 * @param remoteDir
	 * @return
	 * @since liushen @ Apr 3, 2011
	 */
	public static File download(String host, int port, String userName,
			String passwd, String remoteDir, final String remoteFile,
			String encoding, String localDir,
			String localFile, IProgressListener listener) {
		FTPClient ftp = makeFTPSession(host, port, userName, passwd, encoding);
		ftp.enterLocalPassiveMode();
		try {
			ftp.setFileType(FTP.BINARY_FILE_TYPE);
		} catch (IOException e) {
			throw new WrappedException(e);
		}
		localDir = StringHelper.avoidEmpty(localDir,
				FileUtil.getCurrentWorkingDir());
		localFile = StringHelper.avoidEmpty(localFile, remoteFile);
		File resultFile = new File(localDir, localFile);
		OutputStream os;
		try {
			os = new FileOutputStream(resultFile);
		} catch (FileNotFoundException e) {
			throw new WrappedException(e);
		}
		long srcSize = getFileSize(ftp, remoteDir, remoteFile, encoding);
		InputStream is;
		final String remotePath = StringHelper.smartAppendSlashToEnd(remoteDir)
				+ remoteFile;
		try {
			// liushen @ Apr 6, 2011: 从实测看，RETR可以带dir，即cwd非必须
			// ftp.changeWorkingDirectory(remoteDir);
			String fileName = StringHelper.getStringByEncoding(remotePath,
					encoding, "ISO8859-1");
			is = ftp.retrieveFileStream(fileName);
		} catch (IOException e) {
			throw new WrappedException(e);
		}
		if (is == null) {
			throw new WrappedException("the remote file not exist: "
					+ remotePath + "; FTP Code: " + ftp.getReplyString());
		}
		try {
			IOUtil.copy(is, os, listener, srcSize);
		} catch (IOException e) {
			throw new WrappedException(e);
		} finally {
			CloseUtil.closeInputStream(is);
			CloseUtil.closeOutputStream(os);
		}
		return resultFile;
	}

	static void releaseSession(FTPClient ftp, String promptWhenErr) {
		try {
			if (!ftp.completePendingCommand()) {
				ftp.logout();
				ftp.disconnect();
			}
		} catch (IOException e) {
			LOG.warn("releaseSession failed: ", e);
		}
	}

	/**
	 * 测试连接
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param port
	 *            端口
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @return false:连接失败 true:连接成功
	 * @since lichuanjiao @ 2010-12-1
	 */
	public static boolean testConnection(String host, int port,
			String userName, String password, String controlEncoding) {
		boolean testResult = false;
		TRSFTPClient ftpClient = new TRSFTPClient();
		try {
			testResult = ftpClient.login(host, port, userName, password,
					controlEncoding);
		} catch (RuntimeException e) {
			// 服务器连接错误，还未到账号验证阶段，此异常在此吞没，结果统一为连接错误。
		}
		ftpClient.logout();
		return testResult;
	}

	/**
	 * 默认端口上传单个文件到默认位置
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param localFilePath
	 *            本地文件名称
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @param ignoreSameFile
	 *            false表示不上传FTPServer已经有的同名文件，true代表覆盖FTPServer上已经有的同名文件
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-18
	 */
	public static void uploadFile(String host, String userName,
			String password, String localFilePath, String controlEncoding,
			boolean ignoreSameFile) throws RuntimeException {
		uploadFile(host, 21, userName, password, localFilePath,
				controlEncoding, ignoreSameFile);
	}

	/**
	 * 指定端口上传单个文件默认位置
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param port
	 *            端口
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param localFilePath
	 *            本地文件名称
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @param ignoreSameFile
	 *            false表示不上传FTPServer已经有的同名文件，true代表覆盖FTPServer上已经有的同名文件
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-18
	 */
	public static void uploadFile(String host, int port, String userName,
			String password, String localFilePath, String controlEncoding,
			boolean ignoreSameFile) throws RuntimeException {
		TRSFTPClient ftpClient = new TRSFTPClient();
		ftpClient.login(host, port, userName, password, controlEncoding);
		ftpClient.upload(localFilePath, ignoreSameFile);
		ftpClient.logout();
	}

	/**
	 * 默认端口上传单个文件到目标位置
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param localFilePath
	 *            本地文件名称
	 * @param destPath
	 *            上传的目标位置,如：/myFile/info.txt
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @param ignoreSameFile
	 *            false表示不上传FTPServer已经有的同名文件，true代表覆盖FTPServer上已经有的同名文件
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-18
	 */
	public static void uploadFile(String host, String userName,
			String password, String localFilePath, String destPath,String controlEncoding,
			boolean ignoreSameFile) throws RuntimeException {
		uploadFile(host, 21, userName, password, localFilePath, destPath,
				controlEncoding, ignoreSameFile);
	}

	/**
	 * 指定端口上传单个文件到目标位置
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param port
	 *            端口
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param localFilePath
	 *            本地文件名称
	 * @param destPath
	 *            上传的目标位置,如：/myFile/info.txt
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @param ignoreSameFile
	 *            false表示不上传FTPServer已经有的同名文件，true代表覆盖FTPServer上已经有的同名文件
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-18
	 */
	public static void uploadFile(String host, int port, String userName,
			String password, String localFilePath, String destPath,
			String controlEncoding, boolean ignoreSameFile)
			throws RuntimeException {
		TRSFTPClient ftpClient = new TRSFTPClient();
		ftpClient.login(host, port, userName, password, controlEncoding);
		ftpClient.upload(localFilePath, destPath, ignoreSameFile);
		ftpClient.logout();
	}

	/**
	 * 默认端口删除默认位置上的指定文件
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param fileName
	 *            文件名称，含后缀名
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-17
	 */
	public static void deleteFile(String host, String userName,
			String password, String fileName, String controlEncoding)
			throws RuntimeException {
		deleteFile(host, 21, userName, password, fileName, controlEncoding);
	}

	/**
	 * 指定端口删除默认位置上的指定文件
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param port
	 *            端口
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param fileName
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-17
	 */
	public static void deleteFile(String host, int port, String userName,
			String password, String fileName, String controlEncoding)
			throws RuntimeException {
		TRSFTPClient ftpClient = new TRSFTPClient();
		ftpClient.login(host, port, userName, password,controlEncoding);
		ftpClient.delete(fileName);
		ftpClient.logout();
	}

	/**
	 * 默认端口删除指定位置上的指定文件
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param path
	 * @param fileName
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-17
	 */
	public static void deleteFile(String host, String userName,
			String password, String destPath, String fileName,
			String controlEncoding) throws RuntimeException {
		deleteFile(host, 21, userName, password, destPath, fileName,controlEncoding);
	}

	/**
	 * 指定端口删除指定位置上的指定文件
	 * 
	 * @param host
	 *            ip或者hostName
	 * @param port
	 *            端口
	 * @param userName
	 *            用户名
	 * @param password
	 *            密码
	 * @param path
	 * @param fileName
	 * @param controlEncoding
	 *            ftp服务器的编码方式,如果填写务必保证正确，否则请填null。
	 * @throws MAMException
	 * @creator lichuanjiao @ 2010-1-17
	 */
	public static void deleteFile(String host, int port, String userName,
			String password, String destPath, String fileName,
			String controlEncoding) throws RuntimeException {
		TRSFTPClient ftpClient = new TRSFTPClient();
		ftpClient.login(host, port, userName, password, controlEncoding);
		ftpClient.delete(destPath, fileName);
		ftpClient.logout();
	}

}
