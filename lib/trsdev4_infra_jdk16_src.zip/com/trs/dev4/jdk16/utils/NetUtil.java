/*
 * Created: changpeng@2009-6-1 下午01:58:50
 */
package com.trs.dev4.jdk16.utils;

import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * 职责: 网络相关的工具类.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class NetUtil {

	private static final Logger LOG = Logger.getLogger(NetUtil.class);

	/**
	 * 获得本机IP地址.
	 * 
	 * @return
	 * @creator changpeng @ 2009-6-1
	 */
	public static String getLocalHostIP() {
		try {
			InetAddress address = InetAddress.getLocalHost();
			return address.getHostAddress();
		} catch (UnknownHostException e) {
			return "unable getLocalHost! err: " + e;
		}
	}

	/**
	 * 获得本机主机名.
	 * 
	 * @return
	 * @creator changpeng @ 2009-6-1
	 */
	public static String getLocalHostName() {
		try {
			InetAddress address = InetAddress.getLocalHost();
			return address.getHostName();
		} catch (UnknownHostException e) {
			return "unable getLocalHost! err: " + e;
		}
	}

	/**
	 * 获得本机主机名和IP.
	 * 
	 * @return
	 * @creator liushen @ Jun 2, 2009
	 */
	public static String getLocalHost() {
		try {
			InetAddress address = InetAddress.getLocalHost();
			return address.toString();
		} catch (UnknownHostException e) {
			return "unable getLocalHost! err: " + e;
		}
	}

	/**
	 * 测试是否能与指定主机名或IP, 指定端口建立TCP连接.
	 * 
	 * @param host
	 *            给定的主机名或IP
	 * @param port
	 * @return 如果能成功建立TCP连接, 返回true; 否则返回false
	 */
	public static boolean canConnect(String host, int port) {
		if (host == null) {
			return false;
		}
		if (port < 0 || port > 65535) {
			return false;
		}
		host = host.trim();
		if (host.length() == 0) {
			return false;
		}

		Socket socket = null;
		try {
			socket = new Socket(host, port);
			return true;
		} catch (UnknownHostException e) {
			LOG.error("UnknownHost! host=" + host, e);
		} catch (IOException e) {
			LOG.error("IOException! host=" + host + ", port=" + port, e);
		} finally {
			CloseUtil.closeSocket(socket);
		}

		return false;
	}

	/**
	 * 获取本机的一个IP地址(非本地回环IP地址).
	 * 
	 * @return 本机的一个IP地址(排除本地回环IP地址)
	 * @since JDK1.4
	 */
	public static String getIPAddress() {
		Enumeration<?> nets = null;
		try {
			nets = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e) {
			e.printStackTrace();
		}
		if (nets == null) {
			return "";
		}
		NetworkInterface netInterface;
		for (; nets.hasMoreElements();) {
			netInterface = (NetworkInterface) nets.nextElement();
			/*
			 * if (logger.isDebugEnabled()) { logger.debug("name:" +
			 * netInterface.getName() + ", displayName:" +
			 * netInterface.getDisplayName()); }
			 */
			Enumeration<?> ips = netInterface.getInetAddresses();
			if (ips == null) {
				return "";
			}

			for (; ips.hasMoreElements();) {
				InetAddress address = (InetAddress) ips.nextElement();
				final String ipAddress = address.getHostAddress();
				if (ipAddress.equals("127.0.0.1")) {
					continue;
				}
				return ipAddress;
			}
		}
		return "";
	}

	/**
	 * 获取本机的所有IP地址.
	 * 
	 * @return 本机的所有IP地址(包括本地回环IP地址)
	 * @since JDK1.4
	 */
	public static InetAddress[] getAllInetAdresses() {
		Enumeration<?> nets = null;
		try {
			nets = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e) {
			LOG.error("fail to getNetworkInterfaces!", e);
		}
		if (nets == null) {
			return null;
		}
		NetworkInterface ni;
		Enumeration<?> ips;
		List<InetAddress> results = new ArrayList<InetAddress>();
		for (; nets.hasMoreElements();) {
			ni = (NetworkInterface) nets.nextElement();
			if (LOG.isDebugEnabled()) {
				LOG.debug("name:" + ni.getName() + ", displayName:" + ni.getDisplayName());
			}
			ips = ni.getInetAddresses();
			if (ips == null) {
				continue;
			}

			for (; ips.hasMoreElements();) {
				results.add((InetAddress) ips.nextElement());
			}
		}
		return results.toArray(new InetAddress[0]);
	}

	/**
	 * 获取本机所有IP，但会排除掉<code>127.0.0.1</code>。
	 */
	public static String[] getHostNameIps() {
		InetAddress[] ias = getAllInetAdresses();
		if (ias == null) {
			return null;
		}
		List<String> results = new ArrayList<String>();
		for (int i = 0; i < ias.length; i++) {
			if ("127.0.0.1".equals(ias[i].getHostAddress()) && ias.length > 1) {
				continue;
			}
			results.add(ias[i].toString());
		}
		return results.toArray(new String[0]);
	}

	/**
	 * 参见http://download.oracle.com/javase/1.4.2/docs/guide/net/properties.html
	 * 
	 * @return
	 * @since liushen @ Nov 22, 2011
	 */
	public static String getJavaNetHttpProxyHost() {
		return System.getProperty("http.proxyHost");
	}

	/**
	 * 
	 * @return
	 * @see #getJavaNetHttpProxyHost()
	 * @since liushen @ Nov 22, 2011
	 */
	public static int getJavaNetHttpProxyPort() {
		return PropertyUtil.getPropertyAsInt(System.getProperties(), "http.proxyPort", -1);
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Dec 30, 2011
	 */
	public static String getHttpClientProxyHost() {
		String proxy = System.getProperty("trsdev4.httpClient.proxyHost");
		return proxy;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Dec 30, 2011
	 */
	public static int getHttpClientProxyPort() {
		return PropertyUtil.getPropertyAsInt(System.getProperties(), "trsdev4.httpClient.proxyPort", -1);
	}

}
