/*
 * Created: fangxiang@Jan 27, 2011 9:07:53 AM
 */
package com.trs.dev4.jdk16.job;

/**
 * 定时任务执行接口
 */
public interface IJobExecutor {

	/**
	 * 根据jobDetail描述，执行一个定时任务<br>
	 * 执行过程如果出现异常，实现者需要自行处理，确保该接口方法不会抛出任何RunTimeException<br>
	 * 
	 * @param jobDetail
	 *            用于存储定时任务的基本属性
	 * @since zhangshi @ 2011-6-24
	 */
	public void execute(JobDetail jobDetail);

	/**
	 * 执行器的名字
	 * 
	 * @return
	 * @since fangxiang @ Jan 29, 2011
	 */
	public String getName();
}
