/*
 * Created: fangxiang@Jan 27, 2011 9:03:18 AM
 */
package com.trs.dev4.jdk16.job;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.trs.dev4.jdk16.model.BaseEntity;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 用户描述定时任务的属性，便于任务的持久化<br>
 * (如：任务名称，执行时间规则，执行器名称等)
 * 
 */
@Entity
@Table(name = "`JOBDETAILS`")
@SequenceGenerator(name = "SEQ_JOBDETAIL", sequenceName = "SEQ_JOBDETAIL")
@GenericGenerator(name = "idStrategy", strategy = "native", parameters = { @Parameter(name = "sequence", value = "SEQ_JOBDETAIL") })
public class JobDetail extends BaseEntity {

	/**
	 * @since TRS @ Mar 17, 2011
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 任务名称
	 */
	@Column(name = "`JOBNAME`", nullable = false, length = 20)
	private String jobName;

	/**
	 * 手动更新时间
	 */
	@Column(name = "`UPDATEDTIME`")
	private long updatedTime;

	/**
	 * 执行器名
	 */
	@Column(name = "`EXECUTORNODE`", length = 100)
	private String executorNode;

	/**
	 * 执行节点
	 */
	@Column(name = "`EXECUTORNAME`", length = 100)
	private String executorName;

	/**
	 * 周期
	 */
	@Column(name = "`PERIOD`")
	private int period;
	/**
	 * 间隔和延时的单位
	 */
	@Column(name = "`PERIODUNIT`", length = 100)
	@Enumerated(value = EnumType.STRING)
	private EJobDetailUnit periodUnit;

	/**
	 * 间隔和延时的单位
	 */
	@Column(name = "`DELAYUNIT`", length = 100)
	@Enumerated(value = EnumType.STRING)
	private EJobDetailUnit delayUnit;

	/**
	 * 延时
	 */
	@Column(name = "`DELAY`")
	private int delay;
	/**
	 * 状态
	 */
	@Column(name = "`STATUS`")
	@Enumerated(value = EnumType.STRING)
	private EJobDetailStatus status;

	/**
	 * 定期执行时间表达式：<br>
	 * 如："0 00 03 ? * *" 表示每天凌晨三点执行
	 */
	@Column(name = "`CRON`")
	private String cron;

	/**
	 * 调度任务的类型
	 */
	@Column(name = "`TYPE`")
	@Enumerated(value = EnumType.STRING)
	private EJobDetailType type;

	/**
	 * 执行任务参数
	 */
	@Column(name = "`PARAMETERS`", length = 1000)
	private String parameters;

	/**
	 * 获取任务名
	 * 
	 * @return
	 */
	public String getJobName() {
		return jobName;
	}

	/**
	 * 获取任务执行器的名字， 需提前由实例化，并且要实现IJobExecutor接口
	 * 
	 * @return
	 */
	public String getExecutorName() {
		return executorName;
	}

	/**
	 * 获取任务执行器的初始参数，参与以key=value方式，
	 * 
	 * @return
	 */
	public String getParameters() {
		return parameters;
	}

	/**
	 * 获取执行的间隔，单位是秒
	 * 
	 * @return
	 */
	public int getPeriodAsSecond() {
		return period;
	}

	/**
	 * 初始的延时
	 * 
	 * @return
	 */
	public int getDelayAsSecond() {
		return delay;
	}

	/**
	 * 获取任务的执行状态
	 * 
	 * @return
	 */
	public int getStatus() {
		return status.ordinal();
	}

	/**
	 * 获取执行的任务节点
	 * 
	 * @return
	 */
	public String getExecutorNode() {
		return executorNode;
	}

	/**
	 * 获取cron表达式
	 * 
	 * @return
	 */
	public String getCron() {
		return cron;
	}

	/**
	 * 
	 * @param cron
	 *            the {@link #cron} to set
	 */
	public void setCron(String cron) {
		this.cron = cron;
	}

	/**
	 * 获取任务需要使用的调度的类型：基于jdk、quartz
	 * 
	 * @return
	 * @since zhangshi @ 2011-6-23
	 */
	public EJobDetailType getType() {
		return type;
	}

	/**
	 * 
	 * @param type
	 *            the {@link #type} to set
	 * @since zhangshi @ 2011-6-23
	 */
	public void setType(EJobDetailType type) {
		this.type = type;
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Jan 29, 2011
	 */
	public Map<String, String> getParametersAsMap() {
		return StringHelper.isEmpty(this.parameters) ? null : StringHelper
				.parseAsMap(this.parameters);
	}

	/**
	 * @return the {@link #period}
	 */
	public int getPeriod() {
		return period;
	}

	/**
	 * @param period
	 *            the {@link #period} to set
	 */
	public void setPeriod(int period) {
		this.period = period;
	}

	/**
	 * @return the {@link #delay}
	 */
	public int getDelay() {
		return delay;
	}

	/**
	 * @param delay
	 *            the {@link #delay} to set
	 */
	public void setDelay(int delay) {
		this.delay = delay;
	}

	/**
	 * @param jobName
	 *            the {@link #jobName} to set
	 */
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	/**
	 * @param executorNode
	 *            the {@link #executorNode} to set
	 */
	public void setExecutorNode(String executorNode) {
		this.executorNode = executorNode;
	}

	/**
	 * @param executorName
	 *            the {@link #executorName} to set
	 */
	public void setExecutorName(String executorName) {
		this.executorName = executorName;
	}

	/**
	 * @param status
	 *            the {@link #status} to set
	 */
	public void setStatus(EJobDetailStatus status) {
		this.status = status;
	}

	/**
	 * @param parameters
	 *            the {@link #parameters} to set
	 */
	public void setParameters(String parameters) {
		this.parameters = parameters;
	}

	/**
	 * @return the {@link #periodUnit}
	 */
	public EJobDetailUnit getPeriodUnit() {
		return periodUnit;
	}

	/**
	 * @param periodUnit
	 *            the {@link #periodUnit} to set
	 */
	public void setPeriodUnit(EJobDetailUnit periodUnit) {
		this.periodUnit = periodUnit;
	}

	/**
	 * @return the {@link #delayUnit}
	 */
	public EJobDetailUnit getDelayUnit() {
		return delayUnit;
	}

	/**
	 * @param delayUnit
	 *            the {@link #delayUnit} to set
	 */
	public void setDelayUnit(EJobDetailUnit delayUnit) {
		this.delayUnit = delayUnit;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.BaseEntity#equals(java.lang.Object)
	 * @since TRS @ Mar 14, 2011
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof JobDetail) {
			JobDetail objDetail = (JobDetail) obj;
			return objDetail.updatedTime == this.updatedTime;
		}
		return false;
	}

	/**
	 * @return the {@link #updatedTime}
	 */
	public long getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * @param updatedTime
	 *            the {@link #updatedTime} to set
	 */
	public void setUpdatedTime(long updatedTime) {
		this.updatedTime = updatedTime;
	}

}
