/*
 * Created: TRS@Mar 14, 2011 11:23:02 PM
 */
package com.trs.dev4.jdk16.job;

/**
 * 职责: <br>
 *
 */
public enum EJobDetailUnit {

}
