/*
 * Created: zhangshi@2011-6-23 下午01:22:29
 */
package com.trs.dev4.jdk16.job.impl;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.JobDataMap;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import com.trs.dev4.jdk16.job.IJobExecutor;
import com.trs.dev4.jdk16.job.IJobListener;
import com.trs.dev4.jdk16.job.JobDetail;

/**
 * 职责: <br>
 * 
 * 基于quartz实现的定时任务
 * 
 */
public class QuartzJobService extends BaseJobService implements IJobListener {

	private final static Logger logger = Logger
			.getLogger(QuartzJobService.class);

	private Scheduler quartzScheduler;
	
	private Map<String, JobDetail> jobMap = new HashMap<String, JobDetail>();

	public static String JOB_KEY = "quartzJobKey";

	public static String JOB_EXECUTOR = "quartzJobExecutor";


	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#countJobs()
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public int countJobs() {
		return jobMap.size();
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobListener#beforeExecute(com.trs.dev4.jdk16.job.IJobExecutor,
	 *      com.trs.dev4.jdk16.job.JobDetail)
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public void beforeExecute(IJobExecutor jobExecutor, JobDetail jobDetail) {
		// TODO zhangshi@2011-6-23 下午01:23:56: Auto-generated method stub

	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobListener#afterExecuted(com.trs.dev4.jdk16.job.IJobExecutor,
	 *      com.trs.dev4.jdk16.job.JobDetail)
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public void afterExecuted(IJobExecutor jobExecutor, JobDetail jobDetail) {
		// TODO zhangshi@2011-6-23 下午01:23:56: Auto-generated method stub

	}

	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#cancelJob(com.trs.dev4.jdk16.job.JobDetail)
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	protected void cancelJob(JobDetail jobDetail) {
		// TODO zhangshi@2011-6-23 下午01:23:56: Auto-generated method stub
		try {
			quartzScheduler.deleteJob(jobDetail.getJobName(),
					jobDetail.getExecutorName());
		} catch (SchedulerException e) {
			logger.error("error while cancle job, job : " + jobDetail, e);
		}

	}

	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#scheduleJob(com.trs.dev4.jdk16.job.JobDetail)
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public void scheduleJob(JobDetail jobDetail) {
		// 如果传进来的job为null，则直接返回
		if(null == jobDetail){
			logger.debug("job is null, so return directly. ");
			return;
		}
		
		// 如果已经存在这个job，则cancle掉原job，再将新job重新放入调度队列
		if (jobMap.containsKey(jobDetail.getJobName())) {
			cancelJob(jobDetail);
			logger.debug("job is exist, so cancle it first . job : "
					+ jobDetail);
		}

		IJobExecutor jobExecutor = this.getExecutor(jobDetail);
		// 若执行job的jobExecutor为null，则直接返回
		if (jobExecutor == null) {
			logger.debug("Can't found jobExecutor with executorName("
					+ jobDetail.getExecutorName() + ").");
			return;
		}

		// 若cron表达式有误，则无法生成正确的表达式，则直接返回
		Trigger trigger = makeTrigger(jobDetail);
		if (trigger == null) {
			logger.debug("trigger is null, so return. jobDetail is : "
					+ jobDetail);
			return;
		}

		org.quartz.JobDetail job = null;
		try {
			job = new org.quartz.JobDetail(jobDetail.getJobName(),
					jobDetail.getExecutorName(), QuartzJob.class);
			JobDataMap dataMap = new JobDataMap();
			dataMap.put(JOB_KEY, jobDetail);
			dataMap.put(JOB_EXECUTOR, jobExecutor);
			job.setJobDataMap(dataMap);
			quartzScheduler.scheduleJob(job, trigger);
			jobMap.put(jobDetail.getJobName(), jobDetail);
		} catch (SchedulerException e) {
			logger.error("error while schedule job, quartz job : " + job
					+ "; jobDetail : " + jobDetail, e);
			return;
		}
	}

	private Trigger makeTrigger(JobDetail job) {
		CronTrigger trigger = new CronTrigger();
		try {
			trigger.setName(job.getExecutorName() + "-" + job.getJobName()
					+ "-trigger");
			trigger.setCronExpression(job.getCron());
		} catch (ParseException e) {
			logger.error("(triggerExpression)=" + job.getCron(), e);
			return null;
		}
		logger.debug("job trigger name: " + trigger.getName()
				+ ", trigger cron expression: " + job.getCron());
		return trigger;
	}
	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#start()
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public void start() {
		quartzScheduler = startScheduler();
		logger.info("SingletonMonitorJob started.");
	}

	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#stop()
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public void stop() {
		try {
			quartzScheduler.shutdown();
		} catch (SchedulerException e) {
			logger.error("error while shutdown the quartzScheduler. ", e);
		}
	}

	/**
	 * 初始化并启动quartz定时器
	 * 
	 * @return
	 * @since zhangshi @ 2011-6-23
	 */
	private Scheduler startScheduler() {
		Scheduler quartzScheduler = getScheduler();
		if (quartzScheduler == null)
			return null;
		try {
			quartzScheduler.start();
		} catch (SchedulerException e) {
			logger.error(
					"error while start quartzScheduler , quartzScheduler :"
							+ quartzScheduler, e);
		}
		logger.debug("QuartzScheduler server started.");
		return quartzScheduler;
	}

	private Scheduler getScheduler() {
		try {
			return StdSchedulerFactory.getDefaultScheduler();
		} catch (SchedulerException e) {
			logger.error(
					"error while getDefaultScheduler from StdSchedulerFactory , error : "
							+ e.getMessage(), e);
		}
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.job.impl.BaseJobService#existsJob(java.lang.String)
	 * @since zhangshi @ 2011-6-24
	 */
	@Override
	public boolean existsJob(String jobName) {
		return jobMap.containsKey(jobName);
	}

}
