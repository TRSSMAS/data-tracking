/*
 * Created: TRS@Mar 14, 2011 11:36:30 PM
 */
package com.trs.dev4.jdk16.job.impl;

import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.job.IJobDetailManager;
import com.trs.dev4.jdk16.job.JobDetail;
import com.trs.dev4.jdk16.model.BaseManager;

/**
 * 职责: <br>
 *
 */
@Service
public class JobDetailManager extends BaseManager<JobDetail> implements
		IJobDetailManager {

}
