/*
 * Created: fangxiang@Jan 27, 2011 9:19:34 AM
 */
package com.trs.dev4.jdk16.job.impl;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.trs.dev4.jdk16.job.IJobExecutor;
import com.trs.dev4.jdk16.job.IJobService;

/**
 * 自动查找并注册实现了{@link IJobExecutor}接口的类
 * 
 */
public class JobExecutorFinder implements BeanPostProcessor {
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(JobExecutorFinder.class);
	/**
	 * 
	 */
	@Resource(name = "jobService")
	private IJobService jobService;
	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessBeforeInitialization(java.lang.Object, java.lang.String)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		return bean;
	}

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessAfterInitialization(java.lang.Object, java.lang.String)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		if (IJobExecutor.class.isAssignableFrom(bean.getClass())) {
			logger.debug("Found IConfigurable(" + bean + ") with beanName("
					+ beanName + ").");
			jobService.registerExecutor((IJobExecutor) bean);
		}
		return bean;
	}

}
