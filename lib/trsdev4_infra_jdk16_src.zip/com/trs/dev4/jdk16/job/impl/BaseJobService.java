/*
 * Created: fangxiang@Jan 27, 2011 9:18:19 AM
 */
package com.trs.dev4.jdk16.job.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.job.IJobDetailManager;
import com.trs.dev4.jdk16.job.IJobExecutor;
import com.trs.dev4.jdk16.job.IJobService;
import com.trs.dev4.jdk16.job.JobDetail;

/**
 * 用于实现{@link IJobService}，提供基本的定时任务操作
 * 
 */
public abstract class BaseJobService implements IJobService {

	/**
	 *
	 */
	protected final Map<String, IJobExecutor> jobExecutors = new HashMap<String, IJobExecutor>();
	/**
	 *
	 */
	private final static Logger logger = Logger.getLogger(BaseJobService.class);
	/**
	 * 
	 */
	@Resource(name = "jobDetailManager")
	private IJobDetailManager jobDetailManager;

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public String getModuleName() {
		return this.getClass().getSimpleName();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#start()
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void start() {
		initializeLoader();
		scheduleJobs();
		logger.debug("JobService started.");
	}

	/**
	 * 
	 * 
	 * @since TRS @ Mar 17, 2011
	 */
	protected void initializeLoader() {
		JobDetail jobDetail = jobDetailManager.findUnique("JOBNAME",
				"jobDetailLoader");
		if (jobDetail == null) {
			jobDetail = new JobDetail();
			jobDetail.setJobName("jobDetailLoader");
			jobDetail.setExecutorName("jobDetailLoader");
			jobDetail.setExecutorNode("*");
			jobDetail.setDelay(10);
			jobDetail.setPeriod(60);
			this.saveOrUpdate(jobDetail);
		}
	}

	/**
	 * 取消任务
	 * 
	 * @param jobDetail
	 * @since fangxiang @ Jan 29, 2011
	 */
	protected abstract void cancelJob(JobDetail jobDetail);

	/**
	 * 
	 * 
	 * @since fangxiang @ Jan 29, 2011
	 */
	@Override
	public void scheduleJob(JobDetail jobDetail) {
		logger.debug("scheduleJob invoked.");
	}
	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#stop()
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void stop() {

	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void restart() {

	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#resetExecutorNode(java.util.List)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void resetExecutorNode(List<JobDetail> jobDetails) {
		for (JobDetail jobDetail : jobDetails) {
			resetExecutorNode(jobDetail);
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#resetExecutorNode(com.trs.dev4.jdk16.job.JobDetail)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void resetExecutorNode(JobDetail jobDetail) {
		jobDetailManager.saveOrUpdate(jobDetail);
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#saveOrUpdate(com.trs.dev4.jdk16.job.JobDetail)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void saveOrUpdate(JobDetail jobDetail) {
		jobDetailManager.saveOrUpdate(jobDetail);
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#listExecutorNames()
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public List<String> listExecutorNames() {
		return Arrays.asList(jobExecutors.keySet().toArray(new String[0]));
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#getJobExecutor(java.lang.String)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public IJobExecutor getJobExecutor(String name) {
		return jobExecutors.get(name);
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#delete(com.trs.dev4.jdk16.job.JobDetail)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void delete(JobDetail jobDetail) {
		jobDetailManager.delete(jobDetail);
		// this.cancelJob(jobDetail);
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#listAllAvailableJobs()
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public List<JobDetail> listAllAvailableJobs() {
		List<JobDetail> jobDetails = new ArrayList<JobDetail>();
		// 获取本节点的
		SearchFilter sfCurrent = SearchFilter.getDefault();
		sfCurrent.setMaxResults(-1);
		sfCurrent.addEqCondition("EXECUTORNODE", this.getNodeName());
		jobDetails.addAll(jobDetailManager.pagedObjects(sfCurrent)
				.getPageItems());
		// 获取所有节点的
		SearchFilter sfCommon = SearchFilter.getDefault();
		sfCommon.setMaxResults(-1);
		sfCommon.addEqCondition("EXECUTORNODE", "*");
		jobDetails.addAll(jobDetailManager.pagedObjects(sfCommon)
				.getPageItems());
		// 如果是主节点的话，则加载只属于主节点的
		if (this.isMaster()) {
			SearchFilter sfMaster = SearchFilter.getDefault();
			sfMaster.setMaxResults(-1);
			sfMaster.addEqCondition("EXECUTORNODE", "-");
			jobDetails.addAll(jobDetailManager.pagedObjects(sfMaster)
					.getPageItems());
		}
		return jobDetails;
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Mar 14, 2011
	 */
	protected boolean isMaster() {
		return true;
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Mar 14, 2011
	 */
	protected String getNodeName() {
		return "127.0.0.1";
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#pagedJobs(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public PagedList<JobDetail> pagedJobs(SearchFilter searchFilter) {
		return jobDetailManager.pagedObjects(searchFilter);
	}

	/**
	 * 
	 * @param jobDetail
	 * @return
	 * @since fangxiang @ Jan 29, 2011
	 */
	IJobExecutor getExecutor(JobDetail jobDetail) {
		String executorName = jobDetail.getExecutorName();
		return getJobExecutor(executorName);
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#registerExecutor(com.trs.dev4.jdk16.job.IJobExecutor)
	 * @since fangxiang @ Jan 27, 2011
	 */
	@Override
	public void registerExecutor(IJobExecutor jobExecutor) {
		jobExecutors.put(jobExecutor.getName(), jobExecutor);
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#scheduleJobs()
	 * @since TRS @ Feb 23, 2011
	 */
	@Override
	public void scheduleJobs() {
		List<JobDetail> jobDetails = this.listAllAvailableJobs();
		//
		this.preSchedule();
		//
		for (JobDetail jobDetail : jobDetails) {
			this.scheduleJob(jobDetail);
		}
		//
		this.postScheduled();
	}

	/**
	 * 重新规划任务前置处理
	 * 
	 * @since TRS @ Mar 17, 2011
	 */
	protected void preSchedule() {

	}

	/**
	 * 取消已经删除的的任务
	 * 
	 * @since TRS @ Mar 14, 2011
	 */
	protected void postScheduled() {

	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#listScheduledJobs()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public List<JobDetail> listScheduledJobs() {
		return new ArrayList<JobDetail>();
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#existsJob(java.lang.String)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public boolean existsJob(String jobName) {
		return false;
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#existsExecutor(java.lang.String)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public boolean existsExecutor(String executorName) {
		return jobExecutors.containsKey(executorName);
	}

	/**
	 * @param jobDetailManager
	 *            the {@link #jobDetailManager} to set
	 */
	public void setJobDetailManager(IJobDetailManager jobDetailManager) {
		this.jobDetailManager = jobDetailManager;
	}

	/**
	 * @see com.trs.dev4.jdk16.job.IJobService#countExecutors()
	 * @since zhangshi @ 2011-6-23
	 */
	@Override
	public int countExecutors() {
		return jobExecutors.size();
	}

}
