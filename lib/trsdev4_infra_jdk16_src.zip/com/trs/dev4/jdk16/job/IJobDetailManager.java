/*
 * Created: fangxiang@Jan 27, 2011 9:09:37 AM
 */
package com.trs.dev4.jdk16.job;

import com.trs.dev4.jdk16.model.IBaseManager;

/**
 * 定时任务的持久化管理
 * 
 */
public interface IJobDetailManager extends IBaseManager<JobDetail> {

}
