/*
 * Created: liushen@May 5, 2011 7:33:23 PM
 */
package com.trs.dev4.jdk16.schedule;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.ObjectUtil;

/**
 * 运行器, 负责执行并统计运行情况. <br>
 * 
 */
public class ScheduleRunner implements Runnable {

	private static final Logger LOG = Logger.getLogger(ScheduleRunner.class);

	/**
	 * 运行状态.<br>
	 */
	public static enum RunStatus {
		/**
		 * .
		 */
		IDLE,
		/**
		 * 
		 */
		RUNNING;
	}

	private ISchedulable schedulable;

	// ISchedulerListener listener;

	private RunStatus status = RunStatus.IDLE;

	private long failureTimes;

	private long successTimes;

	private long currRunTimestamp;

	private long lastRunTimestamp;

	private long lastRunDuration;

	private long maxDuration;

	private int fixedDelaySeconds;

	private Throwable lastException;

	private long lastErrorTimestamp;

	/**
	 * @param fixedDelaySeconds
	 * 
	 */
	ScheduleRunner(ISchedulable schedulable, int fixedDelaySeconds) {
		this.schedulable = schedulable;
		this.fixedDelaySeconds = fixedDelaySeconds;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public String getDisplayName() {
		return schedulable.getDisplayName();
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public String getSchedulabeClassName() {
		return schedulable.getClass().getName();
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public boolean isRunning() {
		return RunStatus.RUNNING.equals(status);
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getLastRunDuration() {
		return lastRunDuration;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getLastRunTimestamp() {
		return lastRunTimestamp;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getNextRunTimestamp() {
		return currRunTimestamp + lastRunDuration + (fixedDelaySeconds * 1000);
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getSuccessTimes() {
		return successTimes;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getRanTimes() {
		return successTimes + failureTimes;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getFailureTimes() {
		return failureTimes;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 5, 2011
	 */
	public long getMaxDuration() {
		return maxDuration;
	}

	/**
	 * @see java.lang.Runnable#run()
	 * @since liushen @ May 5, 2011
	 */
	@Override
	public void run() {
		status = RunStatus.RUNNING;
		currRunTimestamp = System.currentTimeMillis();
		try {
			schedulable.runOnce();
			successTimes++;
		} catch (Throwable t) {
			lastErrorTimestamp = System.currentTimeMillis();
			failureTimes++;
			lastException = t;
			LOG.error("error in this turn of " + schedulable, t);
		}
		lastRunDuration = getCurrEstimated();
		lastRunTimestamp = currRunTimestamp;
		status = RunStatus.IDLE;
		if (maxDuration < lastRunDuration) {
			maxDuration = lastRunDuration;
		}
	}

	/**
	 * 
	 * @return
	 * @since liushen @ May 6, 2011
	 */
	public long getCurrEstimated() {
		return System.currentTimeMillis() - currRunTimestamp;
	}

	/**
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @since liushen @ May 5, 2011
	 */
	@Override
	public boolean equals(Object obj) {
		if (false == obj instanceof ScheduleRunner) {
			return false;
		}
		ScheduleRunner another = (ScheduleRunner) obj;
		return ObjectUtil.equals(schedulable, another.schedulable);
	}

	/**
	 * 获取运行间隔.
	 */
	public int getDelay() {
		return fixedDelaySeconds;
	}

	/**
	 * @return the {@link #schedulable}
	 */
	public ISchedulable getSchedulable() {
		return schedulable;
	}

	/**
	 * @return the {@link #lastException}
	 */
	public Throwable getLastException() {
		return lastException;
	}

	/**
	 * @return the {@link #lastErrorTimestamp}
	 */
	public long getLastErrorTimestamp() {
		return lastErrorTimestamp;
	}

}
