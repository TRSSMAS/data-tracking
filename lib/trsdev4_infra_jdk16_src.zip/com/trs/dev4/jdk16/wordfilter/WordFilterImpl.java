package com.trs.dev4.jdk16.wordfilter;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.trs.dev4.jdk16.utils.CloseUtil;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.FileUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * @描述 过滤词引擎.可以实现分组xml字典的过滤处理，支持大小写不敏感，支持过滤词分级 ，支持标记颜色分级.
 * @作者 liang.xu
 * @author liu kaixuan. 重构程序，添加忽略过滤内容中的特殊符号功能，更改对外接口以方便应用使用，fix关闭文件流。
 * @创建时间 2006-7-10
 */
public class WordFilterImpl implements IWordFilter {
	protected static final Logger LOG = Logger.getLogger(WordFilterImpl.class);

	/** 词典 */
	protected Map<String, Dictionary> dicMap = new HashMap<String, Dictionary>();

	/** 系统过滤词 */
	protected final Dictionary systemDic = new Dictionary(
			Word.WORD_SYSTEM_GROUP);

	/**
	 * 重新加载的时间
	 */
	private long reloadedTime;
	/**
	 * 重新加载耗时
	 */
	private long reloadedDuration;

	/** 系统默字典键值 */
	public static final String SYSTEM_GROUP_DIC_NAME = "system";

	/** 忽略的字符 */
	private boolean[] ingoreChars = new boolean[65535];

	/** 忽略的字符 */
	private String stopChars = "";

	/**
	 * 过滤词反显使用标记开始部分。过滤词标红原理：标红内容=〉wordMarkPrefixStartTag + 标红的颜色 +
	 * wordMarkPrefixEndTag + 标红内容 + wordMarkSuffix
	 */
	private String wordMarkPrefixStartTag = "<FONT COLOR=";

	private String wordMarkPrefixEndTag = ">";

	private String wordMarkSuffix = "</FONT>";

	/** 用于分割查找到的过滤词的分割符 */
	private String wordSeparator = ", ";

	private int defaultFilterWordLevel = 3;

	/** 过滤词存放位置 */
	protected String filterWordFileURL;

	/** 是否将html代码中的过滤词标红 */
	private boolean markFilterWordInHtmlTag = false;

	/** 是否将html代码中的过滤词记录下来 */
	private boolean recordFilterWordInHtmlTag = true;

	private String[] allGroupNames = new String[0];

	private String[] allGroupNamesWithoutSystemGroup = new String[0];

	public WordFilterImpl() {
		for (int i = 0; i < ingoreChars.length; i++) {
			ingoreChars[i] = false;
		}

		// 过滤时忽略的字符。注意"<>"两个符号不能添加进去！！！否则会引起如：过滤 z<font
		// color=...，而过滤词含有zf，此时'<'被跳过，z<f被当作过滤词，造成html语法被破坏！
		// 同时不包括：" '
		// TODO 为了防止不必要的错误，去掉：: [ ] . # 符号.防止html, css, ubb代码错误。
		char[] m_ingoreChars = new char[] { ' ', '　', '!', '！', '“', '”', '‘',
				'’', '《', '》', ':', '：', '(', ')', '[', ']', '【', '】', '☆',
				'★', '{', '}', '（', '）', '！', '、', ';', ',', '.', '@', '&',
				'，', '；', '。', '*', '·', '…', '-', '_', '+', '×', '=', '#',
				'`', '~', '|', '/', '\\', '\n', '\t', '\r' };

		for (int i = 0; i < m_ingoreChars.length; i++) {
			ingoreChars[m_ingoreChars[i]] = true;
		}
	}

	public String[] getAllGroupNames(boolean incudeSystemGroup) {
		return incudeSystemGroup ? allGroupNames
				: allGroupNamesWithoutSystemGroup;
	}

	public MatchResult filter(String content, String groupName,
			boolean markContent) {
		return filter(content, new String[] { groupName }, markContent,
				this.markFilterWordInHtmlTag, this.recordFilterWordInHtmlTag);
	}

	public MatchResult filter(String content, String groupName,
			boolean markContent, boolean markFilterWordInHtmlTag,
			boolean recordFilterWordInHtmlTag) {
		return filter(content, new String[] { groupName }, markContent,
				markFilterWordInHtmlTag, recordFilterWordInHtmlTag);
	}

	public MatchResult filter(String content, String[] groupNames,
			boolean markContent) {
		return filter(content, groupNames, markContent,
				this.markFilterWordInHtmlTag, this.recordFilterWordInHtmlTag);
	}

	/**
	 *
	 * @param content
	 *            要过滤得内容
	 * @param groupNames
	 *            [] 过滤的组，如果仅使用系统过滤词表不分组，传入null
	 * @param markContent
	 *            是否标红要过滤的内容
	 * @param markFilterWordInHtmlTag
	 *            是否将html代码中的过滤词标红
	 * @param recordFilterWordInHtmlTag
	 *            是否将html代码中的过滤词记录下来
	 */
	public MatchResult filter(String content, String[] groupNames,
			boolean markContent, boolean markFilterWordInHtmlTag,
			boolean recordFilterWordInHtmlTag) {

		if (isBlank(content)) {
			return null;
		}

		// 根据词典组名称加载相应的过滤词典
		Dictionary[] subDictionaries = null;

		// liushen@Jan 18, 2011: 敏感词不存在分组时(比如尚未配置时)不要抛出数组越界等运行期错误
		if ((groupNames == null) || (groupNames.length == 0)) {
			subDictionaries = new Dictionary[0];
		} else {
			// 如果设置为*的话，则表示默认使用所有的组
			if ("*".equalsIgnoreCase(groupNames[0])) {
				groupNames = this.allGroupNames;
			}
			subDictionaries = new Dictionary[groupNames.length];

			// 把分组过滤词典加载进来。
			for (int i = 0; i < groupNames.length; i++) {
				String m_groupName = groupNames[i];

				if (m_groupName == null) { // will cause NullPointerException in
											// HashMap
					continue;
				}

				Dictionary m_dictionary = dicMap.get(m_groupName);

				// TODO: 检查systemDic是否存在这里面，如果在则删除，避免被两次检查。

				if (m_dictionary == null) { // this is a error!!!
					LOG.error("filterword dictionary not found. dictionary name:"
							+ m_groupName);
				} else if (m_dictionary.isEmpty()) {
					// 空词典是没有意义的，不加入。
					if (LOG.isDebugEnabled()) {
						LOG.debug("empty dictionary. pass it. name:"
								+ m_groupName);
					}
				} else {
					subDictionaries[i] = m_dictionary;
				}
			}
		}

		// 先用系统词典。如果系统词典没有，在用分组词典。
		Dictionary dictionary = systemDic;

		// 初始化
		LinkedList<Word> filterWords = null;
		boolean hitted = false;
		int contentLength = content.length();
		StringBuffer markedContentResult = markContent ? new StringBuffer(
				contentLength + 100) : null;
		StringBuffer wordList = null;
		char ch;

		// 跳过html标签部分
		boolean skipHtmlTag = !markFilterWordInHtmlTag
				&& !recordFilterWordInHtmlTag;

		// 已经遇到了多少个"<"
		int ltDeep = 0;

		// 当前字符是否在html标记中
		boolean inHtmlTagNow = false;

		// 在指定字符串内查找过滤字
		for (int posOfContent = 0; posOfContent < contentLength;) {
			char org_ch = content.charAt(posOfContent);
			ch = Character.toLowerCase(org_ch);

			if (ch == '<') {
				ltDeep++;
				inHtmlTagNow = true;
			}

			if (inHtmlTagNow) {
				if (ch == '>') {
					ltDeep--;
					if (ltDeep < 1) {
						inHtmlTagNow = false;
					}
				}
			}

			Word fw = dictionary.getWord(ch);
			hitted = false;

			// 当前使用的分组词典的序号
			int subDicIndex = 0;

			if (ch <= 65534 && !ingoreChars[ch]) { // 过滤词范围内

				// 如果在html标签中，并且可以跳过标签，就直接跳过去。省去无意义的过滤词检查开销。
				if (inHtmlTagNow && skipHtmlTag) {
					continue;
				}

				while (fw == null) { // 系统词典里面没有词，更换到下一个词典

					if (subDicIndex >= subDictionaries.length) {
						break;
					}

					Dictionary m_dic = subDictionaries[subDicIndex];

					if (m_dic != null) {
						fw = m_dic.getWord(ch);
					}

					subDicIndex++;
				}

				while (fw != null) {
					String hittedContent = getMatchedContent(fw, content,
							posOfContent);

					if (hittedContent != null) {

						if (!inHtmlTagNow || recordFilterWordInHtmlTag) {

							if (filterWords == null) {
								filterWords = new LinkedList<Word>();
							}

							filterWords.add(fw);

							if (wordList == null) {
								wordList = new StringBuffer(128);
								wordList.append(hittedContent);
							} else {
								wordList.append(wordSeparator);
								wordList.append(hittedContent);
							}
						}

						if (markContent) {
							if (!inHtmlTagNow || markFilterWordInHtmlTag) {
								markedContentResult
										.append(wordMarkPrefixStartTag);
								markedContentResult.append(fw.getColor());
								markedContentResult
										.append(wordMarkPrefixEndTag);
								markedContentResult.append(hittedContent);
								markedContentResult.append(wordMarkSuffix);
							} else {
								markedContentResult.append(hittedContent);
							}
						}

						posOfContent = posOfContent + hittedContent.length();

						hitted = true;
						break;
					}

					fw = fw.getNext();

					while (fw == null) { // 一个词典用完了，没有发现过滤词；更换到下一个词典

						if (subDicIndex >= subDictionaries.length) {
							break;
						}

						Dictionary m_dic = subDictionaries[subDicIndex];

						if (m_dic != null) {
							fw = m_dic.getWord(ch);
						}

						subDicIndex++;
					}

				}
			}

			if (!hitted) {
				if (markContent)
					markedContentResult.append(org_ch);
				posOfContent++;
			}
		}

		if (filterWords != null) {
			return new MatchResult(filterWords,
					markedContentResult == null ? null : markedContentResult
							.toString(),
					wordList.toString(), this.wordSeparator);
		}

		return null;
	}

	/**
	 * 判断是否含有一个过滤词，如果有返回命中的文本。如果没有返回null。
	 */
	protected String getMatchedContent(Word filterWord, String content,
			int startPosOfContent) {
		String filterWordContent = filterWord.getWord();

		int lengthOfContent = content.length();

		boolean lastChar = startPosOfContent == lengthOfContent;

		boolean m_hitted = true;
		int posOfFilterWord = 0, posOfContentBasedScanPos = 0;
		int pos_of_content = startPosOfContent + posOfContentBasedScanPos;

		for (posOfFilterWord = 0, posOfContentBasedScanPos = 0; posOfFilterWord < filterWordContent
				.length();) {
			pos_of_content = startPosOfContent + posOfContentBasedScanPos;

			if (pos_of_content >= lengthOfContent) { // 结束了
				break;
			}

			char m_word = Character.toLowerCase(content.charAt(pos_of_content));
			if (m_word > 65534) { // 不再过滤词范围内
				posOfContentBasedScanPos++;
				continue;
			}

			if (ingoreChars[m_word]) {
				posOfContentBasedScanPos++;
				continue;
			}
			if (filterWordContent.charAt(posOfFilterWord) != m_word) {
				m_hitted = false;
				break;
			}

			posOfFilterWord++;
			posOfContentBasedScanPos++;
		}

		if (m_hitted) { // 命中了，看看是不是content结束而造成了匹配一半循环结束报告命中。
			if (pos_of_content == lengthOfContent
					&& posOfFilterWord < filterWordContent.length()) {
				return null;
			}
		}

		if (m_hitted) { // 命中了, 读取命中的文本.
			if (startPosOfContent > pos_of_content && !lastChar) { // this is a
																	// error
				LOG.error("error found! IWordFilter failed to match content!("
						+ startPosOfContent + "-->" + pos_of_content + ")",
						new Exception());
				return null;
			}

			return content.substring(startPosOfContent, pos_of_content + 1);
		}

		if (StringHelper.isNotEmpty(filterWord.getUsedFuzzyQuery()) && filterWord.getUsedFuzzyQuery().equals("true")) {
			
		}
		
		return null;
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.wordfilter.IWordFilter#contains(java.lang.String,
	 *      java.lang.String)
	 */
	public boolean contains(String content, String groupName) {
		// 检测内容为null或空字符串，直接认为包含过滤词
		if (isBlank(content)) {
			return false;
		}

		Dictionary dictionary = dicMap.get(groupName);

		// 未找到指定词典
		if (dictionary == null) {
			LOG.error("未找到指定词典：" + groupName);

			dictionary = dicMap.get(SYSTEM_GROUP_DIC_NAME);
		}

		// liushen@Dec 22, 2010: 默认字典也不存在时，直接返回false
		if (dictionary == null) {
			return false;
		}

		// 在指定字符串内查找过滤字
		int contentLength = content.length();

		for (int i = 0; i < contentLength; i++) {
			Word fw = dictionary.getWord(content.charAt(i));
			while (fw != null) {
				String hittedContent = getMatchedContent(fw, content, i);
				if (hittedContent != null) {
					return true;
				}

				fw = fw.getNext();
			}
		}
		return false;
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.wordfilter.IWordFilter#canPass(java.lang.String,
	 *      java.lang.String, int)
	 */
	public boolean canPass(String content, String groupName, int level) {
		try {
			// 得到当前组过滤词列表
			MatchResult result = filter(content, groupName, false);

			if (result != null) {
				int m_level = result.getHighestLevel();
				if (m_level >= level)
					return false;
			}
		} catch (Exception e) {
			LOG.error(e);
			return false;
		}

		return true;
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.wordfilter.IWordFilter#logMatchResult(com.trs.dev4.jdk16.wordfilter.MatchResult,
	 *      java.lang.String, int, java.lang.String)
	 */
	public void logMatchResult(MatchResult result, String filteredObjectName,
			int filteredObjectId, String description) {
		// do nothing.
	}

	/**
	 * 加载过滤词词典
	 *
	 */
	public void reloadDicMap() throws Exception {
		if (StringHelper.isEmpty(filterWordFileURL)) {
			LOG.error("Filterword(" + filterWordFileURL + ") is null.");
			return;
		}
		if (!FileUtil.fileExists(filterWordFileURL)) {
			LOG.error("Filterword(" + filterWordFileURL + ") not exist.");
			return;
		}
		//
		LOG.info("Reloading filterwords from (" + filterWordFileURL + ")...");
		this.reloadedTime = DateUtil.getCurrentTimeMillis();
		this.reloadedDuration = -1;
		this.dicMap = loadDicMap(filterWordFileURL);
		this.reloadedDuration = DateUtil.getCurrentTimeMillis()
				- this.reloadedTime;
		if (LOG.isDebugEnabled()) {
			LOG.debug("Word Dictionary：" + dicMap + ",allGroupNames:"
					+ StringHelper.join(allGroupNames));
		}
	}

	/**
	 * @param dicUrl
	 * @param is
	 * @param dicMap
	 * @param groupNames
	 * @param groupNames2
	 * @throws Exception
	 * @since TRS @ Mar 2, 2011
	 */
	public Map<String, Dictionary> loadDicMap(String fileUrl)
			throws Exception {
		InputStream is = null;
		try {
			if (fileUrl.startsWith("classpath://"))
				is = WordFilterImpl.class.getClassLoader().getResourceAsStream(
						fileUrl.substring("classpath://".length()));
			else
				is = new FileInputStream(fileUrl);
			Element root = read(is).getRootElement();
			WordVisitorSupport visitor = new WordVisitorSupport(root, this);
			allGroupNames = visitor.getGroupNamesWithSystem().toArray(new String[0]);
			allGroupNamesWithoutSystemGroup = visitor.getGroupNames().toArray(new String[0]);
			LOG.debug("Loaded WordGroup："
					+ StringHelper
							.join(visitor.getGroupNames()
									.toArray(new String[0]), ";"));
			return visitor.getDicMap();
		} catch (Exception e) {
			LOG.error("加载词典失败，请检查属性配置文件以及词典文件是否正确。过滤词典文件：" + fileUrl, e);
			throw e;
		} finally {
			CloseUtil.closeInputStream(is);
		}
	}

	// 下面是工具方法



	/** 读词典XML文件，并返回DOM4j Document对象，供其它方法调用 */
	public static Document read(InputStream fileName) throws Exception {
		SAXReader reader = null;
		Document document = null;

		reader = new SAXReader();
		document = reader.read(fileName);
		return document;
	}

	/**
	 * @see com.trs.dev4.jdk16.wordfilter.IWordFilter#reloadDicMap(java.util.List)
	 * @since liushen @ Jan 14, 2011
	 */
	@Override
	public void reloadDicMap(List<Word> words) {
		List<String> listGroupNames = new ArrayList<String>();
		for (int i = 0; i < words.size(); i++) {
			Word fw = words.get(i);
			String groupName = fw.getGroup();
			if (this.dicMap.containsKey(groupName)) { // 已包含此组
				this.dicMap.get(groupName).addWord(fw.getWord(), fw.getLevel(),
						fw.getColor(),fw.getUsedFuzzyQuery());
			} else {
				Dictionary dic = new Dictionary(groupName);
				dic.setGroupName(groupName);
				dic.addWord(fw.getWord(), fw.getLevel(), fw.getColor());
				this.dicMap.put(groupName, dic);
				listGroupNames.add(groupName);
			}
		}
		allGroupNames = listGroupNames
				.toArray(new String[listGroupNames.size()]);
		allGroupNamesWithoutSystemGroup = allGroupNames;
	}

	/**
	 * 系统启动
	 * 
	 * @throws Exception
	 */
	public void init() {
		try {
			reloadDicMap();
		} catch (Exception e) {
			LOG.error("error loading filterword.", e);
		}
	}

	/** 判断是否为空对象和空字符 */
	public static boolean isBlank(String str) {
		return StringHelper.isEmpty(str);
	}

	public String getWordSeparator() {
		return wordSeparator;
	}

	public void setWordSeparator(String wordSeparator) {
		this.wordSeparator = wordSeparator;
	}

	public String getFilterWordFileURL() {
		return filterWordFileURL;
	}

	public void setFilterWordFileURL(String filterWordFileURL) {
		this.filterWordFileURL = filterWordFileURL;
		//
		try {
			reloadDicMap();
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
	}

	/** @deprecated */
	@Deprecated
	public boolean isSkipHtmlTag() {
		return !this.markFilterWordInHtmlTag && !this.recordFilterWordInHtmlTag;
	}

	/** @deprecated */
	@Deprecated
	public void setSkipHtmlTag(boolean skipHtmlTag) {
		this.markFilterWordInHtmlTag = !skipHtmlTag;
		this.recordFilterWordInHtmlTag = !skipHtmlTag;
	}

	public boolean isMarkFilterWordInHtmlTag() {
		return markFilterWordInHtmlTag;
	}

	public void setMarkFilterWordInHtmlTag(boolean markFilterWordInHtmlTag) {
		this.markFilterWordInHtmlTag = markFilterWordInHtmlTag;
	}

	public boolean isRecordFilterWordInHtmlTag() {
		return recordFilterWordInHtmlTag;
	}

	public void setRecordFilterWordInHtmlTag(boolean recordFilterWordInHtmlTag) {
		this.recordFilterWordInHtmlTag = recordFilterWordInHtmlTag;
	}

	public int getDefaultFilterWordLevel() {
		return defaultFilterWordLevel;
	}

	public void setDefaultFilterWordLevel(int defaultFilterWordLevel) {
		this.defaultFilterWordLevel = defaultFilterWordLevel;
	}

	public String getWordMarkPrefixEndTag() {
		return wordMarkPrefixEndTag;
	}

	public void setWordMarkPrefixEndTag(String wordMarkPrefixEndTag) {
		this.wordMarkPrefixEndTag = wordMarkPrefixEndTag;
	}

	public String getWordMarkPrefixStartTag() {
		return wordMarkPrefixStartTag;
	}

	public void setWordMarkPrefixStartTag(String wordMarkPrefixStartTag) {
		this.wordMarkPrefixStartTag = wordMarkPrefixStartTag;
	}

	public String getWordMarkSuffix() {
		return wordMarkSuffix;
	}

	public void setWordMarkSuffix(String wordMarkSuffix) {
		this.wordMarkSuffix = wordMarkSuffix;
	}

	public String getStopChars() {
		return stopChars;
	}

	public void setStopChars(String stopChars) {
		this.stopChars = stopChars;

		if (stopChars == null) {
			return;
		}

		for (int i = 0; i < stopChars.length(); i++) {
			char ch = stopChars.charAt(i);

			if (ch < 65535) {
				ingoreChars[ch] = true;
			}
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.wordfilter.IWordFilter#getStatistic()
	 * @since fangxiang @ Dec 28, 2010
	 */
	@Override
	public Map<String, Object> getStatistic() {
		Map<String, Object> statistic = new HashMap<String, Object>();
		statistic.put("reloadedTime", this.reloadedTime);
		statistic.put("reloadedDuration", this.reloadedDuration);
		statistic.put("groupNames", this.getAllGroupNames(true));
		Map<String,String> dictionaries = new HashMap<String,String>();
		for (String key : dicMap.keySet() ){
			Dictionary dictionary = dicMap.get(key);
			dictionaries.put(key, dictionary.listWords());
		}
		statistic.put("dictionaries", dictionaries);
		return statistic;
	}

	/**
	 * @see com.trs.dev4.jdk16.wordfilter.IWordFilter#getSystemDictionary()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public Dictionary getSystemDictionary() {
		return this.systemDic;
	}

	/**
	 * @see com.trs.dev4.jdk16.wordfilter.IWordFilter#ingoreChar(char)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public boolean ingoreChar(char ch) {
		return this.ingoreChars[ch];
	}

}
