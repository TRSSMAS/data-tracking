package com.trs.dev4.jdk16.wordfilter;

/**
 * @描述 过滤词引擎- 过滤词实体对象
 * @作者 liang.xu
 * @创建时间 2006-7-10
 */
public class Word {

	/**
	 * 标识
	 */
	private int id;
	/**
	 * 组
	 */
	private String group;
	/**
	 * 过滤词
	 */
	private String word;
	/**
	 * 过滤级别
	 */
	private int level;
	/**
	 * 过滤颜色
	 */
	private String color;

	/**
	 * 启用模糊查询
	 */
	private String usedFuzzyQuery;
	/**
	 * 链表中下一节点
	 */
	private Word next;

	public static String WORD_COLOR = "color";
	public static String WORD_LEVEL = "level";
	public static String WORD_GROUP = "group";
	public static String WORD_ID = "id";
	public static String WORD_SYSTEM_GROUP = "systemGroup";
	public static String WORD_USEDFUZZYQUERY = "usedFuzzyQuery";

	public Word getNext() {
		return next;
	}

	public void setNext(Word next) {
		this.next = next;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	@Override
	public String toString() {
		StringBuffer buff = new StringBuffer(64);
		buff.append(word).append("/").append(level).append("/").append(color);
		return buff.toString();
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the {@link #usedFuzzyQuery}
	 */
	public String getUsedFuzzyQuery() {
		return usedFuzzyQuery;
	}

	/**
	 * @param usedFuzzyQuery
	 *            the {@link #usedFuzzyQuery} to set
	 */
	public void setUsedFuzzyQuery(String usedFuzzyQuery) {
		this.usedFuzzyQuery = usedFuzzyQuery;
	}

}
