package com.trs.dev4.jdk16.wordfilter;

import java.util.List;
import java.util.Map;

/**
 * 过滤词引擎
 * 
 * @author bill
 * 
 */
public interface IWordFilter {

	/** 字典文件编码 */
	public static final String DICTIONARY_ENCODING = "filterword.dic.encoding";

	/** 过滤词默认颜色 */
	public static final String DICTIONARY_DEFAULT_COLOR = "filterword.default.color";

	/** 过滤词默认等级 */
	public static final String DICTIONARY_DEFAULT_LEVEL = "filterword.default.level";

	/** 系统级过滤词默认颜色 */
	public static final String DICTIONARY_SYSTEM_WORD_DEFAULT_COLOR = "filterword.system.default.color";

	public void reloadDicMap() throws Exception;

	/**
	 * 采用注入的方式，重新载入所有过滤词.
	 * 
	 * @since liushen @ Jan 14, 2011
	 */
	public void reloadDicMap(List<Word> words);
	/**
	 * 过滤一段文字，根据参数决定是否标红。如果不含有任何过滤词，返回null。
	 * 
	 * @param content
	 *            检测内容
	 * @param groupName
	 *            过滤词组名称
	 * @param markContent
	 *            是否同时标记过滤的内容。
	 * @return MatchResult
	 */
	public MatchResult filter(String content, String groupName,
			boolean markContent);

	/**
	 * 过滤一段内容。如果不含有任何过滤词，返回null。
	 * 
	 * @param content
	 *            要过滤得内容
	 * @param groupName
	 *            过滤的组，如果仅使用系统过滤词表不分组，传入null
	 * @param markContent
	 *            是否标红要过滤的内容
	 * @param markFilterWordInHtmlTag
	 *            是否将html代码中的过滤词标红
	 * @param recordFilterWordInHtmlTag
	 *            是否将html代码中的过滤词记录下来
	 */
	public MatchResult filter(String content, String groupName,
			boolean markContent, boolean markFilterWordInHtmlTag,
			boolean recordFilterWordInHtmlTag);

	/**
	 * 过滤一段内容。如果不含有任何过滤词，返回null。
	 * 
	 * @param content
	 *            要过滤得内容
	 * @param groupNames
	 *            [] 过滤的组，如果仅使用系统过滤词表不分组，传入null
	 * @param markContent
	 *            是否标红要过滤的内容
	 */
	public MatchResult filter(String content, String[] groupNames,
			boolean markContent);

	/**
	 * 过滤一段内容。如果不含有任何过滤词，返回null。
	 * 
	 * @param content
	 *            要过滤得内容
	 * @param groupNames
	 *            [] 过滤的组，如果仅使用系统过滤词表不分组，传入null
	 * @param markContent
	 *            是否标红要过滤的内容
	 * @param markFilterWordInHtmlTag
	 *            是否将html代码中的过滤词标红
	 * @param recordFilterWordInHtmlTag
	 *            是否将html代码中的过滤词记录下来
	 */
	public MatchResult filter(String content, String[] groupNames,
			boolean markContent, boolean markFilterWordInHtmlTag,
			boolean recordFilterWordInHtmlTag);

	/**
	 * 快速检测是否包含过滤词典中定义的过滤词 (不分级/不返回过滤词列表方式)
	 * 
	 * @param content
	 *            检测内容
	 * @param groupName
	 *            过滤词所在组
	 * @return 返回<code>true</code> 包含过滤词 反之不包含过滤词
	 */
	public boolean contains(String content, String groupName);

	/**
	 * 检测内容 可否通过滤词级别验证
	 * 
	 * @param content
	 *            检测内容
	 * @param groupName
	 *            对应词典
	 * @param level
	 *            过滤级别
	 */
	public boolean canPass(String content, String groupName, int level);

	/**
	 * 获取所有的过滤词分组
	 * 
	 * @param incudeSystemGroup
	 *            是否包含系统过滤词组
	 **/
	public String[] getAllGroupNames(boolean incudeSystemGroup);

	/** 返回过滤词文件的存放位置 */
	public String getFilterWordFileURL();

	/**
	 * 
	 * @param result
	 * @param filteredObjectName
	 * @param filteredObjectId
	 * @param description
	 */
	public void logMatchResult(MatchResult result, String filteredObjectName,
			int filteredObjectId, String description);

	/**
	 * 获取统计信息
	 * 
	 * @return
	 */
	public Map<String, Object> getStatistic();

	/**
	 * 获取系统词典
	 * 
	 * @return 系统词典
	 * @since TRS @ Mar 3, 2011
	 */
	public Dictionary getSystemDictionary();

	/**
	 * 是否为忽略字符
	 * 
	 * @param ch
	 * @return
	 * @since TRS @ Mar 3, 2011
	 */
	public boolean ingoreChar(char ch);
}
