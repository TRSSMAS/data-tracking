/*
 * Created: liuyou@2010-4-21 上午11:45:37
 */
package com.trs.dev4.jdk16.actionlog;

import java.util.Date;

/**
 * 职责: <br>
 * 
 */
public interface IActionlog {

	/**
	 * 日志编号
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	int getId();

	/**
	 * 设置编号
	 * 
	 * @param id
	 * @since liuyou @ 2010-4-21
	 */
	void setId(int id);

	/**
	 * 操作用户
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	String getOperUserName();

	/**
	 * 设置操作用户
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setOperUserName(String userName);

	/**
	 * 操作用户编号
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	int getOperUserId();

	/**
	 * 设置操作用户编号
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setOperUserId(int userid);

	/**
	 * 日志级别
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	LogEnums.Level getLogLevel();

	/**
	 * 设置日志级别
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setLogLevel(LogEnums.Level level);

	/**
	 * 操作类型
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	String getOperType();

	/**
	 * 设置操作类型
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setOperType(String operType);

	/**
	 * 对象类型
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	String getObjType();

	/**
	 * 设置对象类型
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setObjType(String objType);

	/**
	 * 对象编号
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	int getObjId();

	/**
	 * 设置对象编号
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setObjId(int id);

	/**
	 * 操作开始时间
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	Date getStartTime();

	/**
	 * 设置操作开始时间
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setStartTime(long time);

	/**
	 * 操作执行时长
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	long getSpentTime();

	/**
	 * 设置操作执行时长
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setSpentTime(long time);

	/**
	 * 操作结果
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	LogEnums.Result getResult();

	/**
	 * 设置操作结果
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setResult(LogEnums.Result result);

	/**
	 * 操作描述信息
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	String getOperDesc();

	/**
	 * 设置操作描述信息
	 * 
	 * @param userName
	 * @since liuyou @ 2010-4-21
	 */
	void setOperDesc(String operDesc);

	/**
	 * 操作标题
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	String getOperTitle();

	/**
	 * 设置操作标题
	 * 
	 * @param operTitle
	 * @since liuyou @ 2010-4-21
	 */
	void setOperTitle(String operTitle);

	/**
	 * 操作描述信息相关参数
	 * 
	 * @return
	 * @since liuyou @ 2010-4-21
	 */
	Object[] getOperArgs();

	/**
	 * 设置描述信息相关参数
	 * 
	 * @param objects
	 * @since liuyou @ 2010-4-21
	 */
	void setOperArgs(Object... objects);

	/**
	 * 
	 * @return
	 * @since fangxiang @ Nov 25, 2010
	 */
	String getRemoteAddr();
}
