/*
 * Created: liuyou@2010-4-21 下午02:16:53
 */
package com.trs.dev4.jdk16.actionlog.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.trs.dev4.jdk16.model.IEntity;

/**
 * 用于指定自动记录日志的Manager层接口
 * 
 */
@Target( { ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface LogMe {
	/**
	 * 操作的对象类型
	 * 
	 * @return 默认返回被注解的方法所在的类的泛型具体领域对象的类型
	 * @since liuyou @ 2010-5-23
	 */
	Class<? extends IEntity> classType() default IEntity.class;

	/**
	 * 对象类
	 * 
	 * @return
	 * @since fangxiang @ Nov 23, 2010
	 */
	int targetIndex() default 1;

	/**
	 * 操作类
	 * 
	 * @return
	 * @since fangxiang @ Nov 23, 2010
	 */
	Class<?> action() default String.class;

	/**
	 * 操作者变量名称
	 * 
	 * @return
	 * @since fangxiang @ Nov 23, 2010
	 */
	int operatorIndex() default 0;
}
