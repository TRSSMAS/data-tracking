/*
 * Created: fangxiang@Nov 24, 2010 1:02:54 PM
 */
package com.trs.dev4.jdk16.actionlog;

/**
 * 职责: <br>
 *
 */
public interface IActionlogExtendable {
	/**
	 * 日志的扩展内容，长度不超过255
	 * 
	 * @return
	 * @since fangxiang @ Nov 24, 2010
	 */
	public String getExtend1();

	/**
	 * 日志的扩展内容，长度不超过255
	 * 
	 * @return
	 * @since fangxiang @ Nov 24, 2010
	 */
	public String getExtend2();

	/**
	 * 日志的扩展内容，长度不超过255
	 * 
	 * @return
	 * @since fangxiang @ Nov 24, 2010
	 */
	public String getExtend3();
}
