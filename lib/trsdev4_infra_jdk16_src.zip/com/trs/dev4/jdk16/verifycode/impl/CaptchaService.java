/*
 * Created: dujie@2011-10-12 下午03:38:14
 */
package com.trs.dev4.jdk16.verifycode.impl;

import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.example.Captcha;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.verifycode.ICaptchaManager;
import com.trs.dev4.jdk16.verifycode.ICaptchaService;

/**
 * 
 * 职责: <br>
 * 问答式验证码服务类实现
 * 
 */
@Service
public class CaptchaService implements ICaptchaService {

	@Resource(name = "captchaManager")
	private ICaptchaManager captchaManager;
	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaService#deleteCaptchas(int[])
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public void deleteCaptchas(int[] ids) {
		for (int id : ids) {
			Captcha captcha = this.captchaManager.get(id);
			if (captcha != null) {
				this.captchaManager.delete(captcha);
			}
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaService#getCaptcha(int)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public Captcha getCaptcha(int captchaId) {
		return this.captchaManager.get(captchaId);
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaService#listCaptchas(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public List<Captcha> listCaptchas(SearchFilter searchFilter) {
		return this.captchaManager.listCaptchas(searchFilter);
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaService#pagedCaptchas(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public PagedList<Captcha> pagedCaptchas(SearchFilter searchFilter) {
		return this.captchaManager.pagedCaptchas(searchFilter);
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaService#saveOrUpdate(com.trs.dev4.jdk16.model.example.Captcha)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public void saveOrUpdate(Captcha captcha) {
		this.captchaManager.saveOrUpdate(captcha);
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaService#validate(java.lang.String, int)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public String validate(String context, int length) {
		String retContext = "";
		if (!StringHelper.isEmpty(context)) {
			if (context.length() > length) {
				retContext = context.substring(0, length);
			} else {
				retContext = context;
			}
		}
		return retContext;
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.ICaptchaService#getRandomCaptcha()
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public Captcha getRandomCaptcha() {
		SearchFilter searchFilter = SearchFilter.getNoPagedFilter();
		List<Captcha> Captchas = this.listCaptchas(searchFilter);
		if (Captchas.size() == 0) {
			return new Captcha();
		}
		return randomQuestion(Captchas);
	}

	/**
	 * 随机获取验证问答List中的验证问答对象
	 * 
	 * @param Captchas
	 *            验证问答List
	 * @return 验证问答对象
	 * @since dujie @ 2011-10-12
	 */
	private Captcha randomQuestion(List<Captcha> Captchas) {
		int max = Captchas.size();
		int min = 0;

		Random random = new Random();
		int index = random.nextInt(max) % (max - min + 1) + min;

		return Captchas.get(index);
		
	}

	/**
	 * @return the {@link #captchaManager}
	 */
	public ICaptchaManager getCaptchaManager() {
		return captchaManager;
	}

	/**
	 * @param captchaManager
	 *            the {@link #captchaManager} to set
	 */
	public void setCaptchaManager(ICaptchaManager captchaManager) {
		this.captchaManager = captchaManager;
	}
	
}
