/*
 * Created: dujie@2011-10-12 下午04:07:01
 */
package com.trs.dev4.jdk16.verifycode.impl;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.trs.dev4.jdk16.model.example.Captcha;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.verifycode.IVerifyCodeGenerator;
import com.trs.dev4.jdk16.verifycode.IVerifyCodeProvider;
import com.trs.dev4.jdk16.verifycode.IVerifyCodeService;

/**
 * 职责: <br>
 * 验证码服务接口的实现（生成·启用·验证·阅读）
 */
@Service
public class VerifyCodeService implements IVerifyCodeService {
	/**
	 * 日志对象
	 */
	private static final Logger logger = Logger.getLogger(VerifyCodeService.class);
	/**
	 * 
	 * @since dujie @ 2011-10-12
	 */
	@Resource(name = "verifyCodeGenerator")
	private IVerifyCodeGenerator verifyCodeGenerator;
	/**
	 * 验证码提供者Map
	 * 
	 * @since dujie @ 2011-10-12
	 */

	@Resource(name = "verifyCodeProviders")
	private Map<String, IVerifyCodeProvider> verifyCodeProviders = new HashMap<String, IVerifyCodeProvider>();

	/**
	 * @see com.trs.dev4.jdk16.verifycode.IVerifyCodeService#buildCaptcha(int,
	 *      String)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public Captcha buildCaptcha(int length, String verifyCodeType) {
		
		if (logger.isDebugEnabled()) {
			logger.debug("verifyCodeProvider.size:" + verifyCodeProviders.size());
		}
		Captcha captcha = new Captcha();
		int type = StringHelper.parseInt(verifyCodeType);
		
		if (type < 8 && type > 0) {
			captcha = this.verifyCodeProviders.get("number").getRandomVerifyCode(length, verifyCodeType);
		} else if (type == 8) {
			captcha = this.verifyCodeProviders.get("chinese").getRandomVerifyCode(length, verifyCodeType);
		} else if (type == 9) {
			captcha = this.verifyCodeProviders.get("questionAnswer").getRandomVerifyCode(length, verifyCodeType);
		}
		
		return captcha;
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.IVerifyCodeService#isOpened(java.lang.String)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public boolean isOpened(String verifyType) {
		if (verifyType.equalsIgnoreCase("none")) {
			return false;
		}
		return true;
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.IVerifyCodeService#verifyCaptcha(String, java.lang.String)
	 * @since dujie @ 2011-10-12
	 */
	@Override
	public boolean verifyCaptcha(String realCode, String verifyCode) {
		if ((realCode == null) || (!realCode.equals(verifyCode))) {
			return false;
		}
		return true;
	}

	/**
	 * @see com.trs.dev4.jdk16.verifycode.IVerifyCodeService#drawVerifyCodeToPicture(java.io.Serializable,
	 *      int, int, int, int, int)
	 * @since dujie @ 2011-10-13
	 */
	@Override
	public BufferedImage drawVerifyCodeToPicture(Serializable verifyCode, int noiseLevel, int torsionResistance, int fontSize, int pictureWidth,
			int pictureHeight) throws IOException {
	 return this.verifyCodeGenerator.drawVerifyCodeToPicture(verifyCode, noiseLevel, torsionResistance, fontSize, pictureWidth, pictureHeight);
	}

	/**
	 * @return the {@link #verifyCodeGenerator}
	 */
	public IVerifyCodeGenerator getVerifyCodeGenerator() {
		return verifyCodeGenerator;
	}

	/**
	 * @param verifyCodeGenerator
	 *            the {@link #verifyCodeGenerator} to set
	 */
	public void setVerifyCodeGenerator(IVerifyCodeGenerator verifyCodeGenerator) {
		this.verifyCodeGenerator = verifyCodeGenerator;
	}

	/**
	 * @return the {@link #verifyCodeProviders}
	 */
	public Map<String, IVerifyCodeProvider> getVerifyCodeProviders() {
		return verifyCodeProviders;
	}

	/**
	 * @param verifyCodeProviders
	 *            the {@link #verifyCodeProviders} to set
	 */
	public void setVerifyCodeProviders(Map<String, IVerifyCodeProvider> verifyCodeProviders) {
		this.verifyCodeProviders = verifyCodeProviders;
	}


}
