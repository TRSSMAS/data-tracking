/*
 * Created: dujie@2011-10-12 下午03:45:45
 */
package com.trs.dev4.jdk16.verifycode;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.Serializable;

import com.trs.dev4.jdk16.model.example.Captcha;

/**
 * 职责: <br>
 * 验证码服务接口（生成·启用·验证·阅读）
 */
public interface IVerifyCodeService {
	/**
	 * 生成验证码
	 * @param length
	 *            验证码长度
	 * @param verifyCodeType
	 *            验证码类型（问答、中文、数字&字符验证码类型）
	 * 
	 * @return 验证码
	 * @since dujie @ 2011-10-12
	 */
	public Captcha buildCaptcha(int length, String verifyCodeType);

	/**
	 * 咨询启用是否启用验证码
	 * 
	 * @param verifyType
	 *            验证类型
	 * 
	 * @return 是否开启
	 * @since dujie @ 2011-10-14
	 */
	public boolean isOpened(String verifyType);

	/**
	 * 判断是否通过验证
	 * 
	 * @param realCode
	 *            session中的验证码
	 * @param verifyCode
	 *            输入的验证码
	 * @return 是否通过验证
	 * @since dujie @ 2011-10-12
	 */
	public boolean verifyCaptcha(String realCode, String verifyCode);

	/**
	 * 获取带有随机验证码的图片
	 * 
	 * @param verifyCode
	 *            验证码字符串
	 * @param noiseLevel
	 *            噪音级别.噪音级别是指验证码生成图片的背景复杂度,噪音级别数越大，验证码越难识别,取值范围：400～1000.
	 * @param torsionResistance
	 *            扭曲度.扭曲度是指验证码在生成图片上的偏移程度,扭曲度指数越大，验证码越难识别,取值范围：10～30.
	 * @param fontSize
	 *            验证码字体大小
	 * @param pictureWidth
	 *            图片宽度
	 * @param pictrueHeight
	 *            图片高度
	 * @return 图片
	 * @throws IOException
	 *             IO异常
	 * @since v3.5
	 * @creator yanghongwu @ 2010-4-9
	 */
	public abstract BufferedImage drawVerifyCodeToPicture(Serializable verifyCode, int noiseLevel, int torsionResistance, int fontSize, int pictureWidth,
			int pictrueHeight) throws IOException;

	
	
}
