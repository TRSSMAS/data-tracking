/*
 * Created: liuyou@2010-5-19 下午01:17:29
 */
package com.trs.dev4.jdk16.remoting;

/**
 * Spring框架下HTTP方式远程调用的接口
 * 
 */
public interface IExecutor {
	/**
	 * 服务的调用
	 * 
	 * @param beanName
	 *            服务的beanName
	 * @param methodName
	 *            服务的方法签名
	 * @param args
	 *            服务的参数列表
	 * @return
	 * @since liuyou @ 2010-5-23
	 */
	Object service(String beanName, String methodName, Object... args);
}
