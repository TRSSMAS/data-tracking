/**
 * Created: liushen@Dec 5, 2009 11:12:20 AM
 */
package com.trs.dev4.jdk16.exec;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.trs.dev4.jdk16.utils.CloseUtil;

/**
 * 包内部类，处理进程的输出流. <br>
 * 
 */
class StreamRunner extends Thread {

	/**
	 * 输入流, 对应进程的输出流.
	 */
	private InputStream is;

	/**
	 * 保存InputStream读出的结果.
	 */
	private List<String> output = new ArrayList<String>();

	/**
	 * 线程是否执行结束.
	 */
	private boolean finished = false;

	/**
	 * 输入流读取是否成功结束.
	 */
	private boolean successReadComplete = false;

	/**
	 * 设置用于读取进程输出流的编码. 如果为null, 则使用JVM默认编码.
	 */
	private String encoding;

	/**
	 * 实际用的编码, 从<code>InputStreamReader.getEncoding()</code>返回.
	 */
	private String actualEncoding;

	StreamRunner(InputStream is) {
		this.is = is;
	}

	@Override
	public void run() {
		InputStreamReader isr = new InputStreamReader(is);
		actualEncoding = isr.getEncoding();
		BufferedReader br = new BufferedReader(isr);
		try {
			for (String line = br.readLine(); line != null; line = br
					.readLine()) {
				output.add(line);
			}
			successReadComplete = true;
		} catch (IOException e) {
		} finally {
			CloseUtil.closeReader(br);
			finished = true;
		}
	}

	/**
	 * Get the {@link #output}.
	 * 
	 * @return the {@link #output}.
	 */
	public List<String> getOutput() {
		return output;
	}

	/**
	 * Get the {@link #finished}.
	 * 
	 * @return the {@link #finished}.
	 */
	public boolean isFinished() {
		return finished;
	}

	/**
	 * Get the {@link #successReadComplete}.
	 * 
	 * @return the {@link #successReadComplete}.
	 */
	public boolean isSuccessReadComplete() {
		return successReadComplete;
	}

	/**
	 * Get the {@link #encoding}.
	 * 
	 * @return the {@link #encoding}.
	 */
	public String getEncoding() {
		return encoding;
	}

	/**
	 * Get the {@link #actualEncoding}.
	 * 
	 * @return the {@link #actualEncoding}.
	 */
	public String getActualEncoding() {
		return actualEncoding;
	}
}
