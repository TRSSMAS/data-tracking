/*
 * Created: fengjianhua@2009-3-27 上午09:28:28
 */
package com.trs.dev4.jdk16.exec;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.trs.dev4.jdk16.utils.AssertUtil;

/**
 * 保存外部进程的执行结果.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class ExecuteResult {

	/**
	 * 
	 */
	private ProcessHelper ph;

	/**
	 * @param ph
	 */
	public ExecuteResult(ProcessHelper ph) {
		AssertUtil.notNull(ph, "ProcessHelper is null!");
		this.ph = ph;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @creator liushen @ Jan 26, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ExecuteResult [");
		builder.append(ph);
		builder.append("]");
		return builder.toString();
	}

	/**
	 * Get the {@link #command}.
	 * 
	 * @return the {@link #command}.
	 */
	public String getCommand() {
		return ph.getCmd();
	}

	/**
	 * Get the {@link #exitValue}.
	 * 
	 * @return the {@link #exitValue}.
	 */
	public int getExitValue() {
		return ph.getExitValue();
	}

	/**
	 * Get the {@link #workDir}.
	 * 
	 * @return the {@link #workDir}.
	 */
	public File getWorkDir() {
		return ph.getActualWorkDir();
	}

	/**
	 * Get the {@link #env}.
	 * 
	 * @return the {@link #env}.
	 */
	public Map<String, String> getEnv() {
		return ph.getActualEnv();
	}

	/**
	 * 执行该进程所花的时间，包括调用开销和执行开销。
	 * 
	 * @return 所花时间的毫秒值
	 */
	public long getEstimatedTimeMillis() {
		return ph.getEstimatedTimeMillis();
	}

	/**
	 * @return the {@link #startTime}
	 */
	public long getStartTime() {
		return ph.getStartTime();
	}

	/**
	 * @return the {@link #endTime}
	 */
	public long getEndTime() {
		return ph.getEndTime();
	}

	/**
	 * Get the {@link #output}.
	 * 
	 * @return the {@link #output}.
	 */
	public List<String> getOutput() {
		return ph.getStdOut();
	}

	/**
	 * Get the {@link #errorOutput}.
	 * 
	 * @return the {@link #errorOutput}.
	 */
	public List<String> getErrorOutput() {
		return ph.getStdErr();
	}

	/**
	 * @see ProcessHelper#hasStdOutput()
	 * @since liushen @ Apr 25, 2010
	 */
	public boolean hasStdoutOutput() {
		return ph.hasStdOutput();
	}

	/**
	 * @see ProcessHelper#hasStdOutput()
	 * @since liushen @ Apr 25, 2010
	 */
	public boolean hasStderrOutput() {
		return ph.hasErrorOutput();
	}

	/**
	 * 头几行标准输出。
	 * 
	 * @param count
	 *            行数
	 * @return
	 * @creator liushen @ Jan 26, 2010
	 */
	public String firstLinesOfStdout(int count) {
		return ph.sublinesOfStdout(count);
	}

	/**
	 * 头几行标准错误的输出。
	 * 
	 * @param count
	 *            行数
	 * @return
	 * @creator liushen @ Jan 26, 2010
	 */
	public String firstLinesOfStderr(int count) {
		return ph.sublinesOfStderr(count);
	}

	/**
	 * 末几行标准输出。
	 * 
	 * @param count
	 *            行数
	 * @return
	 * @creator liushen @ Jan 26, 2010
	 */
	public String lastLinesOfStdout(int count) {
		return ph.lastSublinesOfStdout(count);
	}

	/**
	 * 末几行标准错误的输出。
	 * 
	 * @param count
	 *            行数
	 * @return
	 * @creator liushen @ Jan 26, 2010
	 */
	public String lastLinesOfStderr(int count) {
		return ph.lastSublinesOdStderr(count);
	}

}
