/*
 * Created: liushen@Dec 5, 2009 10:16:10 AM
 */
package com.trs.dev4.jdk16.exec;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.exception.ProcessException;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.EnvConst;
import com.trs.dev4.jdk16.utils.FileUtil;
import com.trs.dev4.jdk16.utils.RegexUtil;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.utils.Substring;

/**
 * 执行操作系统进程的助手.
 * 
 */
public class ProcessHelper {

	private static final Logger LOG = Logger.getLogger(ProcessHelper.class);

	/**
	 * 
	 */
	private static final String PATTERN_SPACES = "\\s+";

	private String cmd;

	private int exitValue = Integer.MIN_VALUE;

	private Process process;

	/**
	 * 开始执行进程的时刻.
	 */
	private long startTime;

	/**
	 * 全部结束的时刻.
	 */
	private long endTime;

	/**
	 * 进程执行结束的时刻.
	 */
	private long endCallTime;

	/**
	 * 设定的工作目录.
	 */
	private File workDir;

	/**
	 * 实际的工作目录.
	 */
	private File actualWorkDir;

	/**
	 * 自定的环境变量.
	 */
	private Map<String, String> env;

	/**
	 * 实际的所有环境变量.
	 */
	private Map<String, String> actualEnv;

	private List<String> listStdout = new ArrayList<String>();

	private List<String> listStderr = new ArrayList<String>();

	/**
	 * 是否不获取程序的输出，包括stdout和stderr的输出.
	 */
	private boolean omitOutput;

	private boolean debug = LOG.isDebugEnabled();

	/**
	 * Windows命令行前缀.
	 */
	public static final String WINDOWS_CMD_PRIFEX = "cmd /c ";

	/**
	 * @param cmd
	 */
	public ProcessHelper(String cmd) {
		this(cmd, null);
	}

	/**
	 * 
	 * @param cmd
	 * @param strWorkDir
	 */
	public ProcessHelper(String cmd, String strWorkDir) {
		if (cmd == null) {
			throw new IllegalArgumentException("cmd is null!");
		}
		cmd = cmd.trim();
		if (cmd.length() == 0) {
			throw new IllegalArgumentException("cmd is empty!");
		}
		this.cmd = cmd;

		prepare();

		this.workDir = StringHelper.isEmpty(strWorkDir) ? new File(FileUtil
				.getCurrentWorkingDir()) : new File(strWorkDir);
	}

	/**
	 * 执行该进程所花的时间，包括调用开销和执行开销。
	 * 
	 * @return 所花时间的毫秒值
	 */
	public long getEstimatedTimeMillis() {
		return endTime - startTime;
	}

	/**
	 * 
	 * @return
	 */
	public List<String> getStdOut() {
		return listStdout;
	}

	/**
	 * 
	 * @return
	 */
	public List<String> getStdErr() {
		return listStderr;
	}

	/**
	 * 强制结束进程, 仅在用{@link #startProcess()}方式调用进程时才有效!
	 */
	public void cancelProcess() {
		if (process == null) {
			return;
		}

		process.destroy();
		// TODO 补充单元测试
	}

	/**
	 * 
	 * @creator liushen @ Jan 28, 2010
	 */
	private void prepare() {
		if (EnvConst.isWindows()) {
			cmd = ProcessHelper.WINDOWS_CMD_PRIFEX + cmd;
		}

	}

	/**
	 * 启动进程, 并一直等待其执行结束; 仅包可见.
	 * 
	 * @return 进程的返回值
	 */
	int startAndWait() {
		startProcess();

		StreamRunner stdoutRunner = null;
		StreamRunner stderrRunner = null;

		if (false == omitOutput) {
			stdoutRunner = new StreamRunner(process.getInputStream());
			stderrRunner = new StreamRunner(process.getErrorStream());
			stdoutRunner.start();
			stderrRunner.start();
		}

		try {
			exitValue = process.waitFor();
		} catch (InterruptedException e) {
			throw new ProcessException("the process ["
					+ "] interrupted, maybe by another thread!", e);
		} finally {
			endCallTime = System.currentTimeMillis();
		}

		if (false == omitOutput) {
			while (stdoutRunner.isFinished() == false
					|| stderrRunner.isFinished() == false) {
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
				}
			}
			listStdout = stdoutRunner.getOutput();
			listStderr = stderrRunner.getOutput();
		}

		recordEndTime();

		return exitValue;
	}

	/**
	 * 仅包可见.
	 */
	ProcessHelper startProcess() {
		List<String> lstCmd = parseCmd(cmd);
		if (isDebug()) {
			LOG.debug("cmd after parsed: " + CollectionUtil.toString(lstCmd));
		}
		ProcessBuilder pb = new ProcessBuilder(lstCmd);

		pb.directory(workDir);
		actualWorkDir = pb.directory();

		// 设置自定的环境变量
		if (env != null) {
			Map<String, String> pbEnv = pb.environment();
			for (Map.Entry<String, String> entry : env.entrySet()) {
				pbEnv.put(entry.getKey(), entry.getValue());
			}
		}

		actualEnv = pb.environment();
		recordStartTime();
		try {
			process = pb.start();
			return this;
		} catch (IOException e) {
			throw new ProcessException(e);
		}
	}

	/**
	 * 将字符串解析为 <code>java.lang.ProcessBuilder</code> 接受的List，主要是对于双引号、空格类字符的处理。
	 * 
	 * @param sCmd
	 *            完整命令行的字符串
	 * @creator liushen @ Jan 28, 2010
	 */
	static List<String> parseCmd(String sCmd) {
		List<String> lstCmd = new ArrayList<String>();

		List<Substring> lstQuotes = RegexUtil.getSubstringsByQuote(sCmd);
		// 若不含双引号，则直接以空白字符分割
		if (lstQuotes.size() == 0) {
			String[] arr = sCmd.split(PATTERN_SPACES);
			return Arrays.asList(arr);
		}

		// 若含双引号，则将引号中的内容作为完整的一部分，再按空白字符分割
		int prevEnd = 0;
		for (Substring substring : lstQuotes) {
			String before = substring.getBefore(prevEnd);
			simpleSplitAndAddToList(before, lstCmd);
			// liushen@Feb 17, 2012: 不应去除掉参数的双引号，以支持Windows的find等命令
			if (EnvConst.isWindows()) {
				lstCmd.add(substring.getValue());
			} else {
				// liushen@Mar 7, 2012: linux下需要去掉双引号，否则出不来正确的结果(TRSMAS-557)
				lstCmd.add(StringHelper.trimQuote(substring.getValue()));
			}
			prevEnd = substring.getEnd();
		}
		String substrAfterLastQuote = sCmd.substring(prevEnd);
		simpleSplitAndAddToList(substrAfterLastQuote, lstCmd);

		return lstCmd;
	}

	/**
	 * @param lstCmd
	 * @creator liushen @ Jan 29, 2010
	 */
	private static void simpleSplitAndAddToList(String str, List<String> lstCmd) {
		if (str == null || str.length() == 0) {
			return;
		}
		str = str.trim();
		String[] arr = str.split(PATTERN_SPACES);
		lstCmd.addAll(Arrays.asList(arr));
	}

	private void recordStartTime() {
		startTime = System.currentTimeMillis();
	}

	private void recordEndTime() {
		endTime = System.currentTimeMillis();
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Apr 25, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ProcessHelper [");
		builder.append("cmd=").append(cmd);
		builder.append(", exitValue=").append(exitValue);
		builder.append(", in ").append(workDir);
		if (hasErrorOutput()) {
			builder.append("; stderr has ").append(listStderr.size()).append(
					" lines, the last 2 line: ");
			builder.append(CollectionUtil.lastSublines(listStderr, 2));
		}

		if (hasStdOutput()) {
			builder.append("; stdout ").append(listStdout.size()).append(
					" lines");
		}
		builder.append("]");
		return builder.toString();
	}

	/**
	 * 是否实际向标准错误设备输出有内容.
	 * 
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public boolean hasErrorOutput() {
		return (listStderr != null) && (listStderr.size() > 0);
	}

	/**
	 * 是否实际向标准输出设备输出有内容.
	 * 
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public boolean hasStdOutput() {
		return (listStdout != null) && (listStdout.size() > 0);
	}

	/**
	 * @return the {@link #cmd}
	 */
	public String getCmd() {
		return cmd;
	}

	/**
	 * @return the {@link #exitValue}
	 */
	public int getExitValue() {
		return exitValue;
	}

	/**
	 * @return the {@link #startTime}
	 */
	public long getStartTime() {
		return startTime;
	}

	/**
	 * @return the {@link #endTime}
	 */
	public long getEndTime() {
		return endTime;
	}

	void dumpStaticis() {
		if (startTime == 0) {
			System.out.println("The process (" + cmd + ") not start yet!");
			return;
		}
		System.out.println("The process: cmd: " + cmd);
		if (debug) {
			System.out.println("workDir: " + workDir + ", env:");
			if (env != null) {
				for (Iterator<String> keys = env.keySet().iterator(); keys.hasNext();) {
					String key = keys.next();
					System.out.println(key + " = " + env.get(key));
				}
			}
		}
	
		System.out.println("ExitValue: " + getExitValue());
		System.out.println("EstimatedTime: " + getEstimatedTimeMillis() + "ms. (start: " + new Timestamp(startTime) + ", endCall: "
				+ new Timestamp(endCallTime) + ", end: " + new Timestamp(endTime) + ")");
		System.out.println("StdOut: " + CollectionUtil.toString(getStdOut()));
		System.out.println("StdErr: " + CollectionUtil.toString(getStdErr()));
		System.out.println();
	}

	/**
	 * Get the {@link #env}.
	 * 
	 * @return the {@link #env}.
	 */
	public Map<String, String> getEnv() {
		return env;
	}

	/**
	 * Set the {@link #env}.
	 * 
	 * @param env
	 *            the env to set
	 */
	void setEnv(Map<String, String> env) {
		this.env = env;
	}

	/**
	 * Get the {@link #workDir}.
	 * 
	 * @return the {@link #workDir}.
	 */
	public File getWorkDir() {
		return workDir;
	}

	/**
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String sublinesOfStdout(int count) {
		return CollectionUtil.sublines(listStdout, count);
	}

	/**
	 * 
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String sublinesOfStderr(int count) {
		return CollectionUtil.sublines(listStderr, count);
	}

	/**
	 * 
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String lastSublinesOfStdout(int count) {
		return CollectionUtil.lastSublines(listStdout, count);
	}

	/**
	 * 
	 * @param count
	 * @return
	 * @since liushen @ Apr 25, 2010
	 */
	public String lastSublinesOdStderr(int count) {
		return CollectionUtil.lastSublines(listStderr, count);
	}

	/**
	 * @return the {@link #omitOutput}
	 */
	public boolean isOmitOutput() {
		return omitOutput;
	}

	/**
	 * @param omitOutput
	 *            the {@link #omitOutput} to set
	 */
	public void setOmitOutput(boolean omitOutput) {
		this.omitOutput = omitOutput;
	}

	/**
	 * @return the {@link #endCallTime}
	 */
	public long getEndCallTime() {
		return endCallTime;
	}

	/**
	 * @return the {@link #actualWorkDir}
	 */
	public File getActualWorkDir() {
		return actualWorkDir == null ? workDir : actualWorkDir;
	}

	/**
	 * @return the {@link #actualEnv}
	 */
	public Map<String, String> getActualEnv() {
		return actualEnv == null ? env : actualEnv;
	}

	/**
	 * @return the {@link #debug}
	 */
	public boolean isDebug() {
		return debug;
	}

	/**
	 * @param debug
	 *            the {@link #debug} to set
	 */
	void setDebug(boolean debug) {
		this.debug = debug;
	}

}
