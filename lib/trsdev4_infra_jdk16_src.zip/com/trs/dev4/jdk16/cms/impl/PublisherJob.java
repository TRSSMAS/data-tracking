/*
 * Created: fangxiang@Jan 21, 2011 3:34:17 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.Map;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.ICMSPublisher;
import com.trs.dev4.jdk16.cms.IContentProvider;

/**
 * 发布任务
 * 
 */
class PublisherJob {
	private final static Logger logger = Logger.getLogger(PublisherJob.class);
	/**
	 * 
	 */
	private String templateName;
	/**
	 * 
	 */
	private int duration;
	/**
	 * 
	 */
	private String outputDirectory;
	/**
	 * 
	 */
	private IContentProvider contentProvider;
	/**
	 * 
	 */
	private Map<String, Object> parameters;
	/**
	 * 发布解释器
	 */
	private ICMSPublisher publisher;

	/**
	 * @return the duration
	 */
	public int getDuration() {
		return duration;
	}

	/**
	 * @param duration
	 *            the duration to set
	 */
	public void setDuration(int duration) {
		this.duration = duration;
	}

	/**
	 * @return the parameters
	 */
	public Map<String, Object> getParameters() {
		return parameters;
	}

	/**
	 * @param parameters
	 *            the parameters to set
	 */
	public void setParameters(Map<String, Object> parameters) {
		this.parameters = parameters;
	}

	/**
	 * @return the {@link #templateName}
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName
	 *            the {@link #templateName} to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return the {@link #publisher}
	 */
	public ICMSPublisher getPublisher() {
		return publisher;
	}

	/**
	 * @param publisher
	 *            the {@link #publisher} to set
	 */
	public void setPublisher(ICMSPublisher publisher) {
		this.publisher = publisher;
	}

	/**
	 * 
	 * 
	 * @since fangxiang @ Jan 21, 2011
	 */
	public void publish() {
		if (contentProvider != null) {
			Map<String, Object> inputObjects = contentProvider
					.getContent(parameters);
			String outputFilePath = outputDirectory
					+ contentProvider.getOutputFile(parameters);
			logger.debug("Publisher(" + publisher
					+ ") executed with templateName(" + templateName
					+ ") and contentProvider(" + contentProvider
					+ "),parameters is (" + parameters + "),outputFile is ("
					+ outputFilePath + ").");
			publisher.publish(templateName, inputObjects, outputFilePath);
		} else {

		}
	}

	/**
	 * @return the {@link #contentProvider}
	 */
	public IContentProvider getContentProvider() {
		return contentProvider;
	}

	/**
	 * @param contentProvider
	 *            the {@link #contentProvider} to set
	 */
	public void setContentProvider(IContentProvider contentProvider) {
		this.contentProvider = contentProvider;
	}

	/**
	 * @param outputDirectory
	 *            the {@link #outputDirectory} to set
	 */
	public void setOutputDirectory(String outputDirectory) {
		this.outputDirectory = outputDirectory;
	}
}
