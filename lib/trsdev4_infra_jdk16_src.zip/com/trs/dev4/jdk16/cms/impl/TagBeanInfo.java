/*
 * TagBeanInfo.java created on 2005-9-6 14:38:59 by Martin (Fu Chengrui)
 *  2006.05.25  caohui
 *      RECURL支持返回绝对还是相对
 */

package com.trs.dev4.jdk16.cms.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * 用于描述 ITagParser 置标的特性
 * 
 * @see com.trs.components.common.publish.domain.tagparser.ITagParser#getBeanInfo()
 * 
 * @author Martin (付成睿)
 */
public class TagBeanInfo {

    public static class BodyType {

		/**
		 * 在开始置标和结束置标之间是普通的HTML代码
		 */
        public final static BodyType HTML = new BodyType("HTML");

		/**
		 * 在开始置标和结束置标之间不能有任何内容
		 */
        public final static BodyType EMPTY = new BodyType("EMPTY");

		/**
		 * 在开始置标和结束置标之间的任何内容都回忽略
		 */
        public final static BodyType IGNORE = new BodyType("IGNORE");

		/**
		 * 在开始置标和结束置标之间是置标的参数，不能为空
		 */
        public final static BodyType ARGUMENT = new BodyType("ARGUMENT");

		/**
		 * 在开始置标和结束置标之间，可以是模板内容，既可以包括WCM置标
		 */
        public final static BodyType TAMPLATE = new BodyType("TAMPLATE");

		/**
		 * 类型的名称
		 */
        private String m_sName;

		/**
		 * 私有的构造函数，不得外部实例化
		 * 
		 * @param name
		 *            类型的名称
		 */
        private BodyType(String name) {
            m_sName = name;
        }

		/**
		 * 返回属性类型的名称
		 * 
		 * @return 属性类型的名称
		 */
        public String getName() {
            return m_sName;
        }

        /*
         * (non-Javadoc)
         * 
         * @see java.lang.Object#toString()
         */
        @Override
		public String toString() {
            return m_sName;
        }

    }

	/**
	 * 置标的名称
	 */
    private String m_sName;

	/**
	 * 置标的详细名称
	 */
    private String m_sDesc;

	/**
	 * 置标的内容类型
	 */
    private BodyType m_oType;

	/**
	 * 标识 ITagParser 实现是否线程安全
	 */
    private boolean m_zThreadSafe;

	/**
	 * 所有的属性名到属性对象的映射表
	 */
	private HashMap<String, TagBeanAttrInfo> m_mapAttrInfo;

	/**
	 * 该置标所必须的属性数组
	 */
    private TagBeanAttrInfo[] m_oRequirAttr;

	/**
	 * 缺省构造方法
	 */
    public TagBeanInfo() {
        TagBeanAttrInfo tbai = new TagBeanAttrInfo();
        tbai.setName("URLISABS");
        tbai.setEnumValue(new String[] { "true", "false" });
        tbai.setDefaultValue("false");
        this.addAttrInfo(tbai);
    }

	/**
	 * 构造方法
	 * 
	 * @param name
	 *            置标的名称
	 * @param desc
	 *            置标的详细描述
	 * @param type
	 *            置标的类型
	 */
    public TagBeanInfo(String name, String desc, BodyType type) {
        m_sName = name;
        m_sDesc = desc;
        m_oType = type;
    }

	/**
	 * 返回置标的名称
	 * 
	 * @return 置标的名称
	 */
    public String getName() {
        return m_sName;
    }

	/**
	 * 设置置标的名称
	 * 
	 * @param name
	 *            置标的名称
	 */
    public void setName(String name) {
        m_sName = name;
    }

	/**
	 * 返回置标的详细描述
	 * 
	 * @return 置标的详细描述
	 */
    public String getDesc() {
        return m_sDesc;
    }

	/**
	 * 设置置标的详细描述
	 * 
	 * @param desc
	 *            置标的详细描述
	 */
    public void setDesc(String desc) {
        m_sDesc = desc;
    }

	/**
	 * 返回置标的类型
	 * 
	 * @return 置标的类型
	 */
    public BodyType getType() {
        return m_oType;
    }

	/**
	 * 设置置标的类型
	 * 
	 * @param type
	 *            置标的类型
	 */
    public void setType(BodyType type) {
        m_oType = type;
    }

	/**
	 * 返回相关联的ITagParser 实现是否线程安全，对于线程安全安全的实现， 可以不必为每一次解析都创建新的实例。
	 * 
	 * @return 相关联的ITagParser 实现是否线程安全
	 */
    public boolean getThreadSafe() {
        return m_zThreadSafe;
    }

	/**
	 * 设置相关联的ITagParser 实现是否线程安全
	 * 
	 * @param zSafe
	 *            相关联的ITagParser 实现是否线程安全
	 */
    public void setThreadSafe(boolean zSafe) {
        m_zThreadSafe = zSafe;
    }

	/**
	 * 返回置标属性的个数
	 * 
	 * @return 置标属性的个数
	 */
    public int getAttrInfoCount() {
        if (m_mapAttrInfo != null) {
            return m_mapAttrInfo.size();
        }
        return 0;
    }

	/**
	 * 返回该置标必须的属性数组
	 * 
	 * @return 该置标必须的属性数组
	 */
    public TagBeanAttrInfo[] getRequiredAttr() {
        if (m_oRequirAttr == null) {
			Iterator<TagBeanAttrInfo> itr = getAttrInfos();
            if (itr != null) {
				ArrayList<TagBeanAttrInfo> list = new ArrayList<TagBeanAttrInfo>();
                while (itr.hasNext()) {
                    TagBeanAttrInfo tbai = itr.next();
                    if (tbai.getRequired()) {
                        list.add(tbai);
                    }
                }
                if (list.size() > 0) {
                    TagBeanAttrInfo[] a = new TagBeanAttrInfo[list.size()];
                    list.toArray(a);
                    m_oRequirAttr = a;
                }
            }
            if (m_oRequirAttr == null) {
                m_oRequirAttr = new TagBeanAttrInfo[0];
            }
        }
        return m_oRequirAttr;
    }

	/**
	 * 确保 m_mapAttrInfo 的构造
	 */
	private HashMap<String, TagBeanAttrInfo> getAttrInfoMap() {
        if (m_mapAttrInfo == null) {
			m_mapAttrInfo = new HashMap<String, TagBeanAttrInfo>();
        }
        return m_mapAttrInfo;
    }

	/**
	 * 返回置标属性信息对象的，如果该置标没有属性，可以返回<code>null</code>。
	 * 
	 * @return 置标属性信息对象的数组
	 */
	public Iterator<TagBeanAttrInfo> getAttrInfos() {
        if (m_mapAttrInfo != null) {
            return m_mapAttrInfo.values().iterator();
        }
        return null;
    }

	/**
	 * 返回指定名称的置标属性信息对象。
	 * 
	 * @param name
	 *            置标名称
	 * @return 置标属性信息对象，或者<code>null</code>，如果指定名称的属性不存在
	 */
    public TagBeanAttrInfo getAttrInfo(String name) {
        if (m_mapAttrInfo != null) {
            return m_mapAttrInfo.get(name);
        }
        return null;
    }

	/**
	 * 添加置标属性信息对象，如果相同名称的置标属性信息对象已经存在，则将被替换，并返回。
	 * 
	 * @param tbai
	 *            待添加的置标属性信息对象
	 * @return 原有的同名称的置标属性信息对象，或者<code>null</code>
	 */
    public TagBeanAttrInfo addAttrInfo(TagBeanAttrInfo tbai) {
        if (tbai == null) {
            return null;
        }
        if (tbai.getRequired()) {
            m_oRequirAttr = null;
        }
        return getAttrInfoMap().put(tbai.getName(), tbai);
    }
}