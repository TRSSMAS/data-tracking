/**
 * Created:         2005-4-4 9:34:34
 * Last Modified:   2006.04.13
 * Description:
 *      class PublishTagContext
 * Update Log:
 *	2006.04.13	FuChengrui
 *		增加了实现序号相关的方法：getSequenceNumber()，setSequenceNumber()
 *	2006.01.19	FuChengrui
 *		修改了构造方法，
 *		增加了方法getPrefixOfArgument()和setPrefixOfArgument()
 *	2005.12.27	FuChengrui
 *		增加了方法 setTagItem()和getTagItem()，用以设置相关联的置标，
 *		增加了两个构造方法，用以在构造新对象时传递相关联的置标，原有的两个构造方法声明为 deprecated
 *		增加了getAttribute()系列方法，用以方法相关联的置标的属性
 *	2006.02.28	FuChengrui
 *		增加了和ITagParser4List相关联的功能，目的是实现在解析概览置标时，
 *		延迟当前PublishTagContext对象的实体化，即延迟UpperHost的设置，
 *		以实现TRS_REPEAT置标
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.HashMap;
import java.util.Map;

import com.trs.dev4.jdk16.cms.CMSException;
import com.trs.dev4.jdk16.cms.PageContext;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 用于描述标签{@link TagItem}的解析上下文
 */
public class TagContext {
	// page generate context
	private PageContext m_pageContext;
	/**
	 * 
	 */
	private TagContext m_parent;
	/**
	 * 
	 */
	private Map<String, String> m_extraAttributes;
	/**
	 * 
	 */
	private PublishObject entity;
	/**
	 * 当前的TagItem
	 */
	private TagItem m_oCurrTagItem = null;

	/**
	 * 全部模板变量的实际值
	 */
	private HashMap<String, String> m_mVariableArgument = null;

	/**
	 * 模板变量名称的前缀
	 */
	private String m_sPrefixOfArgument = null;

	/**
	 * 
	 * @param _pageContext
	 */
	public TagContext(PageContext _pageContext) {
		m_oCurrTagItem = null;
		m_parent = null;
		m_pageContext = _pageContext;
		m_sPrefixOfArgument = null;
	}

	/**
	 * 
	 * @param _pageContext
	 */
	public TagContext(PageContext _pageContext, TagItem tagItem) {
		m_oCurrTagItem = tagItem;
		m_parent = null;
		m_pageContext = _pageContext;
		m_sPrefixOfArgument = null;
	}

	/**
	 * 
	 * @param _parent
	 * @param _tagItem
	 */
	public TagContext(TagContext _parent, TagItem _tagItem) {
		init(_parent, _tagItem);
	}

	/**
	 * 
	 * @param _parent
	 * @param _tagItem
	 * @since TRS @ Feb 16, 2011
	 */
	private void init(TagContext _parent, TagItem _tagItem) {
		m_parent = _parent;
		m_oCurrTagItem = _tagItem;
		m_pageContext = _parent.getPageContext();
		m_mVariableArgument = _parent.m_mVariableArgument;
		m_sPrefixOfArgument = _parent.m_sPrefixOfArgument;
	}

	/**
	 * Returns the parent tag parse context.
	 * 
	 * @return the parent tag parse context
	 */
	public TagContext getParent() {
		return m_parent;
	}

	/**
	 * Sets the parent tag parse context.
	 * 
	 * @param _parent
	 *            the parent tag parse context
	 */
	public void setParent(TagContext _parent) {
		m_parent = _parent;
	}

	/**
	 * Returns the page generate context
	 * 
	 * @return the page generate context
	 */
	public PageContext getPageContext() {
		return m_pageContext;
	}

	/**
	 * Returns the display styles.
	 * 
	 * @return the display styles.
	 */
	public Map<String, String> getExtraAttributes() {
		return m_extraAttributes;
	}

	/**
	 * Returns the specified extra attribute.
	 * 
	 * @param _sName
	 *            style name
	 * @return the specified attribute value.
	 */
	public String getExtraAttribute(String _sName) {
		if (m_extraAttributes == null)
			return null;

		// else
		return m_extraAttributes.get(_sName.toUpperCase());
	}

	/**
	 * Returns the boolean extra property.
	 * 
	 * @param _sName
	 *            the property name.
	 * @param _bDefault
	 *            default value if the property value is not set.
	 * @return the boolean extra property if the value is set; other, the
	 *         default value.
	 */
	public boolean getBooleanExtraAttribute(String _sName, boolean _bDefault) {
		String sValue = this.getExtraAttribute(_sName);
		if (sValue == null || (sValue = sValue.trim()).length() == 0)
			return _bDefault;
		// else
		return sValue.equalsIgnoreCase("true");
	}

	/**
	 * Sets the display styles.
	 * 
	 * @param _displayStyles
	 *            display styles.
	 */
	public void setExtraAttributes(Map<String, String> _displayStyles) {
		m_extraAttributes = _displayStyles;
	}

	/**
	 * @see PageContext#addWarning(String, int, String)
	 */
	public void addWarning(String _sObjName, int _nObjId, String _sDesc)
			throws CMSException {
		m_pageContext.addWarning(_sObjName, _nObjId, _sDesc);
	}

	/**
	 * 
	 * @param _sDesc
	 * @throws CMSException
	 * @since TRS @ Feb 16, 2011
	 */
	public void addWarning(String _sDesc) throws CMSException {
		m_pageContext.addWarning(_sDesc);
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Feb 16, 2011
	 */
	public TagItem getTagItem() {
		return m_oCurrTagItem;
	}

	/**
	 * 
	 * @param _tagItem
	 * @since TRS @ Feb 16, 2011
	 */
	public void setTagItem(TagItem _tagItem) {
		m_oCurrTagItem = _tagItem;
	}

	/**
	 * @return Returns all the attributes.
	 */
	public HashMap<String, String> getAttributes() {
		return m_oCurrTagItem.getAttributes() == null ? new HashMap()
				: m_oCurrTagItem.getAttributes();
	}

	/**
	 * @return the {@link #entity}
	 */
	public PublishObject getEntity() {
		return entity;
	}

	/**
	 * @param entity
	 *            the {@link #entity} to set
	 */
	public void setEntity(PublishObject entity) {
		this.entity = entity;
	}
	
	/**
	 * 根据attributeName 获取标签内传入值
	 * @param attributeName
	 * @return
	 */
	public String getAttribute(String attributeName){
		String attributeValue = this.m_oCurrTagItem.getAttribute(attributeName.toUpperCase());
		//如果attribute 是以$开始的，则认为是一个request请求的变量名，从request再取一次。
		if(StringHelper.isNotEmpty(attributeValue) && attributeValue.startsWith("$")){
			attributeValue = this.getPageContext().getRequestParameter(attributeValue.substring(1),"");
		}
		return attributeValue;
	}
	
	/**
	 * 根据attributeName 获取标签传入int 值
	 * @param attributeName
	 * @param defValue
	 * @return
	 */
	public int getAttribute(String attributeName,int defValue){
		String attribute = getAttribute(attributeName);
		if(StringHelper.isEmpty(attribute)){
			return defValue;
		}
		return StringHelper.parseInt(attribute);
	}

	/**
	 * 返回标签属性
	 * @param attributeName
	 * @param defValue
	 * @return
	 */
	public String getAttribute(String attributeName, String defValue) {
		String attribute = getAttribute(attributeName);
		if(StringHelper.isEmpty(attribute)){
			return defValue;
		}
		return attribute;
	}
}