/*
 * Created: TRS@Feb 12, 2011 9:48:51 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.ArrayList;
import java.util.List;

/**
 * 记录解析后的页面内容，以{@link TagItem}节点的方式记录
 * 
 */
public class PageContent {
	/**
	 *
	 */
	public List<TagItem> textNodes = new ArrayList<TagItem>();

	/**
	 * 
	 * @param textNode
	 * @since TRS @ Feb 12, 2011
	 */
	public void add(TagItem textNode) {
		textNodes.add(textNode);
	}

	/**
	 * Returns the parse result at the specified position.
	 * 
	 * @param _index
	 *            the result position
	 * @return the parse result at the specified position
	 */
	public String get(int _index) {
		if (_index >= textNodes.size()) {
			return null;
		}

		// else
		return (textNodes.get(_index)).toString();
	}

	/**
	 * 
	 * 
	 * @since TRS @ Feb 16, 2011
	 */
	public void clear() {
		textNodes.clear();
	}

	/**
	 * 遍历该PageContent中的所有的TagItem,将所有标签的内容拼在一起，即返回解析标签后的页面内容
	 * @return
	 * @since TRS @ Feb 12, 2011
	 */
	public String merge() {
		StringBuilder builder = new StringBuilder();
		for (TagItem textNode : textNodes) {
			builder.append(textNode.getContent());
		}
		return builder.toString();
	}
}
