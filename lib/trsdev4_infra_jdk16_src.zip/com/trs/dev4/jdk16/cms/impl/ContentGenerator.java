/*
 * Created: TRS@Feb 12, 2011 9:40:34 PM
 */
package com.trs.dev4.jdk16.cms.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.UnmodifiableMap;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.cms.ForeignRelationship;
import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.ITemplateManager;
import com.trs.dev4.jdk16.cms.PageContext;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.TemplateDocument;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 负责内容解析和生成，实现{@link IContentGenerator}
 * 
 */
public class ContentGenerator implements IContentGenerator {

	private static final Logger LOG = Logger.getLogger(ContentGenerator.class);

	/**
	 * 管理置标和ITagParser之间的关系
	 */
	private Map<String, ITagParser> parsers = new HashMap<String, ITagParser>();
	/**
	 * 管理对象和ITagAware之间的关系
	 */
	private Map<String, ITagAware> tagAwares = new HashMap<String, ITagAware>();

	private ITemplateManager templateManager;

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParserManager#getParser(java.lang.String)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public ITagParser getParser(String tagName) {
		return parsers.get(tagName);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#getAware(java.lang.String)
	 */
	@Override
	public ITagAware getAware(String obj) {
		return tagAwares.get(obj);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParserManager#registerParser(com.trs.dev4.jdk16.cms.ITagParser)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public void registerParser(ITagParser tagParser) {
		if (tagParser == null) {
			return;
		}

		String name = tagParser.getBeanInfo().getName();
		ITagParser prevRegistered = parsers.get(name);
		if (prevRegistered == null) {
			parsers.put(name, tagParser);
			return;
		}
		if (false == tagParser.getClass().equals(prevRegistered.getClass())) {
			LOG.warn("the [" + name + "] already associated a different parser: " + prevRegistered.toString() + "; it will replace with " + tagParser);
		}
		parsers.put(name, tagParser);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParserManager#unregisterParser(java.lang.String)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public void unregisterParser(String tagName) {
		parsers.remove(tagName);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#generate(java.lang.String,
	 *      com.trs.dev4.jdk16.cms.PageContext)
	 */
	@Override
	public String generate(String templateName, PageContext pageContext) {
		if (StringHelper.isEmpty(templateName)) {
			return "";
		}
		TemplateDocument templateDoc = templateManager
				.getTemplateDocument(templateName);
		if (templateDoc == null) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("templateDoc is null: [" + templateName + "]");
			}
			return "";
		}
		return generate(templateDoc, pageContext);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#generate(com.trs.dev4.jdk16.cms.ITemplate,
	 *      com.trs.dev4.jdk16.cms.PageContext)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public String generate(TemplateDocument templateDoc, PageContext pageContext) {
		PageContent pageContent = new PageContent();
		int tagCount = templateDoc.getItemCount();
		if (LOG.isDebugEnabled()) {
			LOG.debug("tagCount: " + tagCount);
		}
		for (int i = 0; i < tagCount; i++) {
			TagItem currentTag = templateDoc.getItemAt(i);
			if (currentTag == null) {
				LOG.warn(i + "of " + tagCount + " tagItem is null");
				continue;
			}
			TagContext tagContext = new TagContext(pageContext, currentTag);
			parseTag(currentTag, pageContent, pageContext, tagContext);
		}
		return pageContent.merge();
	}

	/**
	 * 解析指标
	 * 
	 * @param currentTag
	 * @param pageContent
	 * @param pageContext
	 * @param tagContext
	 */
	protected void parseTag(TagItem currentTag, PageContent pageContent,
			PageContext pageContext, TagContext tagContext) {
		String tagName = currentTag.getName();// 标签名
		if (StringHelper.isEmpty(tagName)) {
			pageContent.add(currentTag);
			return;
		}

		ITagParser tagParser = this.getParser(tagName); // 标签对应的Tag
		if (tagParser == null) {
			LOG.warn("No Suitable TagParser for [" + tagName + "]");
			return;
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("Found " + tagParser + " for parse [" + tagName + "]");
		}
		String parsedTagContent = tagParser.parse(currentTag, tagContext);
		pageContent.add(new TagItem(parsedTagContent));
	}

	/**
	 * 构造分页显示的位置,返回TRS_PAGE对应的TagItem
	 * 
	 * 遍历所有的子标签，如果发现子标签是TRS_PAGE，获取location属性的值，如果值为up则在遍历内容之前出现分页
	 * 如果值为down,在遍历内容之后出现分页显示
	 * 
	 * @param up_location
	 *            被遍历的内容之上是否显示分页
	 * @param down_location
	 *            被便利内容之下是否显示分页
	 * @param currentTag
	 *            当前置标
	 * @param objects
	 *            被遍历的内容
	 * @return 返回TRS_PAGE对应的TagItem
	 */
	// private TagItem buildPageLocation(boolean up_location,
	// boolean down_location, TagItem currentTag, PagedList objects) {
	//
	// TagItem pageTagItem = null;
	//
	// List<TagItem> children = currentTag.getChildren();
	// for (TagItem childTag : children) {
	// if (StringHelper.isEmpty(childTag.getName())) {
	// continue;
	// }
	// if (childTag.getName().equalsIgnoreCase("TRS_PAGE")) {
	//
	// childTag.setAttribute("NUM", objects.getTotalItemCount());
	// childTag.setAttribute("PAGENO", objects.getPageIndex());
	// childTag.setAttribute("PAGESIZE", objects.getPageSize());
	//
	// Map<String, String> attrMap = childTag.getAttributes();
	//
	// pageTagItem = childTag;
	//
	// // 找到location的值
	// String location = attrMap.get("LOCATION");
	// if (location == null) {
	// throw new IllegalArgumentException("请指明location属性");
	// }
	//
	// String[] strs = StringUtils.split(location, ",");
	// for (String str : strs) {
	// if (str.equalsIgnoreCase("up")) {
	// up_location = true;
	// }
	// if (str.equalsIgnoreCase("down")) {
	// down_location = true;
	// }
	// }
	// }
	// }
	// return pageTagItem;
	// }

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.trs.dev4.jdk16.cms.IContentGenerator#parseObjects(com.trs.dev4.jdk16
	 * .dao.PagedList, com.trs.dev4.jdk16.cms.impl.TagItem,
	 * com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	@SuppressWarnings("rawtypes")
	public String parseObjects(PagedList objects, TagItem currentTag,
			TagContext tagContext, ITagAware tagAware) {

		if (LOG.isDebugEnabled()) {
			LOG.debug("tagItem: " + tagContext + "\ntagContext: " + tagContext);
			LOG.debug("tagParser.pagedObjects: " + objects);
			LOG.debug("tagItem.getChildren: "
					+ CollectionUtil.toString(currentTag.getChildren()));
		}
		// /** 分页内容前是否显示分页 **/
		// boolean up_location = false;
		// /** 分页内容知否是否显示分页 **/
		// boolean down_location = false;

		PageContent childrenContent = new PageContent();

		// // 1. 根据TRS_PAGE判断分页内容的显示位置
		// TagItem pageTagItem = this.buildPageLocation(up_location,
		// down_location, currentTag, objects);
		//
		// // 2.在遍历内容之前显示的分页标识
		// if (up_location) {
		// buildPageMark(tagContext, childrenContent, pageTagItem);
		// }

		// 3. 显示遍历内容
		buildPageContent(objects, currentTag, tagContext, childrenContent,
				tagAware);

		// // 4. 在遍历内容之后显示的分页标识
		// if (down_location) {
		// buildPageMark(tagContext, childrenContent, pageTagItem);
		// }

		return childrenContent.merge();
	}

	/**
	 * 显示遍历内容
	 * 
	 * @param objects
	 * @param currentTag
	 * @param tagContext
	 * @param childrenContent
	 */
	@SuppressWarnings("rawtypes")
	private void buildPageContent(PagedList objects, TagItem currentTag,
			TagContext tagContext, PageContent childrenContent,
			ITagAware tagAware) {
		int objectSize = objects.getPageItems().size();
		// 遍历所有的Object项
		for (int objectIndex = 0; objectIndex < objectSize;objectIndex++) {
			// IPublishable entity = tagAware.converte(object);
			// 遍历所有的子标签
			for (TagItem childTag : currentTag.getChildren()) {

				// 子标签中的HTML标签不通过Parser
				if (StringHelper.isEmpty(childTag.getName())) {
					childrenContent.add(childTag);
					continue;
				}

				if (childTag.getName().equalsIgnoreCase("TRS_OBJECT")) {
					int length = StringHelper.parseInt(childTag
							.getAttribute("LENGTH"));
					length = length > 0 ? length : 1;
					for (int i = 0; i < length && objectIndex < objectSize; i++) {
						
						Object object = objects.getPageItems().get(objectIndex);
						PublishObject entity = tagContext.getPageContext()
								.wrap(object);
						// 构造子标签的TagContext及标签上下文对象
						TagContext entityTagContext = new TagContext(
								tagContext, childTag);

						entityTagContext.setEntity(entity);

						// 解析每一个子标签到childrenContent
						this.parseTag(childTag, childrenContent,
								entityTagContext.getPageContext(),
								entityTagContext);
						if (i != length - 1) {
							objectIndex++;
						}
					}

				} else {
					Object object = objects.getPageItems().get(objectIndex);
					PublishObject entity = tagContext.getPageContext().wrap(
							object);
					// 构造子标签的TagContext及标签上下文对象
					TagContext entityTagContext = new TagContext(tagContext,
							childTag);

					entityTagContext.setEntity(entity);

					// 解析每一个子标签到childrenContent
					this.parseTag(childTag, childrenContent,
							entityTagContext.getPageContext(), entityTagContext);
				}
				// if (childTag.getName().equalsIgnoreCase("TRS_PAGE")) {
				// continue;
				// }

				// 构造子标签的TagContext及标签上下文对象
				// TagContext entityTagContext = new TagContext(tagContext,
				// childTag);
				//
				// entityTagContext.setEntity(entity);
				//
				// // 解析每一个子标签到childrenContent
				// this.parseTag(childTag, childrenContent,
				// entityTagContext.getPageContext(), entityTagContext);
			}
		}
	}

	/**
	 * 构造分页
	 * 
	 * @param tagContext
	 * @param childrenContent
	 * @param pageTagItem
	 */
	// private void buildPageMark(TagContext tagContext,
	// PageContent childrenContent, TagItem pageTagItem) {
	// TagContext entityTagContext = new TagContext(tagContext, pageTagItem);
	// this.parseTag(pageTagItem, childrenContent,
	// entityTagContext.getPageContext(), entityTagContext);
	// }

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.trs.dev4.jdk16.cms.IContentGenerator#parsePage(com.trs.dev4.jdk16
	 * .dao.PagedList, com.trs.dev4.jdk16.cms.impl.TagItem,
	 * com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	// public String parsePage(PagedList objects, TagItem tagItem,
	// TagContext tagContext) {
	//
	// // PageContent childrenContent = new PageContent();
	// //
	// // //将Object的类型转换成可以解析的IPublishable类型
	// // IPublishConvertor convertor =
	// // publishConvertorFactory.getPublishConvertor("pageSet");
	// // IPublishable entity = convertor.convert(objects);
	// //
	// // // 遍历所有的子标签
	// // for (TagItem childTag : tagItem.getChildren()) {
	// //
	// // //子标签中的HTML标签不通过Parser
	// // if (StringHelper.isEmpty(childTag.getName())) {
	// // childrenContent.add(childTag);
	// // continue;
	// // }
	// //
	// // //构造子标签的TagContext及标签上下文对象
	// // TagContext entityTagContext = new TagContext(tagContext,
	// // childTag);
	// //
	// // entityTagContext.setEntity(entity);
	// //
	// // //解析每一个子标签到childrenContent
	// // this.parseTag(childTag, childrenContent,
	// // entityTagContext.getPageContext(), entityTagContext);
	// // }
	// //
	// // return childrenContent.merge();
	// return "";
	// }

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.trs.dev4.jdk16.cms.IContentGenerator#parseObject(com.trs.dev4.jdk16
	 * .cms.IPublishable, com.trs.dev4.jdk16.cms.impl.TagItem,
	 * com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	public String parseObject(PublishObject entity, TagItem tagItem,
			TagContext tagContext) {

		PageContent childrenContent = new PageContent();

		// 遍历所有的子标签
		for (TagItem childTag : tagItem.getChildren()) {

			// 子标签中的HTML标签不通过Parser
			if (StringHelper.isEmpty(childTag.getName())) {
				childrenContent.add(childTag);
				continue;
			}

			// 构造子标签的TagContext及标签上下文对象
			TagContext entityTagContext = new TagContext(tagContext, childTag);

			entityTagContext.setEntity(entity);

			// 解析每一个子标签到childrenContent
			this.parseTag(childTag, childrenContent,
					entityTagContext.getPageContext(), entityTagContext);
		}

		return childrenContent.merge();

	}

	/**
	 * @see com.trs.dev4.jdk16.cms.IContentGenerator#listRegedTagParsers()
	 * @since liushen @ Feb 15, 2012
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, ITagParser> listRegedTagParsersAsMap() {
		return UnmodifiableMap.decorate(parsers);
	}

	/**
	 * @param parsers
	 *            the parsers to set
	 */
	public void setParsers(Map<String, ITagParser> parsers) {
		for (ITagParser parser : parsers.values()) {
			TagBeanInfo tagBeanInfo = parser.getBeanInfo();
			String tagName = tagBeanInfo.getName();
			this.parsers.put(tagName, parser);
			LOG.info("ITagParser [" + tagName + "] ==> " + parser + ".");
		}
	}

	/**
	 * @return the templateManager
	 */
	public ITemplateManager getTemplateManager() {
		return templateManager;
	}

	@SuppressWarnings("unchecked")
	public Map<String, ITagAware> getTagAwares() {
		return UnmodifiableMap.decorate(tagAwares);
	}

	public void setTagAwares(Map<String, ITagAware> tagAwares) {
		for (ITagAware tagAware : tagAwares.values()) {
			String tagClassName = tagAware.getTagClass().getSimpleName();
			this.tagAwares.put(tagClassName, tagAware);
			LOG.info("ITagAware [" + tagClassName + "] ==> " + tagAware + ".");
		}
	}

	/**
	 * @param templateManager
	 *            the {@link #templateManager} to set
	 */
	public void setTemplateManager(ITemplateManager templateManager) {
		this.templateManager = templateManager;
	}

	@Override
	public PublishObject getForeign(PublishObject publishable, String key, TagContext tagContext) {

		ITagAware tagAware = this.getAware(publishable.getMappedObject()
				.getClass().getSimpleName());
		if (null == tagAware) {
			return null;
		}
		List<ForeignRelationship> foreignRelationships = tagAware
				.listForeignRelationships();
		if (null == foreignRelationships) {
			return null;
		}

		ForeignRelationship foreignRelationship = null;
		for (ForeignRelationship t : foreignRelationships) {
			if (key.equals(t.getObjectName())) {
				foreignRelationship = t;
				break;
			}

		}
		if (null == foreignRelationship) {
			return null;
		}
		ITagAware nextTagAware = this.getAware(foreignRelationship
				.getAwareClassName());
		Object nextObject = null;
		String propertyAsStr = publishable.getPropertyAsStr(foreignRelationship.getAttributeName());
		if (StringHelper.isEmpty(propertyAsStr)) {
			nextObject = nextTagAware.getPublishObject(publishable.getPropertyAsInt(foreignRelationship.getAttributeName()));
		} else {
			nextObject = nextTagAware.getPublishObject(propertyAsStr, tagContext);
		}
		if (nextObject == null) {
			return null;
		}
		PublishObject nextPublishable = (!(nextObject instanceof PublishObject)) ? new PublishObject(
				nextObject) : (PublishObject) nextObject;
		publishable.put(foreignRelationship.getObjectName(), nextPublishable);
		return nextPublishable;
	}
}
