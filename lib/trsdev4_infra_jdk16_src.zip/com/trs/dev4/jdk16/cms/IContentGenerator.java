/*
 * created by TRS @ Jan 21, 2011
 */
package com.trs.dev4.jdk16.cms;

import java.util.Map;

import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.dao.PagedList;

/**
 * 内容生成器.
 * 
 * @author TRS
 * 
 */
public interface IContentGenerator {
	/**
	 * 获取指标解析器
	 * 
	 * @param name
	 * @return
	 * @since TRS @ Feb 12, 2011
	 */
	ITagParser getParser(String tagName);
	
	/**
	 * 注册解析器
	 * 
	 * @param tagParser
	 * @since TRS @ Mar 3, 2011
	 */
	void registerParser(ITagParser tagParser);

	/**
	 * 注销解析器
	 * 
	 * @param tagName
	 * @since TRS @ Mar 3, 2011
	 */
	void unregisterParser(String tagName);

	/**
	 * 返回所有已注册的置标解析器.
	 * 
	 * @since liushen @ Feb 15, 2012
	 */
	Map<String, ITagParser> listRegedTagParsersAsMap();

	/**
	 * 获取ITagAware
	 * @param obj
	 * @return
	 */
	ITagAware getAware(String obj);

	/**
	 * 根据模板名及页面上下文环境生成页面内容
	 * 
	 * @param templateName
	 *            页面模板名
	 * @param pageContext
	 *            页面上下文
	 * @return 解析后的页面内容
	 * @since TRS @ Feb 12, 2011
	 */
	String generate(String templateName, PageContext pageContext);
	
	/**
	 * 根据模板及页面上下文解析生成页面内容
	 * 
	 * @param template
	 *            页面模板
	 * @param pageContext
	 *            页面上下文
	 * @return 解析后的页面内容
	 * @since TRS @ Mar 3, 2011
	 */
	String generate(TemplateDocument templateDoc, PageContext pageContext);

	/**
	 * 
	 * @return
	 * @since TRS @ Mar 18, 2011
	 */
	@SuppressWarnings("rawtypes")
	String parseObjects(PagedList objects,
			TagItem tagItem, TagContext tagContext,ITagAware tagAware);

	/**
	 * 解析Object类型的标签
	 * @param obj
	 * @param tagItem
	 * @param tagContext
	 * @return
	 */
	String parseObject(PublishObject entity, TagItem tagItem, TagContext tagContext);
	
	/**
	 * @param publishable
	 * @param key
	 * @return
	 */
	PublishObject getForeign(PublishObject publishable, String key, TagContext tagContext);
}
