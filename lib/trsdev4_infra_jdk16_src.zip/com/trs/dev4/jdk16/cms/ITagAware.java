package com.trs.dev4.jdk16.cms;

import java.util.List;

import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;

/**
 * 负责给置标解析提供数据
 */
public interface ITagAware {

	/**
	 * 根据Objects类型的标签定义的内容，从系统中获取相应的数据源
	 * @param tagItem 当前的标签
	 * @param tagContext 当前的标签的上下文
	 * @return
	 */
	PagedList pagedPublishObjects(TagItem tagItem,TagContext tagContext);
	
	/**
	 * 根据Objects类型的标签定义的内容，从系统中获取相应的数据源
	 * @param searchFilter 查询条件
	 * @return
	 */
	PagedList pagedPublishObjects(SearchFilter searchFilter);
	/**
	 * 根据Object类型的标签定义的内容，从系统中获取相应的数据源
	 * @param id 标签指定的ID
	 */
	Object getPublishObject(int id);
	
	/**
	 * 根据Object类型的标签定义的内容，从系统中获取相应的数据源
	 * 
	 * @param obj
	 *            标签指定的内容
	 * @param tagContext
	 *            当前置标
	 */
	Object getPublishObject(Object obj, TagContext tagContext);

	/**
	 * 根据Object类型的标签定义的内容，从系统中获取相应的数据源
	 * @param searchFilter查询条件
	 * @return
	 */
	Object getPublishObject(SearchFilter searchFilter);
	/**
	 * 用于获取Object类型标签的数据源
	 * @param tagItem 当前置标
	 * @param tagContext 当前置标
	 * @return
	 */
	Object getPublishObject(TagItem tagItem,TagContext tagContext);
	/**
	 * 判断是否支持的标签Tag
	 * @param tagItem 当前置标
	 * @return 
	 */
	boolean supportedTag(TagItem tagItem);
	/**
	 * 判断是否支持的Tag名
	 * @param tagName 标签名称
	 * @return
	 */
	boolean supportedTag(String tagName);
	
	List<ForeignRelationship> listForeignRelationships();
	
	Class<?> getTagClass();
}
