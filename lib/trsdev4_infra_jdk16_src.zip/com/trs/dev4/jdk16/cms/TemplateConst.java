package com.trs.dev4.jdk16.cms;

/**
 * 广告位常量类
 * 
 * @author yangyu
 * @since 2011-3-29
 */
public class TemplateConst {

	/**
	 * 版区首页模板名称
	 */
	public static final String TEMPLATE_TYPENAME_BOARDLIST = "boardList";

	/**
	 * 版区帖子细览类别名称
	 */
	public static final String TEMPLATE_TYPENAME_POSTDETAIL = "postDetail";
	/**
	 * 无类别的模板类型
	 */
	public static final String TEMPLATE_TYPENAME_NOTYPE = "noType";

}
