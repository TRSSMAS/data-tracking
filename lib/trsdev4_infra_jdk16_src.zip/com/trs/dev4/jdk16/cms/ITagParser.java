/**
 * Created:         2005-4-1 16:13:18
 * Last Modified:   2005-4-1/2005-4-1
 * Description:
 *      class ITagParser
 */

package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;

/**
 * 置标解析器
 */
public interface ITagParser {

	/**
	 * 返回置标解析器的自我描述 实现建议，置标解析器的实现应该定义一个静态成员变量，并通过该方法返回，以避免不必要的对象创建。
	 * @return 置标解析器的自我描述
	 */
    public TagBeanInfo getBeanInfo();

    /**
     * 置标的解析方法
     * @param tagItem 当前置标
     * @param tagContext 置标的上下文
     * @return 解析指标后的内容
     */
	public String parse(TagItem tagItem, TagContext tagContext);
}