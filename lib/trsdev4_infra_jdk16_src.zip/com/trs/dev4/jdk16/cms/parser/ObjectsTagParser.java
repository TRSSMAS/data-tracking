/**
 * Created:         2006-3-28 18:41:21
 * Last Modified:   2006-3-28/2006-3-28
 * Description:
 *      class BaseTagParser
 */
package com.trs.dev4.jdk16.cms.parser;

import java.util.Map;

import com.trs.dev4.jdk16.cms.CMSException;
import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * List类型的置标基类
 * @author yangyu
 * @since 2011-5-21
 */
public class ObjectsTagParser implements ITagParser {
	
	/*
	 * (non-Javadoc)
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem, com.trs.dev4.jdk16.cms.impl.TagContext)
	 */
	public final String parse(TagItem tagItem, TagContext tagContext) {
		
		Map<String,String> attributeMap = tagContext.getAttributes();
		String obj = attributeMap.get("OBJ");
		if(StringHelper.isEmpty(obj )){
			throw new CMSException("TRS_OBJECT标签需要指定obj属性");
		}
		
		IContentGenerator contentGenerator = tagContext.getPageContext().getContentGenerator();
		ITagAware tagAware = contentGenerator.getAware(obj);
		
		if (null == tagAware) {
			return "tagAware is null";
		}
		
		PagedList pageList  = tagAware.pagedPublishObjects(tagItem, tagContext);
		
		return contentGenerator.parseObjects(pageList, tagItem, tagContext,tagAware);
	}

	@Override
	public TagBeanInfo getBeanInfo() {
		return  new TagBeanInfo("TRS_OBJECTS", "generate datetime",
				BodyType.EMPTY);
	}
	
}