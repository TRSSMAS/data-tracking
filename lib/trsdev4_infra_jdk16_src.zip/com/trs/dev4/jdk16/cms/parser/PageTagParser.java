package com.trs.dev4.jdk16.cms.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.utils.StringHelper;

public class PageTagParser implements ITagParser {

	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_PAGE", "Page information", BodyType.EMPTY);
	}

	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {

		int pageSize = tagContext.getAttribute("pageSize", 20);
		int total = tagContext.getAttribute("total", 100);
		String countField = tagContext.getAttribute("value");
		String usedFirst = tagContext.getAttribute("first");
		String usedPrev = tagContext.getAttribute("prev");
		String usedNext = tagContext.getAttribute("next");
		String usedLast = tagContext.getAttribute("last");
		String urlPattern = tagContext.getAttribute("urlPattern");

		PublishObject entity = tagContext.getEntity();
		if (null != entity && StringHelper.isNotEmpty(countField)) {
			total = entity.getPropertyAsInt(countField);
		}
		int currentPage = tagContext.getAttribute("pageNo", -1);
		if (currentPage == -1) {
			currentPage = tagContext.getPageContext().getRequestParameter(
					"pageNo", 0);
		}
		int pageNum = total / pageSize + 1;
		List<Object> pages = new ArrayList<Object>();
		if (StringHelper.isNotEmpty(usedFirst) && currentPage != 1) {
			buildPage(urlPattern, pages, usedFirst, 0);
		}
		if (StringHelper.isNotEmpty(usedPrev) && currentPage != 1) {
			buildPage(urlPattern, pages, usedPrev, currentPage - 1);
		}
		int start = 1, end = pageNum;
		int step = tagContext.getAttribute("step", 2);
		if (currentPage - step > 1) {
			start = currentPage - step;
			buildPage(urlPattern, pages, "...", start - 1);
		} 
		end = start + 2*step ;
		end = pageNum>end?end:pageNum;
		if(end == pageNum){
			start = end - 2*step - 1;
			start = start>1 ? start:1;
		}
		
		for (int i = start; i <= end; i++) {
			buildPage(urlPattern, pages, String.valueOf(i), i);
		}
		
		if (end < pageNum) {
			buildPage(urlPattern, pages, "...", end + 1);
		}

		if (StringHelper.isNotEmpty(usedNext) && currentPage != pageNum) {
			buildPage(urlPattern, pages, usedNext, currentPage + 1);
		}

		if (StringHelper.isNotEmpty(usedLast) && currentPage != pageNum) {
			buildPage(urlPattern, pages, usedLast, pageNum);
		}

		PagedList pageList = new PagedList<Object>(pages);

		IContentGenerator contentGenerator = tagContext.getPageContext()
				.getContentGenerator();
		return contentGenerator.parseObjects(pageList, tagItem, tagContext,
				null);

	}

	private void buildPage(String urlPattern, List<Object> pages, String title,
			int i) {
		Map<String, String> page = new HashMap<String, String>();
		page.put("title", title);
		page.put("link",
				StringHelper.replaceAll(urlPattern, "$", String.valueOf(i)));
		pages.add(page);
	}

}
