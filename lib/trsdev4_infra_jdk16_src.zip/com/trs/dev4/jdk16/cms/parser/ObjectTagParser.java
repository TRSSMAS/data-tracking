/**
 * Created:         2006-3-28 18:41:21
 * Last Modified:   2006-3-28/2006-3-28
 * Description:
 *      class BaseTagParser
 */
package com.trs.dev4.jdk16.cms.parser;

import java.util.Map;

import com.trs.dev4.jdk16.cms.CMSException;
import com.trs.dev4.jdk16.cms.IContentGenerator;
import com.trs.dev4.jdk16.cms.ITagAware;
import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.PublishObject;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.utils.StringHelper;

public class ObjectTagParser implements ITagParser {
	
	public String parse(TagItem tagItem, TagContext tagContext) {
		
		Map<String,String> attributeMap = tagContext.getAttributes();
		
		String obj = attributeMap.get("OBJ");
		if(StringHelper.isEmpty(obj)){
			throw new CMSException("TRS_OBJECT标签需要指定obj属性");
		}
		
		IContentGenerator contentGenerator = tagContext.getPageContext().getContentGenerator();
		ITagAware tagAware = contentGenerator.getAware(obj);
		if(null == tagAware){
			return "tagAware is null";
		}
		Object object  = tagContext.getEntity();
		if(object == null){
			object = tagAware.getPublishObject(tagItem, tagContext);
		}
		
		if(object == null){
			return "";
		}
		PublishObject publishObject = null;
		
		if (object instanceof PublishObject) {
			publishObject = (PublishObject) object;
		} else {
			publishObject = new PublishObject(object);
		}
		return contentGenerator.parseObject(publishObject, tagItem, tagContext);
	}

	@Override
	public TagBeanInfo getBeanInfo() {
		return  new TagBeanInfo("TRS_OBJECT", "generate datetime",
				BodyType.EMPTY);
	}
	
}