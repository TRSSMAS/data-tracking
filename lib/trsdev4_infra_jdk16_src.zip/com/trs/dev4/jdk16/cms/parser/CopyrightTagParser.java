/*
 * Created: TRS@Mar 3, 2011 10:39:38 PM
 */
package com.trs.dev4.jdk16.cms.parser;

import com.trs.dev4.jdk16.cms.ITagParser;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo;
import com.trs.dev4.jdk16.cms.impl.TagBeanInfo.BodyType;
import com.trs.dev4.jdk16.cms.impl.TagContext;
import com.trs.dev4.jdk16.cms.impl.TagItem;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 解析TRS_COPYRIGHT标签，供测试用<br>
 * 
 */
public class CopyrightTagParser implements ITagParser {

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#getBeanInfo()
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public TagBeanInfo getBeanInfo() {
		return new TagBeanInfo("TRS_COPYRIGHT", "Copyright information",
				BodyType.EMPTY);
	}

	/**
	 * @see com.trs.dev4.jdk16.cms.ITagParser#parse(com.trs.dev4.jdk16.cms.impl.TagItem,
	 *      com.trs.dev4.jdk16.cms.impl.TagContext)
	 * @since TRS @ Mar 3, 2011
	 */
	@Override
	public String parse(TagItem tagItem, TagContext tagContext) {
		String year = tagItem.getAttributeTrim("YEAR");
		if (StringHelper.isEmpty(year)) {
			year = "2010";
		}
		return "TRS "+year+".";
	}
}
