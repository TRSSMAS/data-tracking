package com.trs.dev4.jdk16.cms;

import com.trs.dev4.jdk16.cms.bo.PageLink;
import com.trs.dev4.jdk16.model.IBaseManager;
import com.trs.dev4.jdk16.session.RequestContext;

/**
 * 链接管理的业务层
 * @author yangyu
 * @since 2011-5-31
 */
public interface IPageLinkManager extends IBaseManager<PageLink> {

	/**
	 * 保存链接
	 * @param newLink 新的链接
	 */
	public PageLink save(PageLink newLink);

	/**
	 * 根据value值获取Link对象
	 * @param value
	 * @return
	 */
	public PageLink getByName(String value);

	/**
	 * 查找当前请求是否有匹配的模板.
	 * 
	 * @param reqCtx
	 *            请求上下文
	 * @param actionMethodPart
	 *            该参数用于直接支持Spring的MulitAction；传入的值为确定action的参数名和值，如
	 *            <code>?action=bar</code>； 对于不是Spring的MulitAction的情况，应传入
	 *            <code>null</code>.
	 * @return 匹配的模板的标识名；如果没找到匹配的模板，则返回<code>null</code>.
	 * @since liushen @ Jan 30, 2012
	 */
	public String findTemplateName(RequestContext reqCtx, String actionMethodPart);

	/**
	 * @param bean
	 * @since liushen @ Feb 1, 2012
	 */
	void registerTemplateAware(ITemplateAware bean);
	
}
