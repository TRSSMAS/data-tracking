package com.trs.dev4.jdk16.cms;

import java.util.Map;

import net.sf.cglib.beans.BeanMap;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 置标组件解析对象
 * @author Administrator
 *
 */
public class PublishObject{

	private BeanMap beanMappedObject; 
	
	private Object mappedObject;
	
	
	public Object getProperty(String name) {
		Object obj = null;
		if(mappedObject instanceof Map<?, ?>){
			obj = ((Map) mappedObject).get(name);
		}else{
			obj = beanMappedObject.get(name);
		}
		
		if(null == obj){
			return null;
//			return "obj["+name+"] is null";
		}
		return obj;
	}
	
	public int getPropertyAsInt(String name) {
		Object obj = null;
		if(mappedObject instanceof Map<?, ?>){
			obj = ((Map) mappedObject).get(name);
		}else{
			obj = beanMappedObject.get(name);
		}
		if(null == obj){
			return -1;
//			return "obj["+name+"] is null";
		}
		return StringHelper.parseInt(obj.toString());
	}
	
	public String getPropertyAsStr(String name) {
		Object obj = null;
		if(mappedObject instanceof Map<?, ?>){
			obj = ((Map) mappedObject).get(name);
		}else{
			obj = beanMappedObject.get(name);
		}
		if(null == obj){
			return null;
//			return "obj["+name+"] is null";
		}
		return obj.toString();
	}

	protected PublishObject(){
		
	}
	
	public PublishObject(Object object){
		beanMappedObject = BeanMap.create(object);
		mappedObject = object;
	}

	public void put(String key,Object value){
		beanMappedObject.put(key, value);
	}


	/**
	 * @return the mappedObjectClass
	 */
	public Object getMappedObject() {
		return mappedObject;
	}
}
