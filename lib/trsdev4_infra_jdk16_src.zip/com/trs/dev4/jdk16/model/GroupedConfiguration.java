/*
 * Created: liushen@Feb 19, 2010 4:46:00 PM
 */
package com.trs.dev4.jdk16.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.trs.dev4.jdk16.exception.BussinessException;
import com.trs.dev4.jdk16.utils.AssertUtil;
import com.trs.dev4.jdk16.utils.ObjectUtil;

/**
 * 相同前缀的一组配置.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class GroupedConfiguration {

	private List<Configuration> listConfigs;

	private String prefix;

	/**
	 * 
	 */
	public GroupedConfiguration(List<Configuration> listConfigs) {
		assertValid(listConfigs);
		this.listConfigs = listConfigs;
		this.prefix = listConfigs.get(0).getPrefix();
	}

	/**
	 * @param listConfigs
	 * @creator liushen @ Feb 19, 2010
	 */
	private void assertValid(List<Configuration> listConfigs) {
		AssertUtil.notNullOrEmpty(listConfigs, "分组配置不能为空.");

		Set<String> prefixs = new HashSet<String>();
		for (Configuration configuration : listConfigs) {
			prefixs.add(configuration.getPrefix());
		}
		if (prefixs.size() != 1) {
			throw new BussinessException("配置前缀不唯一: " + prefixs + ".");
		}
	}

	public String getPrefix() {
		return prefix;
	}

	/**
	 * Get the {@link #listConfigs}.
	 * 
	 * @return the {@link #listConfigs}.
	 */
	public List<Configuration> getListConfigs() {
		return listConfigs;
	}

	/**
	 * 以map形式返回各配置.
	 * 
	 * @return
	 * @creator liushen @ Feb 19, 2010
	 */
	public Map<String, Configuration> getMapConfigs() {
		Map<String, Configuration> resultMap = new HashMap<String, Configuration>();
		for (Configuration configuration : listConfigs) {
			if (ObjectUtil.equals(configuration.getPrefix(), prefix)) {
				resultMap.put(configuration.getName(), configuration);
			}
		}
		return resultMap;
	}

}
