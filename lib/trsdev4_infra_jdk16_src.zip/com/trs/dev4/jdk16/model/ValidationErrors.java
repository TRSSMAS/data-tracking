/*
 * Created: Administrator@Feb 10, 2009 8:43:08 AM
 */
package com.trs.dev4.jdk16.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 记录验证结果集.<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class ValidationErrors {
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(ValidationErrors.class);
	/**
	 *
	 */
	public final static ValidationErrors NO_ERRORS = new ValidationErrors();
	/**
	 *
	 */
	private List<ValidationError> errors = new ArrayList<ValidationError>();

	/**
	 * 增加一个验证错误.
	 * 
	 * @param field
	 *            该验证的字段
	 * @param errorCode
	 *            验证结果代码
	 * @param defaultMessage
	 *            具体信息
	 */
	public void error(String field,String errorCode,String defaultMessage){
		ValidationError error = new ValidationError(field, errorCode,
				defaultMessage);
		logger.error("Found validation error:" + defaultMessage + ","
				+ errorCode + "," + field);
		errors.add(error);
	}

	/**
	 * 增加一个验证错误.
	 * 
	 * @param field
	 *            该验证的字段
	 * @param errorCode
	 *            验证结果代码
	 * @param defaultMessage
	 *            具体信息
	 */
	public void errorIfEmpty(String field, String value,String errorCode,
			String defaultMessage) {
		if (StringHelper.isEmpty(value)) {
			ValidationError error = new ValidationError(field, errorCode,
					defaultMessage);
			logger.error("Found validation error:" + defaultMessage + ","
					+ errorCode + "," + field);
			errors.add(error);
		}
	}

	/**
	 * 增加多个验证错误.
	 * 
	 * @param deltaErrors
	 *            多个验证错误
	 * @since liushen @ Aug 4, 2010
	 */
	public void addErrors(ValidationErrors deltaErrors) {
		if (deltaErrors == null || false == deltaErrors.hasErrors()) {
			return;
		}
		for (ValidationError error : errors) {
			logger.error("Found validation error:" + error.getDefaultMessage()
					+ "," + error.getErrorCode() + "," + error.getField());
		}
		errors.addAll(deltaErrors.errors);
	}

	/**
	 * 
	 * @return 收集的所有错误
	 */
	public List<ValidationError> getErrors(){
		return Collections.unmodifiableList(errors);
	}

	/**
	 * 
	 * @return 错误数量
	 */
	public int size(){
		return errors.size();
	}

	/**
	 * 获取某个校验错误.
	 * 
	 * @param index
	 *            第几个错误，从0开始计算(0为第一个错误)
	 * @return 校验错误
	 */
	public ValidationError getError(int index){
		return errors.get(index);
	}

	/**
	 * 是否有校验错误.
	 * 
	 * @return 有校验错误返回<code>true</code>, 否则返回<code>false</code>.
	 * @creator liushen @ Feb 18, 2010
	 */
	public boolean hasErrors() {
		return size() > 0;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @creator liushen @ Feb 18, 2010
	 */
	@Override
	public String toString() {
		if (size() == 0) {
			return "ValidationErrors [No error].";
		}
		StringBuilder builder = new StringBuilder();
		builder.append("ValidationErrors [").append(size()).append("] errors: ");
		for ( ValidationError error : errors){
			builder.append(error.getDefaultMessage()).append("{")
					.append(error.getField()).append("}").append(";");
		}
		builder.append(".");
		return builder.toString();
	}

}
