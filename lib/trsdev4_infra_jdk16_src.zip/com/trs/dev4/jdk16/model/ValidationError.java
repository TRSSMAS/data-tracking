/*
 * Created: Administrator@Feb 10, 2009 8:43:16 AM
 */
package com.trs.dev4.jdk16.model;

import com.trs.dev4.jdk16.exception.ExceptionUtil;

/**
 * 职责: 记录验证结果，不符合验证条件的字段记录到此对象.配合IValidator接口使用。<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public class ValidationError {

	/**
	 * 
	 */
	public static final ValidationError NO_ERROR = new ValidationError();

	/**
	 * 
	 */
	private String field;

	/**
	 * 
	 */
	private String errorCode;

	/**
	 * 
	 */
	private String defaultMessage;

	/**
	 * 原始调用栈帧，内部属性，用于快速定位错误来源。
	 */
	private Throwable originStack;

	/**
	 * 
	 */
	ValidationError() {
		this(null, null, null);
	}

	/**
	 * @param field
	 * @param errorCode
	 * @param defaultMessage
	 * @param originStack
	 */
	ValidationError(String field, String errorCode, String defaultMessage) {
		this.field = field;
		this.errorCode = errorCode;
		this.defaultMessage = defaultMessage;

		originStack = new Exception();
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[").append(field);
		sb.append(": ").append(errorCode);
		sb.append(", ").append(defaultMessage);
		sb.append("; caller: ").append(
				ExceptionUtil.getMainCaller(originStack, getClass(),
						ValidationErrors.class));
		sb.append("]");
		return sb.toString();
	}
	
	/**
	 * Get the {@link #field}. 
	 * @return the {@link #field}.
	 */
	public String getField() {
		return field;
	}
	/**
	 * Set the {@link #field}.
	 * @param field the field to set
	 */
	public void setField(String field) {
		this.field = field;
	}
	/**
	 * Get the {@link #errorCode}. 
	 * @return the {@link #errorCode}.
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * Set the {@link #errorCode}.
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * Get the {@link #defaultMessage}. 
	 * @return the {@link #defaultMessage}.
	 */
	public String getDefaultMessage() {
		return defaultMessage;
	}
	/**
	 * Set the {@link #defaultMessage}.
	 * @param defaultMessage the defaultMessage to set
	 */
	public void setDefaultMessage(String defaultMessage) {
		this.defaultMessage = defaultMessage;
	}
	
}
