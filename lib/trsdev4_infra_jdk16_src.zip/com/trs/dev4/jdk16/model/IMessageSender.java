/*
 * Created: TRS@Feb 11, 2012 5:44:41 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 职责: 消息发送控制器<br>
 * 
 */
public interface IMessageSender {

}
