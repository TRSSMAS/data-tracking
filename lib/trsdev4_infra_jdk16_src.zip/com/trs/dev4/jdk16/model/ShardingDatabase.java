/*
 * Created: TRS@Feb 13, 2012 9:39:10 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 职责: <br>
 *
 */
public class ShardingDatabase extends BaseEntity {

	/**
	 * @since TRS @ Feb 13, 2012
	 */
	private static final long serialVersionUID = 1L;

}
