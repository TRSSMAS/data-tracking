/*
 * @revised liushen@Apr 18, 2009
 */
package com.trs.dev4.jdk16.model;

import java.util.List;
import java.util.Map;

import com.trs.dev4.jdk16.dao.HQLBuilder;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.DAOException;

/**
 * 领域对象管理的公共接口(基接口).
 */
public interface IBaseManager<T> extends IModuleLifecycle {

	/**
	 * 向数据库中插入一个新对象.
	 *
	 * @param obj
	 *            待插入的对象.
	 * @return 新对象的ID.
	 */
	public int addNew(T obj);

	/**
	 * 校验对象.
	 *
	 * @param obj
	 *            待插入的对象.
	 * @return 校验结果
	 * @creator liushen @ Feb 18, 2010
	 */
	ValidationErrors validate(T obj);

	/**
	 * 批量添加新对象
	 *
	 * @param obj
	 *            待插入的对象.
	 * @return 实际添加的条数
	 * @throws DAOException
	 * @creator fangxiang @ Mar 17, 2009
	 */
	public int batchAddNew(T[] obj);

	/**
	 *
	 * @param object
	 */
	public void delete(T object);

	/**
	 *
	 * @creator fangxiang @ Mar 17, 2009
	 */
	public void batchDelete(HQLBuilder builder);

	/**
	 *
	 * @creator fangxiang @ Mar 17, 2009
	 */
	public void batchDelete(int[] objectIds);

	/**
	 *
	 * @param sf
	 *            查询条件.
	 * @return 实际删除的条数
	 */
	public int delete(SearchFilter sf);

	/**
	 * 更新对象(或添加).
	 *
	 * @param masObj
	 * @throws DAOException
	 */
	public void update(T masObj);

	/**
	 * 更新对象的指定字段到数据库. 该方法可配合hibernate实体对象的dynamicUpdate配置来提高性能.
	 * 
	 * @param id
	 *            待更新对象的ID
	 * @param updatedFields
	 *            所有要更新的字段的Map，Key为字段名，Object为字段值
	 * @return 返回更新的记录数; 如果没有记录被更新, 则返回<code>0</code>.
	 * @since liushen @ Dec 2, 2011
	 */
	int update(int id, Map<String, Object> updatedFields);

	/**
	 * 是 {@link #update(int, Map)} 只更新一个字段的特例。
	 * 
	 * @see #update(int, Map)
	 * @since liushen @ Dec 2, 2011
	 */
	int update(int id, String field, Object value);

	/**
	 * 批量更新对象或数据.
	 *
	 * @param builder
	 * @creator fengjianhua @ 2009-4-14
	 */
	public int batchUpdate(HQLBuilder builder);
	
	/**
	 * 将所有字段field值为旧值oldValue的记录改为新值newValue；并且整个过程只执行一条Update语句，以提高性能.
	 * @param field 字段
	 * @param oldValue 旧值
	 * @param newValue 新值
	 * @return 影响的记录条数
	 * @since liushen @ Jun 8, 2011
	 */
	int bulkUpdate(String field, Object oldValue, Object newValue);

	/**
	 *
	 * @param objectId
	 * @return
	 * @throws DAOException
	 */
	public T get(int objectId);

	/**
	 * For Readonly
	 * @param objectId
	 * @return
	 * @throws DAOException
	 */
	public T find(int objectId);

	/**
	 * 提取所有对象.
	 *
	 * @return 对象列表.
	 */
	public List<T> listAllObjects();

	/**
	 * 按查询条件分页提取.
	 *
	 * @return 分页结果.
	 */
	public PagedList<T> pagedObjects(SearchFilter sf);

	/**
	 * 分页提取所有对象.
	 *
	 * @return 分页结果.
	 * @since liushen @ Apr 22, 2010
	 */
	public PagedList<T> pagedAll();

	/**
	 * @deprecated liushen@Mar 29, 2011:use {@link #exists(String, Object, int)}
	 */
	@Deprecated
	public boolean exists(Object value,int excludedId);

	/**
	 *
	 * @param idArray
	 * @return
	 * @creator fangxiang @ Mar 17, 2009
	 */
	public List<T> listObjects(int[] idArray);

	/**
	 * 获取对象T的总数.
	 *
	 * @return
	 * @creator liushen @ Mar 19, 2009
	 */
	public int total();

	/**
	 * 获取对象T的总数.
	 *
	 * @param sf
	 * @return
	 * @creator fengjianhua @ 2009-7-21
	 */
	public int total(SearchFilter sf);

	/**
	 * 获取最新的N个已审核通过的对象T, 适用于不需要获取总数的查询.
	 *
	 * @param amount
	 * @return
	 * @creator liushen @ Apr 16, 2009
	 */
	public List<T> listLatest(int amount);

	/**
	 * 根据查询条件获得对象列表.
	 *
	 * @param sf
	 * @return
	 * @creator changpeng @ 2009-5-15
	 */
	public List<T> listAllObjects(SearchFilter sf);

	/**
	 * 根据唯一名称找到一个对象
	 * 
	 * @param name
	 * @return
	 * @creator fengjianhua @ 2009-7-24
	 * @deprecated liushen@Mar 29, 2011: use {@link #findUnique(String, Object)}
	 */
	@Deprecated
	public T findByUniqueField(String name);

	/**
	 * 根据唯一字段找到一个对象
	 *
	 * @param field
	 * @param value
	 * @return
	 * @creator fengjianhua @ 2009-7-24
	 */
	public T findUnique(String field, Object value);

	/**
	 * 返回给定字段等于给定的取值的第一个对象.
	 *
	 * @param field
	 * @param value
	 * @return
	 * @since liushen @ Apr 22, 2010
	 */
	public T findFirst(String field, Object value);

	/**
	 * 获取或者创建一个新的对象.
	 *
	 * @param entityId
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public T getOrNew(int entityId);

	/**
	 * 保存或更新对象; 当更新时，不自动修改lastModified值，使系统自身计划调度的更新不会对lastModified造成干扰.
	 * 
	 * @since fangxiang @ Apr 20, 2010
	 */
	public void saveOrUpdate(T entity);

	/**
	 * 获取第一个符合条件的对象
	 *
	 * @param sf
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public T findFirst(SearchFilter sf);

	/**
	 * 获取符合检索条件的唯一对象，如果不是唯一的话，则抛出异常
	 *
	 * @param sf
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public T findUnique(SearchFilter sf);

	/**
	 * 批量删除对象
	 * 
	 * @param objects
	 * @return
	 * @since fangxiang @ Nov 13, 2010
	 */
	public void batchDelete(T[] objects);

	/**
	 *批量保存或更新对象
	 *
	 * @param objects
	 * @since fangxiang @ Nov 13, 2010
	 */
	public void batchSaveOrUpdate(T[] objects);

	/**
	 * 
	 * 
	 * @since fangxiang @ Nov 16, 2010
	 */
	public void truncate();

	/**
	 * 验证指定的字段值是否存在
	 * 
	 * @param fieldName
	 *            字段名
	 * @param value
	 *            值
	 * @param excludedId
	 *            排除ID
	 * @return
	 */
	public boolean exists(String fieldName, Object value, int excludedId);

	/**
	 * 查询对象加载统计器
	 * 
	 * @return
	 */
	public ObjectCounter getObjectCounter();
}
