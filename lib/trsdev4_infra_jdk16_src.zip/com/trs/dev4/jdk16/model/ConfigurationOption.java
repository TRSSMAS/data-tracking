/*
 * Created: TRS@Jan 30, 2012 2:21:16 PM
 */
package com.trs.dev4.jdk16.model;

import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 职责:记录配置项{@link Configuration}的选项，通过{@link IConfigurationOptionReader}动态获取 <br>
 * 不持久化；
 * 
 * @since 2012.01.30
 */
public class ConfigurationOption {
	/**
	 * 值
	 */
	private String value;
	/**
	 * 显示标题
	 */
	private String title;
	/**
	 * 备注，备用
	 */
	private String comment;
	/**
	 * URI，供点击查看更多使用，备用
	 */
	private String uri;
	/**
	 * 缩略图，备用
	 */
	private String thumb;

	/**
	 * 默认构造函数，所有的字符串赋值为空串
	 */
	public ConfigurationOption() {
		this.value = this.title = this.comment = this.uri = this.thumb = "";
	}

	/**
	 * 带有值的构造函数，其他字符串赋值为空串
	 * 
	 * @param value
	 *            值
	 */
	public ConfigurationOption(String value) {
		this();
		this.value = value;
	}
	
	/**
	 * 带有值和显示信息的构造函数，其他字符串赋值为空串
	 * 
	 * @param value
	 *            值
	 * @param title
	 *            显示标题
	 */
	public ConfigurationOption(String value, String title) {
		this();
		this.value = value;
		this.title = title;
	}

	/**
	 * 将值（字符串）直接转换成整数，便于使用
	 * 
	 * @return 字符串代表的整数。如果不是整数，则返回为-1。
	 * @since TRS @ Jan 31, 2012
	 */
	public int intValue() {
		return StringHelper.parseInt(this.value);
	}

	/**
	 * @return the {@link #value}
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the {@link #value} to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the {@link #title}
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the {@link #title} to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the {@link #comment}
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment
	 *            the {@link #comment} to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the {@link #uri}
	 */
	public String getUri() {
		return uri;
	}

	/**
	 * @param uri
	 *            the {@link #uri} to set
	 */
	public void setUri(String uri) {
		this.uri = uri;
	}

	/**
	 * @return the {@link #thumb}
	 */
	public String getThumb() {
		return thumb;
	}

	/**
	 * @param thumb
	 *            the {@link #thumb} to set
	 */
	public void setThumb(String thumb) {
		this.thumb = thumb;
	}
}
