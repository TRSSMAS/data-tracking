/*
 * Created: liushen@Oct 24, 2009 1:33:40 PM
 */
package com.trs.dev4.jdk16.model.example;

import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.model.IBaseManager;

/**
 * 职责: .<br>
 * 
 * @author TRS信息技术股份有限公司
 */
public interface IFooManager extends IBaseManager<Foo> {

	void addNewArchivedFoo(ArchivedFoo archivedFoo);

	int totalArchived();

	ArchivedFoo getArchived(int id);

	/**
	 * @return
	 * @since liushen @ May 17, 2010
	 */
	PagedList<ArchivedFoo> pagedArchived();

}
