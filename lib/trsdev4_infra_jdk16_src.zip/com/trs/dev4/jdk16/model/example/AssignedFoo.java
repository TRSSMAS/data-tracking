/*
 * Created: liushen@May 7, 2010 5:00:26 PM
 */
package com.trs.dev4.jdk16.model.example;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.trs.dev4.jdk16.model.BaseEntity;

/**
 * 指定ID的例子. <br>
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "ASSIGNEDFOO")
@GenericGenerator(name = "idStrategy", strategy = "org.hibernate.id.Assigned")
public class AssignedFoo extends BaseEntity {

	private String name;

	/**
	 * 
	 */
	public AssignedFoo() {
	}

	/**
	 * @param id
	 * @param name
	 */
	public AssignedFoo(int id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * @return the {@link #name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the {@link #name} to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @see java.lang.Object#toString()
	 * @since liushen @ Jun 22, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AssignedFoo [id=");
		builder.append(id);
		builder.append(", name=");
		builder.append(name);
		builder.append("]");
		return builder.toString();
	}

}
