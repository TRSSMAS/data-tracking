/*
 * Created: TRS@Feb 13, 2012 9:39:34 PM
 */
package com.trs.dev4.jdk16.model;

/**
 * 职责: <br>
 *
 */
public interface IShardingDatabaseManager extends IBaseManager<ShardingDatabase> {

}
