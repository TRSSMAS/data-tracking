/*
 * @revised liushen@Apr 18, 2009
 */
package com.trs.dev4.jdk16.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.collections.map.UnmodifiableMap;
import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.dao.HQLBuilder;
import com.trs.dev4.jdk16.dao.IAccessor;
import com.trs.dev4.jdk16.dao.PagedList;
import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.exception.DAOException;
import com.trs.dev4.jdk16.exception.ExceptionUtil;
import com.trs.dev4.jdk16.exception.ValidateAssertionException;
import com.trs.dev4.jdk16.utils.ArrayUtil;

/**
 * 领域对象管理的基类，实现对领域对象涉及的数据库等底层操作的封装.
 */
public abstract class BaseManager<T extends ISerializableEntity> implements
		IBaseManager<T>, IConfigurable {

	/**
	 * 
	 */
	private static Map<Class<?>, Integer> initialiedManagers = new ConcurrentHashMap<Class<?>, Integer>();

	/**
	 * 获得所有的初始化Manager，及其初始化次数
	 * 
	 * @return
	 * @since TRS @ Feb 7, 2012
	 */
	@SuppressWarnings("unchecked")
	public final static Map<Class<?>, Integer> getInitializedManager() {
		return UnmodifiableMap.decorate(BaseManager.initialiedManagers);
	}

	/**
	 *
	 */
	private static final Logger LOG = Logger.getLogger(BaseManager.class);

	/**
	 * 操作数据库的访问接口.
	 */
	private IAccessor<T> accessor;

	/**
	 * 
	 */
	protected ObjectCounter objectCounter = new ObjectCounter(this.getClass()
			.getSimpleName());

	/**
	 * 标识是新增还是更新.
	 */
	public static enum Mode {
		INSERT("insert"), UPDATE("update");

		String modeName;

		Mode(String name) {
			this.modeName = name;
		}

	}

	/**
	 * 构造函数, 仅子类可见.
	 */
	protected BaseManager() {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Class(" + this + ") Manager constructed successfully,callers:" + ExceptionUtil.getMainCaller(5));
		}
		Class<?> thisClass = this.getClass();
		if (initialiedManagers.containsKey(thisClass) == false) {
			initialiedManagers.put(thisClass, 1);
		} else {
			initialiedManagers.put(thisClass, initialiedManagers.get(thisClass) + 1);
		}
	}

	/**
	 * 先校验，再保存.
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#addNew(com.trs.dev4.jdk16.model.IEntity)
	 */
	@Override
	public int addNew(T masObj) {
		assertValid(masObj);
		onValidationPass(masObj, Mode.INSERT);

		if (masObj instanceof BaseEntity) {
			BaseEntity bo = (BaseEntity) masObj;
			bo.setCreatedTime(System.currentTimeMillis());
			bo.setLastModifiedTime(System.currentTimeMillis());
		}

		Serializable oSerializable = accessor.insert(masObj);

		if (oSerializable instanceof Number) {
			return ((Number) oSerializable).intValue();
		}
		//
		objectCounter.countSave();
		return 0;
	}

	/**
	 * @param masObj
	 * @creator liushen @ Feb 19, 2010
	 */
	private void assertValid(T masObj) {
		ValidationErrors validationErrors = validate(masObj);
		// TODO liushen @ May 23, 2010:
		// 以下if分支简化为ValidationErrors.assertValid并抛出原始调用堆栈
		if (validationErrors.hasErrors()) {
			throw new ValidateAssertionException("校验未通过，不能保存对象[" + masObj
					+ "]: " + validationErrors);
		}
	}

	/**
	 * 校验通过后的回调方法.
	 * 
	 * @param masObj
	 * @param mode
	 *            是新增还是更新
	 * @since liushen @ May 16, 2010
	 */
	protected void onValidationPass(T masObj, Mode mode) {
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#update(com.trs.dev4.jdk16.model.IEntity)
	 */
	@Override
	public void update(T masObj) {
		assertValid(masObj);
		onValidationPass(masObj, Mode.UPDATE);

		if (masObj instanceof BaseEntity) {
			BaseEntity bo = (BaseEntity) masObj;
			bo.setLastModifiedTime(System.currentTimeMillis());
		}

		accessor.update(masObj);
		objectCounter.countSave();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#update(int, java.util.Map)
	 * @since liushen @ Dec 2, 2011
	 */
	@Override
	public int update(int id, Map<String, Object> updatedFields) {
		return accessor.update(id, updatedFields);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#update(int, java.lang.String,
	 *      java.lang.Object)
	 * @since liushen @ Dec 2, 2011
	 */
	@Override
	public int update(int id, String field, Object value) {
		return accessor.update(id, field, value);
	}

	/**
	 *
	 * @param masObj
	 * @return
	 * @creator liushen @ May 18, 2009
	 */
	@Override
	public ValidationErrors validate(T masObj) {
		return new ValidationErrors();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#delete(com.trs.dev4.jdk16.model.IEntity)
	 */
	@Override
	public void delete(T object) {
		accessor.delete(object);
		objectCounter.countDelete();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#delete(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public int delete(SearchFilter sf) {
		int count = accessor.delete(sf);
		objectCounter.countDelete(count);
		return count;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#batchUpdate(com.trs.dev4.jdk16.dao.HQLBuilder)
	 */
	@Override
	public int batchUpdate(HQLBuilder builder) {
		int count = accessor.batchUpdate(builder);
		objectCounter.countSave(count);
		return count;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#bulkUpdate(java.lang.String,
	 *      java.lang.Object, java.lang.Object)
	 * @since liushen @ Jun 8, 2011
	 */
	@Override
	public int bulkUpdate(String field, Object oldValue, Object newValue) {
		HQLBuilder hqlBuilder = HQLBuilder.UPDATE(accessor.getClassType());
		hqlBuilder.setNewValue(field, newValue).addEqCondition(field, oldValue);
		return batchUpdate(hqlBuilder);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#find(int)
	 */
	@Override
	public T find(int objectId) {
		T object = doAfterObjectGot(accessor.getObject(objectId));
		objectCounter.countGet();
		//
		return object;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#get(int)
	 */
	@Override
	public T get(int objectId) {
		T object = doAfterObjectGot(accessor.getObject(objectId));
		objectCounter.countGet();
		//
		return object;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#listAllObjects()
	 */
	@Override
	public List<T> listAllObjects() {
		List<T> objects = doAfterObjectGot(accessor.listObjects());
		objectCounter.countSearch(objects.size(), 0);
		return objects;
	}

	/**
	 *
	 * @param sf
	 * @return
	 */
	public List<T> listAllObjects(SearchFilter sf) {
		List<T> objects = doAfterObjectGot(accessor.listObjects(sf));
		objectCounter.countSearch(objects.size(), 0);
		return objects;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#pagedObjects(com.trs.dev4.jdk16.dao.SearchFilter)
	 */
	@Override
	public PagedList<T> pagedObjects(SearchFilter sf) {
		PagedList<T> pagedObjects = doAfterObjectGot(accessor.pagedObjects(sf));
		objectCounter.countSearch(pagedObjects.size(), 0);
		return pagedObjects;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#pagedAll()
	 * @since liushen @ Apr 22, 2010
	 */
	@Override
	public PagedList<T> pagedAll() {
		PagedList<T> pagedObjects = doAfterObjectGot(accessor.pagedAll());
		objectCounter.countSearch(pagedObjects.size(), 0);
		return pagedObjects;
	}

	/**
	 * Get the {@link #accessor}.
	 *
	 * @return the {@link #accessor}.
	 */
	protected IAccessor<T> getAccessor() {
		return accessor;
	}

	/**
	 * Set the {@link #accessor}.
	 *
	 * @param accessor
	 *            the accessor to set
	 */
	public void setAccessor(IAccessor<T> accessor) {
		this.accessor = accessor;
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.model.IBaseManager#findUnique(java.lang.String,
	 *      java.lang.Object)
	 */
	public T findUnique(String field, Object value) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition(field, value);
		List<T> objects = accessor.listObjects(sf);
		if (objects.size() > 1) {
			throw new DAOException("not unique "
					+ accessor.getClassType().getName() + ": " + field + "="
					+ "[" + value + "]");
		}
		T object = doAfterObjectGot(objects.size() == 0 ? null : (T) objects
				.get(0));
		objectCounter.countGet();
		//
		return object;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#findFirst(java.lang.String,
	 *      java.lang.Object)
	 * @since liushen @ Apr 22, 2010
	 */
	@Override
	public T findFirst(String field, Object value) {
		T object = doAfterObjectGot(accessor.findFirst(field, value));
		objectCounter.countGet();
		return object;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#exists(java.lang.Object, int)
	 * @deprecated liushen@Mar 29, 2011
	 */
	@Deprecated
	@Override
	public boolean exists(Object value, int excludedId) {
		return accessor.exists(getUniqueFieldName(), value, excludedId);
	}

	/**
	 * 
	 * @deprecated liushen@Mar 29, 2011: 语义不充分，将删除
	 */
	@Deprecated
	protected String getUniqueFieldName() {
		return "name";
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#batchAddNew(T[])
	 */
	@Override
	public int batchAddNew(T[] objects) {
		int count = this.accessor.batchInsert(objects);
		objectCounter.countSave(count);
		return count;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#batchSaveOrUpdate(T[])
	 */
	@Override
	public void batchSaveOrUpdate(T[] objects) {
		this.accessor.batchUpdate(objects);
		objectCounter.countSave(objects.length);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#batchDelete(T[])
	 */
	@Override
	public void batchDelete(T[] objects) {
		this.accessor.batchDelete(objects);
		objectCounter.countDelete(objects.length);
	}

	/**
	 * 初步单元测试见
	 * {@link com.trs.dev4.jdk16.model.example.FooManagerTest#testListByIn()} ,
	 * 尚需补充其他场景!
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#listObjects(int[])
	 */
	@Override
	public List<T> listObjects(int[] idArray) {
		if (idArray == null || idArray.length == 0) {
			return Collections.emptyList();
		}
		SearchFilter searchFilter = SearchFilter.getNoPagedFilter();
		searchFilter.addInCondition("id", idArray);
		List<T> objects = doAfterObjectGot(accessor.listObjects(searchFilter));
		objectCounter.countSearch(objects.size(), 0);
		return objects;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#batchDelete(com.trs.dev4.jdk16.dao.HQLBuilder)
	 */
	@Override
	public void batchDelete(HQLBuilder builder) {
		int count = this.accessor.batchDelete(builder);
		objectCounter.countDelete(count);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#total()
	 */
	@Override
	public int total() {
		return accessor.total();
	}

	/**
	 * 获取符合条件的总记录数.
	 * 
	 * @see IAccessor#total(SearchFilter)
	 * @creator liushen @ Apr 30, 2009
	 */
	public int total(SearchFilter sf) {
		return accessor.total(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#listLatest(int)
	 */
	@Override
	public List<T> listLatest(int amount) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.setMaxResults(amount);
		sf.setOrderBy("id desc");
		return doAfterObjectGot(accessor.listObjects(sf));
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#findByUniqueField(java.lang.String)
	 * @creator fengjianhua @ 2009-7-24
	 */
	@Override
	@Deprecated
	public T findByUniqueField(String name) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition(getUniqueFieldName(), name);
		List<T> list = accessor.listObjects(sf);
		if (list.size() != 1) {
			return null;
		}
		return doAfterObjectGot(list.get(0));
	}

	/**
	 * 空实现.
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#start()
	 * @creator liushen @ Feb 17, 2010
	 */
	@Override
	public void start() {
	}

	/**
	 * 空实现.
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#start()
	 * @creator liushen @ Feb 17, 2010
	 */
	@Override
	public void restart() {

	}

	/**
	 * 空实现.
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#stop()
	 * @creator liushen @ Feb 17, 2010
	 */
	@Override
	public void stop() {
	}

	/**
	 * 空实现.
	 * 
	 * @see com.trs.dev4.jdk16.model.IConfigurable#refreshConfigs()
	 * @creator liushen @ Sep 3, 2009
	 */
	@Override
	public void refreshConfigs() {
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#getPrefix()
	 * @creator liushen @ Sep 3, 2009
	 */
	@Override
	public String getPrefix() {
		return getClass().getSimpleName();
	}

	/**
	 * 默认情况下没有配置项，不需要校验；返回空的校验结果即可.
	 * 
	 * @see com.trs.dev4.jdk16.model.IConfigurable#validateConfigs(java.util.Map)
	 * @creator liushen @ Feb 17, 2010
	 */
	@Override
	public ValidationErrors validateConfigs(Map<String, Configuration> configs) {
		return new ValidationErrors();
	}

	/**
	 *
	 * @see com.trs.dev4.jdk16.model.IBaseManager#batchDelete(int[])
	 */
	@Override
	public void batchDelete(int[] objectIds) {
		Object[] objIds = ArrayUtil.toIntegerArray(objectIds);
		HQLBuilder hqlBuilder = HQLBuilder.DELETE(accessor.getClassType());
		hqlBuilder.addInCondition("id", objIds);
		int count = accessor.batchDelete(hqlBuilder);
		objectCounter.countDelete(count);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#getOrNew(int)
	 */
	@Override
	public T getOrNew(int entityId) {
		if (entityId <= 0) {
			try {
				return accessor.getClassType().newInstance();
			} catch (InstantiationException e) {
				LOG.error(e.getMessage());
			} catch (IllegalAccessException e) {
				LOG.error(e.getMessage());
			}
		}
		T object = doAfterObjectGot(this.accessor.getObject(entityId));
		objectCounter.countGet();
		return object;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#saveOrUpdate(com.trs.dev4.jdk16.model.IEntity)
	 */
	@Override
	public void saveOrUpdate(T entity) {
		ValidationErrors errors = this.validate(entity);
		if (errors.hasErrors()) {
			ValidateAssertionException ex = new ValidateAssertionException(
					"Object(" + entity + ") validation failed : "
							+ errors.toString());
			ex.setValiationErrors(errors);
			throw ex;
		}
		//
		if ( entity.getId() == 0 ){
			if (entity instanceof BaseEntity) {
				BaseEntity bo = (BaseEntity) entity;
				bo.setCreatedTime(System.currentTimeMillis());
				bo.setLastModifiedTime(System.currentTimeMillis());
			}
			accessor.insert(entity);
		}else{
			// liushen@Mar 10, 2011: 某些时候不希望更新lastModifiedTime
			accessor.update(entity);
		}
		objectCounter.countSave();
	}


	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#findFirst(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public T findFirst(SearchFilter sf) {
		if (sf == null) {
			sf = SearchFilter.getDefault();
		}
		PagedList<T> entities = this.pagedObjects(sf);
		T object = doAfterObjectGot((entities.getPageItems().size() > 0) ? entities
				.get(0) : null);
		objectCounter.countGet();
		return object;
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#findFirst(com.trs.dev4.jdk16.dao.SearchFilter)
	 * @since fangxiang @ Nov 13, 2010
	 */
	@Override
	public T findUnique(SearchFilter sf) {
		if (sf == null) {
			sf = SearchFilter.getDefault();
		}
		PagedList<T> entities = this.pagedObjects(sf);
		if (entities.getPageItems().size() > 1) {
			throw new DAOException("not unique "
					+ accessor.getClassType().getName() + ",sf: " + sf);
		}
		T object = doAfterObjectGot((entities.getPageItems().size() > 0) ? entities
				.get(0) : null);
		objectCounter.countGet();
		return object;
	}

	/**
	 * 
	 * @param entities
	 * @return
	 * @since fangxiang @ Nov 28, 2010
	 */
	protected final List<T> doAfterObjectGot(List<T> entities) {
		if (entities == null) {
			return entities;
		}
		for (T entity : entities) {
			doAfterObjectGot(entity);
		}
		return entities;
	}

	/**
	 * 
	 * @param entities
	 * @return
	 * @since fangxiang @ Nov 28, 2010
	 */
	protected final PagedList<T> doAfterObjectGot(PagedList<T> entities) {
		if (entities == null) {
			return entities;
		}
		for (T entity : entities.getPageItems()) {
			doAfterObjectGot(entity);
		}
		return entities;
	}

	/**
	 * 
	 * @param entity
	 * @return
	 * @since fangxiang @ Nov 28, 2010
	 */
	protected final T doAfterObjectGot(T entity) {
		if (entity != null) {
			this.afterObjectGot(entity);
		}
		return entity;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#truncate()
	 * @since fangxiang @ Nov 16, 2010
	 */
	@Override
	public void truncate() {
		accessor.truncate();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IBaseManager#exists(java.lang.Object, int)
	 */
	@Override
	public boolean exists(String fieldName, Object value, int excludedId) {
		return accessor.exists(fieldName, value, excludedId);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public String getModuleName() {
		return this.getClass().getSimpleName();
	}

	/**
	 * 对象获取后的后置处理
	 * 
	 * @param object
	 */
	protected void afterObjectGot(T object) {

	}

	/**
	 * 
	 * @param searchFilter
	 * @return
	 */
	public PagedList<Integer> pagedObjectIds(SearchFilter searchFilter) {
		return accessor.pagedObjectIds(searchFilter);
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.model.IBaseManager#getObjectLoadCounter()
	 */
	public ObjectCounter getObjectCounter() {
		return objectCounter;
	}
}
