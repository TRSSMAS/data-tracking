/*
 * Created: TRS@Jan 30, 2012 2:17:05 PM
 */
package com.trs.dev4.jdk16.model;

import java.util.List;

import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.impl.ConfigurationBeanPostProcessor;

/**
 * 职责:动态获取配置{@link Configuration}的选项 <br>
 * 由{@link IConfigurationManager}实现类负责管理和维护，通过
 * {@link IConfigurationManager#readOptions}方法来获取ConfigurationOption的列表.<br>
 * 由{@link ConfigurationBeanPostProcessor}实现Spring环境下的自动注册.<br>
 * 
 * @since 2012.01.30
 */
public interface IConfigurationOptionReader {

	/**
	 * 获取配置选项读取器的名字
	 * 
	 * @return 配置选项读取器的名字
	 * @since TRS @ Jan 30, 2012
	 */
	String getConfigurationOptionReaderName();
	
	/**
	 * 获取配置的选项列表，支持输入的动态查询和匹配检索
	 * 
	 * @param sf
	 *            查询条件，支持动态
	 * @return 符合条件的配置选项列表
	 * @since TRS @ Jan 30, 2012
	 */
	List<ConfigurationOption> read(SearchFilter sf);
}
