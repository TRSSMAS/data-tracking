/*
 * Created: fangxiang@Nov 22, 2010 6:49:57 PM
 */
package com.trs.dev4.jdk16.model.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.model.IModuleLifecycle;

/**
 *
 */
public class ModuleLifecycleContainer implements IModuleLifecycle, ApplicationContextAware {

	/**
	 *
	 */
	private final static Logger logger = Logger
			.getLogger(ModuleLifecycleContainer.class);
	protected ApplicationContext applicationContext;

	@SuppressWarnings("unchecked")
	protected List<IModuleLifecycle> getModuleLifecycles() {
		return (List<IModuleLifecycle>) applicationContext.getBean("moduleLifecycles");
	}

	/**
	 * 
	 * 
	 * @since fangxiang @ Nov 22, 2010
	 */
	public void start(){
		for (IModuleLifecycle moduleLifecycle : getModuleLifecycles()) {
			try{
				moduleLifecycle.start();
			}catch(Exception ex){
				logger.debug(ex.getMessage(), ex);
			}
		}
	}

	/**
	 * 
	 * 
	 * @since fangxiang @ Nov 22, 2010
	 */
	public void stop() {
		for (IModuleLifecycle moduleLifecycle : getModuleLifecycles()) {
			try {
				moduleLifecycle.stop();
			} catch (Exception ex) {
				logger.debug(ex.getMessage(), ex);
			}
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since TRS @ Feb 5, 2012
	 */
	@Override
	public String getModuleName() {
		return this.getClass().getSimpleName();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since TRS @ Feb 5, 2012
	 */
	@Override
	public void restart() {
		for (IModuleLifecycle moduleLifecycle : getModuleLifecycles()) {
			try {
				moduleLifecycle.restart();
			} catch (Exception ex) {
				logger.debug(ex.getMessage(), ex);
			}
		}

	}

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * @since TRS @ Feb 11, 2012
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
}
