/*
 * Created: TRS@Feb 11, 2012 5:36:27 PM
 */
package com.trs.dev4.jdk16.model.impl;

import java.util.Locale;

import com.trs.dev4.jdk16.dao.SearchFilter;
import com.trs.dev4.jdk16.model.BaseManager;
import com.trs.dev4.jdk16.model.I18NMessage;
import com.trs.dev4.jdk16.model.II18NMessageManager;

/**
 * 职责: 实现{@link I18NMessageManager}接口<br>
 * 
 */
public class I18NMessageManagerImpl extends BaseManager<I18NMessage> implements II18NMessageManager {

	/**
	 * @see com.trs.dev4.jdk16.model.II18NMessageManager#find(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 * @since TRS @ Feb 11, 2012
	 */
	@Override
	public I18NMessage find(String messageKey, String language, String country) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("messageKey", messageKey);
		sf.addEqCondition("language", language);
		sf.addEqCondition("country", country);
		return super.findFirst(sf);
	}

	/**
	 * @see com.trs.dev4.jdk16.model.II18NMessageManager#find(java.lang.String,
	 *      java.util.Locale)
	 * @since TRS @ Feb 11, 2012
	 */
	@Override
	public I18NMessage find(String messageKey, Locale locale) {
		return this.find(messageKey, locale.getLanguage(), locale.getCountry());
	}

	/**
	 * @see com.trs.dev4.jdk16.model.II18NMessageManager#list(java.lang.String)
	 * @since TRS @ Feb 11, 2012
	 */
	@Override
	public I18NMessage[] list(String messageKey) {
		SearchFilter sf = SearchFilter.getDefault();
		sf.addEqCondition("messageKey", messageKey);
		return super.listAllObjects(sf).toArray(new I18NMessage[0]);
	}

}
