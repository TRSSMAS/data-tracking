/*
 * Created: fangxiang@Nov 22, 2010 8:50:47 AM
 */
package com.trs.dev4.jdk16.model.impl;

import java.lang.reflect.Field;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.util.ReflectionUtils;

import com.trs.dev4.jdk16.model.AnnotationProperty;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 通过注解将配置参数注入到类里面 <br>
 *
 */
public class AnnotationPropertyPlaceholderConfigurer extends
		PropertyPlaceholderConfigurer implements InitializingBean,
		BeanPostProcessor {
	/**
	 *
	 */
	private java.util.Properties properties;

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessAfterInitialization(java.lang.Object,
	 *      java.lang.String)
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		if (!bean.getClass().getName().startsWith("com.trs")) {
			return bean;
		}
		Field[] fields = bean.getClass().getDeclaredFields();
		for (Field field : fields) {
			String fieldTypeName = field.getType().getName();
			AnnotationProperty property = field
					.getAnnotation(AnnotationProperty.class);
			if (property == null) {
				logger.debug("Object(" + bean + ")'s field(" + field.getName()
						+ ") annotationProperty is null.");
				continue;
			}
			Object propertyValue = properties.getProperty(property.name(),
					property.defValue());
			if (propertyValue == null) {
				logger.debug("Object(" + bean + ")'s field(" + field.getName()
						+ ") annotationProperty (" + property.name()
						+ ")'s propertyValue is null.");
				continue;
			}
			logger.debug("Object(" + bean + ")'s field(" + field.getName()
					+ ") annotationProperty(" + property.name()
					+ ")'s propertyValue:"
					+ propertyValue);
			field.setAccessible(true);
			if ("java.lang.Integer".equalsIgnoreCase(fieldTypeName)
					|| "int".equalsIgnoreCase(fieldTypeName)) {
				ReflectionUtils.setField(field, bean,
						StringHelper.parseInt(propertyValue.toString()));
			} else if ("java.lang.Long".equalsIgnoreCase(fieldTypeName)
					|| "long".equalsIgnoreCase(fieldTypeName)) {
				ReflectionUtils.setField(field, bean,
						StringHelper.parseInt(propertyValue.toString()));
			} else if ("java.lang.String".equalsIgnoreCase(fieldTypeName)) {
				ReflectionUtils.setField(field, bean, propertyValue.toString());
			} else {
				logger.error("Unsupported field(" + field + ") type("
						+ field.getName() + ") with Object(" + beanName
						+ ") by annotationProperty(" + property.name() + ","
						+ property.defValue() + ").");
			}
		}
		return bean;
	}

	/**
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		properties = mergeProperties();
	}

	/**
	 * @see org.springframework.beans.factory.config.BeanPostProcessor#postProcessBeforeInitialization(java.lang.Object,
	 *      java.lang.String)
	 * @since fangxiang @ Nov 22, 2010
	 */
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		return bean;
	}

}
