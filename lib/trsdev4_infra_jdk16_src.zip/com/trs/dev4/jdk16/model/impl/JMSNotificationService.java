/*
 * Created: TRS@Feb 13, 2012 9:46:08 PM
 */
package com.trs.dev4.jdk16.model.impl;

import com.trs.dev4.jdk16.model.INotification;
import com.trs.dev4.jdk16.model.INotificationService;

/**
 * 职责: 通过JMS服务实现通知<br>
 * 
 */
public class JMSNotificationService implements INotificationService {

	/**
	 * @see com.trs.dev4.jdk16.model.INotificationService#notify(com.trs.dev4.jdk16.model.INotification)
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	public void notify(INotification notification) {
		// TODO TRS@Feb 13, 2012 9:46:08 PM: Auto-generated method stub

	}

}
