/*
 *
 * liushen
 * Created on 2006-3-14 15:42:23
 */
package com.trs.dev4.jdk16.exception;

/**
 * TODO <BR>
 * 
 * @author liushen
 */
public class MailException extends RootException {

    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public MailException(String msg) {
        super(msg);
    }

    public MailException(String msg, Throwable cause) {
        super(msg, cause);
    }

}
