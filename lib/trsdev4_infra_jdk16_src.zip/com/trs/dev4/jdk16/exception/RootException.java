/**
 * Created: liushen@Dec 2, 2009 10:45:35 PM
 */
package com.trs.dev4.jdk16.exception;

/**
 * 异常基类. <BR>
 * 
 */
@SuppressWarnings("serial")
public abstract class RootException extends RuntimeException {

	/**
	 * 构造指定信息的异常.
	 * 
	 * @param msg
	 *            异常信息
	 */
	public RootException(String msg) {
		super(msg);
	}

	/**
	 * 指定信息和引发异常, 以形成异常链.
	 * 
	 * @param msg
	 *            异常信息
	 * @param cause
	 *            引发此异常的异常.
	 */
	public RootException(String msg, Throwable cause) {
		super(msg, cause);
	}

	/**
	 * 指定引发异常, 以形成异常链.
	 * 
	 * @param cause
	 *            引发此异常的异常.
	 */
	public RootException(Throwable cause) {
		super((cause == null) ? "cause is null!" : cause.toString(), cause);
	}

}
