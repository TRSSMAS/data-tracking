/*
 * Created: TRS@Feb 3, 2012 1:26:42 PM
 */
package com.trs.dev4.jdk16.thread;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.utils.DateUtil;

/**
 * 职责: 统一控制线程<br>
 * 
 */
public class DaemonThreadFactory {
	/**
	 * 
	 */
	private final static Logger LOG = Logger.getLogger(DaemonThreadFactory.class);
	/**
	 * 
	 */
	Map<String, DaemonThreadControllor> threadControllors = new ConcurrentHashMap<String, DaemonThreadControllor>();

	/**
	 * 
	 */
	private static DaemonThreadFactory daemonThreadFactory = null;

	/**
	 * 
	 * @return
	 * @since TRS @ Feb 3, 2012
	 */
	public static DaemonThreadFactory getInstance() {
		if ( daemonThreadFactory == null ) {
			daemonThreadFactory = new DaemonThreadFactory();
		}
		return daemonThreadFactory;
	}


	/**
	 * 默认构造函数，不允许单独创建
	 */
	private DaemonThreadFactory() {

	}

	/**
	 * 构造线程
	 * 
	 * @param name
	 *            线程名字
	 * @param duration
	 *            执行间隔，单位秒
	 * @param delay
	 *            第一次执行延迟，单位秒
	 * @param workload
	 *            执行单元
	 * @since TRS @ Feb 3, 2012
	 */
	public void buildThread(String name, int duration, long delay, IThreadWorkload workload) {
		DaemonThreadControllor controllor = new DaemonThreadControllor();
		controllor.build(name, duration, delay, workload);
		threadControllors.put(controllor.getThreadName(), controllor);
	}

	/**
	 * 构造每天执行一次的线程并执行
	 * 
	 * @since TRS @ Feb 3, 2012
	 */
	public void startDailyThread(String name, IThreadWorkload workload) {
		startThread(name, (int) DateUtil.ONE_DAY_SECONDS, DateUtil.getTodayRemainAsSecond(), workload);
	}

	/**
	 * 构造每小时执行一次的线程
	 * 
	 * @since TRS @ Feb 3, 2012
	 */
	public void startHourlyThread(String name, IThreadWorkload workload) {
		startThread(name, (int) DateUtil.ONE_DAY_SECONDS, DateUtil.getTodayRemainAsSecond(), workload);
	}

	/**
	 * 构造每天执行一次的线程
	 * 
	 * @since TRS @ Feb 3, 2012
	 */
	public void buildDailyThread(String name, IThreadWorkload workload) {
		buildThread(name, (int) DateUtil.ONE_DAY_SECONDS, DateUtil.getTodayRemainAsSecond(), workload);
	}

	/**
	 * 构造每小时执行一次的线程
	 * 
	 * @since TRS @ Feb 3, 2012
	 */
	public void buildHourlyThread(String name, IThreadWorkload workload) {
		buildThread(name, (int) DateUtil.ONE_DAY_SECONDS, DateUtil.getTodayRemainAsSecond(), workload);
	}

	/**
	 * 构造并启动线程
	 * 
	 * @param name
	 *            线程名字
	 * @param duration
	 *            执行间隔，单位秒
	 * @param delay
	 *            第一次延迟，单位秒
	 * @param workload
	 *            执行负荷
	 * @since TRS @ Feb 3, 2012
	 */
	public void startThread(String name, int duration, long delay, IThreadWorkload workload) {
		buildThread(name, duration, delay, workload);
		this.startThread(name);
	}

	/**
	 * 启动线程
	 * 
	 * @param name
	 *            线程名字
	 * @since TRS @ Feb 3, 2012
	 */
	public void startThread(String name) {
		DaemonThreadControllor controllor = threadControllors.get(name);
		if (controllor != null) {
			controllor.start();
			LOG.info("Thread(" + controllor.getThreadName() + ") started with bean(" + controllor + ")");
		} else {
			LOG.error("Thread(" + name + ") started with bean(" + controllor + ")", new NullPointerException());
		}
	}

	/**
	 * 创建并立即启动线程
	 * 
	 * @param name
	 *            线程名
	 * @param duration
	 *            线程循环间隔，单位秒
	 * @param workload
	 *            负载
	 */
	public void startThread(String name, int duration, IThreadWorkload workload) {
		startThread(name, duration, 0, workload);
	}

	/**
	 * 创建线程
	 * 
	 * @param name
	 *            线程名
	 * @param duration
	 *            线程循环间隔
	 * @param runnable
	 *            负载
	 */
	public void buildThread(String name, int duration, long delay, Runnable runnable) {
		DaemonThreadControllor controllor = new DaemonThreadControllor();
		controllor.build(name, duration, delay, runnable);
		threadControllors.put(controllor.getThreadName(), controllor);
	}

	/**
	 * 创建并启动线程
	 * 
	 * @param name
	 *            线程名
	 * @param duration
	 *            线程循环间隔
	 * @param runnable
	 *            负载
	 */
	public void startThread(String name, int duration, long delay, Runnable runnable) {
		buildThread(name, duration, delay, runnable);
		startThread(name);
	}

	/**
	 * 创建并启动线程，循环间隔由线程自己控制
	 * 
	 * @param name
	 *            线程名
	 * @param runnable
	 *            负载
	 */
	public void startThread(String name, Runnable runnable) {
		buildThread(name, 200, 0, runnable);
		startThread(name);
	}

	/**
	 * 停止线程
	 * 
	 * @param name
	 *            线程名字
	 * @since TRS @ Feb 3, 2012
	 */
	public void stopThread(String name) {
		DaemonThreadControllor controllor = threadControllors.get(name);
		if (controllor != null) {
			controllor.stop();
		}
	}

	/**
	 * 启动所有线程
	 * 
	 * @since TRS @ Feb 3, 2012
	 */
	public void startAll() {
		for (String name : threadControllors.keySet()) {
			startThread(name);
		}
	}

	/**
	 * 停止所有线程
	 * 
	 * @since TRS @ Feb 3, 2012
	 */
	public void stopAll() {
		for (String name : threadControllors.keySet()) {
			stopThread(name);
		}
	}
}
