/*
 * Created: fangxiang@Jan 8, 2011 10:01:13 AM
 */
package com.trs.dev4.jdk16.thread;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.tunning.PerformanceTimer;
import com.trs.dev4.jdk16.utils.DateUtil;

/**
 * 后台线程
 */
public class DaemonThreadControllor {
	/**
	 * 
	 */
	private final static Logger logger = Logger
			.getLogger(DaemonThreadControllor.class);

	private static final long DEF_MAX_WAIT_MS = 5000;
	/**
	 * 
	 */
	private Thread backgroundThread;
	/**
	 * 
	 */
	private int duration;
	/**
	 * 
	 */
	private long delay;
	/**
	 * 
	 */
	private boolean running;
	/**
	 * 
	 */
	private int executedCount;
	/**
	 * 
	 */
	private String threadName;

	/**
	 * 
	 */
	DaemonThreadControllor() {

	}
	/**
	 * 启动线程
	 * 
	 * @param name
	 *            线程名
	 * @param duration
	 *            线程循环间隔
	 * @param workload
	 *            负载
	 */
	void start(String name, int duration, IThreadWorkload workload) {
		start(name, duration, 0, workload);
	}

	/**
	 * 启动线程
	 * 
	 * @param name
	 *            线程名
	 * @param delay
	 *            延迟时间
	 * @param workload
	 *            负载
	 */
	void startDaily(String name, IThreadWorkload workload) {
		start(name, (int) DateUtil.ONE_DAY_SECONDS,
				DateUtil.getTodayRemainAsSecond(), workload);
	}

	/**
	 * 启动线程
	 * 
	 * @param name
	 *            线程名
	 * @param delay
	 *            延迟时间
	 * @param workload
	 *            负载
	 */
	void startHourly(String name, IThreadWorkload workload) {
		start(name, (int) DateUtil.ONE_HOUR_SCONDS,
				DateUtil.getCurrentHourRemainAsSecond(), workload);
	}

	/**
	 * 
	 * @param name
	 *            线程名称
	 * @param duration
	 *            线程循环间隔
	 * @param delay
	 *            线程启动延时
	 * @param workload
	 * @since fangxiang @ Jan 8, 2011
	 */
	public void start(String name, int duration, long delay,
			IThreadWorkload workload) {
		build(name, duration, delay, workload);
		start();
	}

	/**
	 * 
	 * @param name
	 * @param duration
	 * @param delay
	 * @param workload
	 * @since TRS @ Feb 3, 2012
	 */
	public void build(String name, int duration, long delay, IThreadWorkload workload) {
		this.duration = duration;
		this.delay = delay;
		running = true;
		backgroundThread = new Thread(new BackgroudDaemonThread(workload));
		backgroundThread.setDaemon(true);
		this.threadName = name;
		backgroundThread.setName(threadName);
		if (logger.isDebugEnabled()) {
			logger.debug("BackgroudDaemonThread(" + backgroundThread.getName() + ") builded with IThreadWorkload =" + workload);
		}
	}

	/**
	 * 
	 * 
	 * @since TRS @ Feb 3, 2012
	 */
	public void start() {
		if (backgroundThread != null) {
			backgroundThread.start();
			if (logger.isDebugEnabled()) {
				logger.debug("BackgroudDaemonThread(" + backgroundThread.getName() + ") started with [" + backgroundThread + "]");
			}
		}
	}

	/**
	 * 
	 * @param name
	 * @param duration
	 * @param delay
	 * @param workload
	 * @since TRS @ Feb 3, 2012
	 */
	public void build(String name, int duration, long delay, Runnable runnable) {
		this.duration = duration;
		this.delay = delay;
		running = true;
		if (runnable instanceof Thread) {
			backgroundThread = (Thread) runnable;
			backgroundThread.setDaemon(true);
		} else {
			backgroundThread = new Thread(runnable);
		}
		this.threadName = name;
		backgroundThread.setName(threadName);
	}

	/**
	 * 停止线程
	 * 
	 */
	public void stop(){
		stop(DEF_MAX_WAIT_MS);
	}

	/**
	 * 最多等多长时间停掉线程.
	 * 
	 * @param maxWaitMillis
	 *            最多等多长时间, 毫秒.
	 * @since liushen @ Jan 18, 2011
	 */
	public void stop(long maxWaitMillis) {
		running = false;
		try {
			backgroundThread.join(maxWaitMillis);
		} catch (InterruptedException e) {
		}
		backgroundThread.interrupt();
	}


	/**
	 * 
	 *
	 */
	class BackgroudDaemonThread implements Runnable {

		private IThreadWorkload workload;

		/**
		 * 
		 * @param workload
		 */
		public BackgroudDaemonThread(IThreadWorkload workload) {
			this.workload = workload;
		}

		/**
		 * 
		 * 
		 * @since fangxiang @ Jan 8, 2011
		 */
		void execute() {
			try {
				if (workload != null) {
					this.workload.onExecute();
				}
			} catch (Exception ex) {
				logger.error(ex.getMessage(), ex);
			}
		}
		/**
		 * @see java.lang.Runnable#run()
		 */
		@Override
		public void run() {
			// 延时delay秒
			try {
				Thread.sleep(delay * 1000L);
			} catch (InterruptedException e1) {
			}
			// 循环执行
			while (running) {
				executedCount++;
				PerformanceTimer pTimer = new PerformanceTimer("workload");
				this.execute();
				pTimer.stop();
				logger.debug("Thread (" + threadName
						+ ") with IThreadWorkload(" + workload + ") elapsed ("
						+ pTimer.getDuration() + ") ms for (" + executedCount
						+ ") execution. ");
				// 间隔duration秒
				try {
					Thread.sleep(duration * 1000L);
				} catch (InterruptedException e) {
				}
			}
		}

		/**
		 * @see java.lang.Object#toString()
		 * @since TRS @ Feb 3, 2012
		 */
		@Override
		public String toString() {
			return "BackgroudDaemonThread [workload=" + workload + "]";
		}

	}

	/**
	 * @return the {@link #threadName}
	 */
	public String getThreadName() {
		return threadName;
	}
}
