/*
 * Created: liushen@Mar 28, 2011 2:15:36 PM
 */
package com.trs.dev4.jdk16.log4j;

import org.apache.log4j.HTMLLayout;

/**
 * 更好地控制Log4j日志向HTML输出.<br>
 * 
 */
public class Log4JHTMLLayout extends HTMLLayout {

	/**
	 * @see org.apache.log4j.HTMLLayout#getContentType()
	 * @since liushen @ Mar 28, 2011
	 */
	@Override
	public String getContentType() {
		return "text/html;charset=utf-8";
	}

}
