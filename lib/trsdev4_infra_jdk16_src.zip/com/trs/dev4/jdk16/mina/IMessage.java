/*
 * Created: dujie@Oct 26, 2010 1:38:10 PM
 */
package com.trs.dev4.jdk16.mina;

/**
 * 职责: 消息接口<br>
 * 
 */
public interface IMessage {

}
