/*
 * Created: dujie@Oct 26, 2010 2:57:57 PM
 */
package com.trs.dev4.jdk16.mina.impl;

import java.util.Map;

import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trs.dev4.jdk16.mina.IMessage;
import com.trs.dev4.jdk16.mina.IMessageHandler;

/**
 * 职责: 消息响应会话句柄<br>
 * 
 */
public class MessageClientSessionHandler extends IoHandlerAdapter {

	/**
	 * 日志logger
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private final static Logger logger = LoggerFactory
			.getLogger(MessageClientSessionHandler.class);

	/**
	 * 将要注入的消息句柄map
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private Map<String, IMessageHandler> messageHandlers;

	/**
	 * @see com.trs.dev4.jdk16.mina.IMessageHandler#messageReceived(com.trs.dev4.jdk16.mina.IMessage)
	 * @since dujie @ Oct 26, 2010
	 */
	@Override
	public void messageReceived(IoSession session, Object message) {
		IMessage rm = (IMessage) message;

		Map<String, IMessageHandler> messageHandlers = this.messageHandlers;

		IMessageHandler messageHandler = messageHandlers.get(rm.getClass()
				.getName());

		messageHandler.messageReceived(rm);

	}

	/**
	 * @see org.apache.mina.core.service.IoHandlerAdapter#exceptionCaught(org.apache.mina.core.session.IoSession,
	 *      java.lang.Throwable)
	 * @since dujie @ Oct 26, 2010
	 */
	@Override
	public void exceptionCaught(IoSession session, Throwable cause) {
		logger.error("ClientSessionHandler exception:" + cause.getMessage(),
				cause);
		session.close(true);

	}

	/**
	 * @return the {@link #messageHandlers}
	 */
	public Map<String, IMessageHandler> getMessageHandlers() {
		return messageHandlers;
	}

	/**
	 * @param messageHandlers
	 *            the {@link #messageHandlers} to set
	 */
	public void setMessageHandlers(Map<String, IMessageHandler> messageHandlers) {
		this.messageHandlers = messageHandlers;
	}
}
