/*
 * Created: dujie@Oct 26, 2010 3:35:00 PM
 */
package com.trs.dev4.jdk16.mina;

import java.net.InetSocketAddress;

import org.apache.mina.core.RuntimeIoException;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.serialization.ObjectSerializationCodecFactory;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.trs.dev4.jdk16.mina.impl.MessageClientSessionHandler;

/**
 * 职责: 消息客户端<br>
 * 
 */
public class MessageClient extends Thread {

	/**
	 * 日志logger
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private static final Logger logger = LoggerFactory
			.getLogger(MessageClient.class);

	/**
	 * 要注入的messageClientSessionHandler
	 * 
	 * @since dujie @ Nov 1, 2010
	 */
	private MessageClientSessionHandler messageClientSessionHandler;
	/**
	 * 客户端会话
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private IoSession session;

	/**
	 * NIO套接字连接
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private NioSocketConnector connector = new NioSocketConnector();;

	/**
	 * 主机名
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private String hostName;

	/**
	 * 端口
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private int port;

	/**
	 * 超时时间
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private static final long TIME_OUT = 300 * 1000L;

	/**
	 * 判断是否在运行
	 * 
	 * @since dujie @ Oct 29, 2010
	 */
	private boolean running = true;

	/**
	 * 尝试连接的次数
	 * 
	 * @since dujie @ Oct 30, 2010
	 */
	private int tryTimes = 10;

	/**
	 * @see java.lang.Thread#start()
	 * @since dujie @ Oct 29, 2010
	 */
	@Override
	public void start() {
		connect();
	}

	/**
	 * @see java.lang.Thread#run()
	 * @since dujie @ Oct 29, 2010
	 */
	@Override
	public void run() {
		while (this.running) {
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				logger.error(" Client sleep exception: " + e.getMessage(), e);
			}
		}

	}

	/**
	 * @param hostName
	 *            主机名
	 * @param port
	 *            端口
	 * @param timeOut
	 *            超时时间
	 * @since dujie @ Oct 26, 2010
	 */
	protected void connect() {

		// 设置超时时间
		connector.setConnectTimeoutMillis(TIME_OUT);
		// 设置过滤器
		// 1、ObjectSerializationCodecFactory一般发送/接收的是对象等形象,以对象形式读取
		// 2、TextLineCodecFactory设置这个过滤器一行一行(/r/n)的发送/读取数据
		connector.getFilterChain().addLast("codec",
				new ProtocolCodecFilter(new ObjectSerializationCodecFactory()));
		// 设置日志过滤器，对IoSession 对象上发生的各种事件进行日志记录
		connector.getFilterChain().addLast("logger", new LoggingFilter());
		// 设定服务器端消息处理器
		connector.setHandler(this.messageClientSessionHandler);

		for (int i = 0; i < this.tryTimes; i++) {
			try {
				ConnectFuture future = connector.connect(new InetSocketAddress(
						this.hostName, this.port));
				future.awaitUninterruptibly();
				session = future.getSession();
				break;
			} catch (RuntimeIoException e) {
				logger.error("Failed to connect,hostName: " + this.hostName
						+ ",port: " + this.port + "-" + e.getMessage(), e);
			}
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
				logger.error("Thread.sleep(5000) failed: " + e1.getMessage(),
						e1);
			}

		}

	}

	/**
	 * @param message
	 *            要发送的消息
	 * @since dujie @ Oct 27, 2010
	 */
	public void send(IMessage message) {
		if (session != null) {
			if (session.isConnected()) {

				session.write(message);
			}
		}
	}

	/**
	 * 关闭会话 和 连接
	 * 
	 * @since dujie @ Oct 27, 2010
	 */
	public void close() {
		if (session != null) {
			if (session.isConnected()) {
				session.close(true);
			}
			connector.dispose();
		}
	}

	/**
	 * @param hostName
	 *            the {@link #hostName} to set
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**
	 * @param port
	 *            the {@link #port} to set
	 */
	public void setPort(int port) {
		this.port = port;
	}

	/**
	 * @param timeOut
	 *            the {@link #timeOut} to set
	 */

	public void shutdown() {
		this.running = false;
		this.close();
	}

	/**
	 * @param tryTimes
	 *            the {@link #tryTimes} to set
	 */
	public void setTryTimes(int tryTimes) {
		this.tryTimes = tryTimes;
	}

	/**
	 * @return the {@link #messageClientSessionHandler}
	 */
	public MessageClientSessionHandler getMessageClientSessionHandler() {
		return messageClientSessionHandler;
	}

	/**
	 * @param messageClientSessionHandler
	 *            the {@link #messageClientSessionHandler} to set
	 */
	public void setMessageClientSessionHandler(
			MessageClientSessionHandler messageClientSessionHandler) {
		this.messageClientSessionHandler = messageClientSessionHandler;
	}
}
