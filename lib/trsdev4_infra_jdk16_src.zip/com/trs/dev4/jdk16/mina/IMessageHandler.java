/*
 * Created: Administrator@Oct 26, 2010 1:57:21 PM
 */
package com.trs.dev4.jdk16.mina;

/**
 * 职责: 消息句柄接口<br>
 * 
 */
public interface IMessageHandler {

	/**
	 * @param message
	 *            消息对象
	 * @return ResultMessage 对象
	 * @since dujie @ Oct 26, 2010
	 */
	IMessage messageReceived(IMessage message);

}
