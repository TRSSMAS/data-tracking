/*
 * Created on Oct 31, 2006 6:49:13 PM, by Chen Liang
 */
package com.trs.dev4.jdk16.session;


/**
 *
 *
 */
public interface ISessionUser
{
	/**
	 * 用户编号
	 * 
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public int getId();

	/**
	 * 用户名
	 * 
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public String getUserName();

	/**
	 * 昵称
	 * 
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public String getNickName();

	/**
	 * 登录时间
	 * 
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public long getLoginedTime();

	/**
	 * 登录IP
	 * 
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public String getLoginedIP();

	/**
	 * 是否可以登录管理台
	 * 
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public boolean canLoginConsole();

	/**
	 * 是否为匿名的用户
	 * 
	 * @return
	 * @since TRS @ Feb 17, 2011
	 */
	public boolean isAnonymous();
}
