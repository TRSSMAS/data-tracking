/*
 * Created: fangxiang@Dec 6, 2010 6:13:06 PM
 */
package com.trs.dev4.jdk16.session.impl;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.trs.dev4.jdk16.servlet24.BaseFilter;
import com.trs.dev4.jdk16.session.ApplicationSessionException;
import com.trs.dev4.jdk16.session.ISessionHandler;

/**
 * 职责: <br>
 * 
 */
public class ApplicationSessionFilter extends BaseFilter {

	private final static Logger logger = Logger
			.getLogger(ApplicationSessionFilter.class);
	/**
	 *
	 */
	protected ApplicationContext applicationContext;

	/**
	 * 
	 */
	public ApplicationSessionFilter() {

	}

	/**
	 * 仅供单元测试用
	 * 
	 * @param applicationContext
	 */
	protected ApplicationSessionFilter(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
		try {
			this.initInternal(super.filterConfig);
		} catch (ServletException e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#doFilterInternal(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 * @since yu.hongqi @ 2011-11-25
	 */
	@Override
	protected void doFilterInternal(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		ISessionHandler<?> sessionHandler = (ISessionHandler<?>) applicationContext.getBean("sessionHandler");
		logger.debug("Found ISessionHandler(" + sessionHandler + ") with applicationContext(" + applicationContext + ").");
		if (sessionHandler == null) {
			filterChain.doFilter(request, response);
			return;
		}
		// 是否在忽略列表中，不生成应用会话，也不统计在会话之内
		if (sessionHandler.ignoreUrl((HttpServletRequest) request, (HttpServletResponse) response)) {
			filterChain.doFilter(request, response);
			return;
		}
		// 验证会话
		ApplicationSession as = null;
		try {
			as = sessionHandler.getApplicationSession((HttpServletRequest) request, (HttpServletResponse) response, true);
		} catch (ApplicationSessionException ex) {
			// 请求是否达到最大的会话数
			// 请求是否达到最小的刷新时间间隔
			// 请求是否属于允许的地址范围
			logger.error(ex.getMessage(), ex);
			// 重定向到指定的页面
			((HttpServletResponse) response).sendRedirect(ex.getRedirectUrl());
		}
		if (as != null) {
			sessionHandler.updateLastModified(as);
		}
		//
		filterChain.doFilter(request, response);
	}

	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#initInternal(javax.servlet.FilterConfig)
	 * @since yu.hongqi @ 2011-11-25
	 */
	@Override
	protected boolean initInternal(FilterConfig config) throws ServletException {
		if (applicationContext == null) {
			applicationContext = WebApplicationContextUtils.getWebApplicationContext(config.getServletContext());
			logger.debug("Found ApplicationContext(" + applicationContext + ").");
		}
		return applicationContext != null;
	}

	/**
	 * @see com.trs.dev4.jdk16.servlet24.BaseFilter#destroyInternal()
	 * @since yu.hongqi @ 2011-11-25
	 */
	@Override
	protected void destroyInternal() {

	}

	/**
	 * @param applicationContext
	 *            the {@link #applicationContext} to set
	 */
	protected void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

}
