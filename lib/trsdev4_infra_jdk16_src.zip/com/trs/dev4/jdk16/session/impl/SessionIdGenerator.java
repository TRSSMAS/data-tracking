package com.trs.dev4.jdk16.session.impl;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

import org.apache.log4j.Logger;

public class SessionIdGenerator {
	private static final Logger LOG = Logger
			.getLogger(SessionIdGenerator.class);

	/**
	 * SessionId的长度，默认是16位
	 */
	private int sessionIdLength = 16;

	/**
	 * 生成为唯一Id时用，Random的对象，生成唯一ID时使用
	 */
	protected Random random = null;

	/**
	 * 生成为唯一Id时用，用于初始化random number generator
	 */
	protected String entropy = null;

	/**
	 * 生成为唯一Id时用，random number generator使用的类
	 */
	protected String randomClass = "java.security.SecureRandom";

	/**
	 * 生成为唯一Id时用，消息摘要
	 */
	protected MessageDigest digest = null;

	/**
	 * 生成为唯一Id时用，默认的生成消息摘要算法
	 */
	protected String algorithm = DEFAULT_ALGORITHM;

	/**
	 * 生成为唯一Id时用，设置消息摘要算法为MD
	 */
	protected static final String DEFAULT_ALGORITHM = "MD5";

	/**
	 * 节点标识.
	 */
	private String nodeKey;

	/**
	 *
	 */
	public SessionIdGenerator() {
	}

	/**
	 * 
	 * @param nodeKey
	 */
	public SessionIdGenerator(String nodeKey) {
		if (nodeKey != null && nodeKey.trim().length() > 0) {
			this.nodeKey = nodeKey;
		}
	}

	// -------------------------------------- 生成唯一ID相关的方法

	/**
	 * 生成唯一ID. 线程安全.
	 * 
	 * @return String类型的16进制的SessionId
	 */
	public String generateSessionId() {
		byte random[] = new byte[this.sessionIdLength];
		StringBuffer result = new StringBuffer();

		int resultLenBytes = 0;

		synchronized (this) {
			while (resultLenBytes < this.sessionIdLength) {
				getRandomBytes(random);
				random = getDigest().digest(random);
				for (int j = 0; j < random.length
						&& resultLenBytes < this.sessionIdLength; j++) {
					byte b1 = (byte) ((random[j] & 0xf0) >> 4);
					byte b2 = (byte) (random[j] & 0x0f);
					if (b1 < 10) {
						result.append((char) ('0' + b1));
					} else {
						result.append((char) ('A' + (b1 - 10)));
					}

					if (b2 < 10) {
						result.append((char) ('0' + b2));
					} else {
						result.append((char) ('A' + (b2 - 10)));
					}
					resultLenBytes++;
				}
			}
		}
		// ls@08-0222 追加节点标识
		if (nodeKey != null) {
			result.append(nodeKey);
		}
		return result.toString();
	}

	protected void getRandomBytes(byte bytes[]) {
		getRandom();
		getRandom().nextBytes(bytes);
	}

	/**
	 * 获得java.util.Random的对象，生成唯一ID时用.
	 */
	private synchronized Random getRandom() {
		if (this.random == null) {
			synchronized (this) {
				if (this.random == null) {
					// Calculate the new random number generator seed
					long seed = System.currentTimeMillis();
					long t1 = seed;
					char entropy[] = getEntropy().toCharArray();
					for (int i = 0; i < entropy.length; i++) {
						long update = ((byte) entropy[i]) << ((i % 8) * 8);
						seed ^= update;
					}
					try {
						// Construct and seed a new random number generator
						Class<?> clazz = Class.forName(randomClass);
						this.random = (Random) clazz.newInstance();
						this.random.setSeed(seed);
					} catch (Exception e) {
						LOG.error("SSOSessionManager.random: " + randomClass, e);
						this.random = new java.util.Random();
						this.random.setSeed(seed);
					}
					long t2 = System.currentTimeMillis();
					if ((t2 - t1) > 100) {
						LOG.debug("SSOSessionIdGen.seeding time high! " + randomClass
								+ " " + (t2 - t1));
					}
				}
			}
		}

		return (this.random);

	}

	synchronized MessageDigest getDigest() {

		if (this.digest == null) {
			long t1 = System.currentTimeMillis();
			try {
				this.digest = MessageDigest.getInstance(algorithm);
			} catch (NoSuchAlgorithmException e) {
				LOG.error("SSOSessionManager.digest:  " + "   " + algorithm
						+ "   " + e);
				try {
					this.digest = MessageDigest.getInstance(DEFAULT_ALGORITHM);
				} catch (NoSuchAlgorithmException f) {
					LOG.error("SSOSessionManager.digest:" + "   "
							+ DEFAULT_ALGORITHM + "   " + e);
					this.digest = null;
				}
			}
			long t2 = System.currentTimeMillis();
			if (LOG.isDebugEnabled()) {
				LOG.debug("getDigest(): " + (t2 - t1));
			}
		}

		return (this.digest);

	}

	public String getEntropy() {

		// Calculate a semi-useful value if this has not been set
		if (this.entropy == null)
			setEntropy(this.toString());

		return (this.entropy);

	}

	void setEntropy(String entropy) {
		this.entropy = entropy;
	}

	// --------------------------------------------------- getters and setters

	public int getSessionIdLength() {
		return sessionIdLength;
	}

	/**
	 * Returns the {@link #nodeKey}.
	 * @return the nodeKey.
	 */
	String getNodeKey() {
		return nodeKey;
	}

}
