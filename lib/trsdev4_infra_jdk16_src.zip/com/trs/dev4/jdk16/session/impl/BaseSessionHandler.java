/*
 * Created: fangxiang@Apr 14, 2010 10:34:28 PM
 */
package com.trs.dev4.jdk16.session.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.servlet24.CookieHelper;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.session.ISessionHandler;
import com.trs.dev4.jdk16.session.ISessionUser;
import com.trs.dev4.jdk16.utils.NetUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 基础会话
 */
public abstract class BaseSessionHandler<T extends ISessionUser> implements
		ISessionHandler<T> {

	/**
	 * @since TRS @ Feb 13, 2012
	 */
	protected static final String ADDRESS_DENIED = "address.Denied";
	/**
	 * @since TRS @ Feb 13, 2012
	 */
	protected static final String ADDRESS_MIN_DURATION = "address.minDuration";
	/**
	 * @since TRS @ Feb 13, 2012
	 */
	protected static final String ADDRESS_MAX_VISIT_AS_ADDRESS = "address.maxVisitAsAddress";
	/**
	 * @since fangxiang @ Dec 23, 2010
	 */
	protected static final String SESSION_DENY_COUNT_MAX = "session.countMax";
	/**
	 * @since fangxiang @ Dec 23, 2010
	 */
	protected static final String SESSION_DENY_REMOTE_ADDR = "address.deny";
	/**
	 * @since fangxiang @ Dec 23, 2010
	 */
	protected static final String SESSION_DENY_DURATION = "session.duration";
	/**
	 * @since fangxiang @ Dec 6, 2010
	 */
	private static final String UCSID_COOKIE_NAME = "UCSID";
	/**
	 * @since fangxiang @ Dec 6, 2010
	 */
	private static final String UCSID_REQUEST_ATTR = "UCSID_REQUEST_ATTR";
	/**
	 *
	 */
	private final static Logger logger = Logger.getLogger(BaseSessionHandler.class);
	/**
	 *
	 */
	private static final String ATTR_VERIFY_CODE = "verifyCode";
	/**
	 * 会话后缀
	 */
	private String sessionIdSuffix = "";
	/**
	 * 主机地址
	 */
	private String hostAddress = "127.0.0.1";

	/**
	 * 
	 */
	public BaseSessionHandler(){
		hostAddress = NetUtil.getLocalHostIP();
		if (StringHelper.isEmpty(sessionIdSuffix)) {
			sessionIdSuffix = hostAddress.substring(hostAddress
					.lastIndexOf('.'));
		}
	}
	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#getUser(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public T getUser(HttpServletRequest request, HttpServletResponse response) {
		String ucsid = getUCSID(request, response);
		ApplicationSession as = getApplicationSession(ucsid);
		logger.debug("Request (" + request.getRequestURI() + ") : ucsid=("
				+ ucsid + "), as=(" + as + ")");
		if (as == null) {
			return null;
		}
		return getUser(as.getUserName());
	}

	/**
	 * @param request
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	protected String getUCSID(HttpServletRequest request,
			HttpServletResponse response) {
		return getUCSID(request, response, true);
	}

	/**
	 * @param request
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	protected String getUCSID(HttpServletRequest request,
			HttpServletResponse response, boolean create) {
		// 从Cookie中获取UCSID
		CookieHelper cookieHelper = new CookieHelper(request, response,
				getDomain());
		String ucsid = cookieHelper.getValue(UCSID_COOKIE_NAME);
		if (!StringHelper.isEmpty(ucsid)) {
			logger.debug("Found UCSID(" + ucsid + ") from Cookie.");
			return ucsid;
		}
		// 从Request的Attribute里面获取UCSID
		ApplicationSession as = (ApplicationSession) request
				.getAttribute(UCSID_REQUEST_ATTR);
		if (as != null) {
			logger.debug("Found UCSID(" + as.getId()
					+ ") from RequestAttribute.");
			return as.getId();
		}
		// 重新创建新的UCSID
		return create ? this.createUCSID() : "";
	}

	/**
	 * 根据用户名获取用户对象
	 *
	 * @param userName
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	protected abstract T getUser(String userName);

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#isLogin(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public boolean isLogined(HttpServletRequest request,
			HttpServletResponse response) {
		String ucsid = getUCSID(request, response);
		ApplicationSession as = getApplicationSession(ucsid);
		logger.debug("Request (" + request.getRequestURI() + ") : ucsid=("
				+ ucsid + "), as=(" + as + ")");
		return (as == null) ? false : as.isLogined();
	}

	/**
	 * 
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#isLogined(java.lang.String)
	 */
	@Override
	public boolean isLogined(String userName) {
		return true;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#login(javax.servlet.http.HttpServletRequest,
	 *      com.trs.dev4.jdk16.session.ISessionUser)
	 */
	@Override
	public void login(HttpServletRequest request, HttpServletResponse response,
			T user) {
		if (!allowLogin(user)) { // 如果用户不允许登录的话，则直接返回
			return;
		}
		ApplicationSession as = this.getApplicationSession(request, response,
				true);
		as.setUserId(user.getId());
		as.setUserName(user.getUserName());
		as.setNickName(user.getNickName());
		as.setRemoteAddr(request.getRemoteAddr());
		logger.debug("User (" + user.getNickName() + ") logined with as=("
				+ as.getId() + ")");
		applicationSessionUpdated(as);
		// 本地保存用户
		userLogin(user, as);
	}

	/**
	 * 是否允许用户登录
	 * 
	 * @param user
	 *            用户对象
	 * @return true表示允许登录，false表示不允许登录
	 * @since fangxiang @ Jan 13, 2011
	 */
	protected boolean allowLogin(T user) {
		return true;
	}

	/**
	 * 保存登陆用户
	 * 
	 * @param user
	 * @since fangxiang @ Dec 7, 2010
	 */
	protected abstract void userLogin(T user,
			ApplicationSession applicationSession);

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#logout(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public void logout(HttpServletRequest request, HttpServletResponse response) {
		String ucsid = this.getUCSID(request, response);
		ApplicationSession as = getApplicationSession(ucsid);
		if (as == null) {
			logger.error("Can't found ApplicationSession with UCSID(" + ucsid
					+ ").");
			return;
		}
		applicationSessionDeleted(as);
		//
		T user = this.getUser(as.getUserName());
		if (user != null) {
			logger.error("Found User(" + user + ") with userName("
					+ as.getUserName() + ").");
			userLogout(user, as);
		} else {
			logger.error("Can't found User with userName(" + as.getUserName()
					+ ").");
		}
		// 删除Cookie里面的UCSID标记
		CookieHelper cookieHelper = new CookieHelper(request, response);
		cookieHelper.removeCookie(UCSID_COOKIE_NAME, getDomain());
	}

	/**
	 * 应用会话已删除的通知
	 * 
	 * @param as
	 * @since fangxiang @ Dec 8, 2010
	 */
	protected abstract void applicationSessionDeleted(ApplicationSession as);

	/**
	 * 用户退出
	 * 
	 * @param ucsid
	 * @since fangxiang @ Dec 6, 2010
	 */
	protected abstract void userLogout(T user,
			ApplicationSession applicationSession);

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#getUserNick(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public String getUserNick(HttpServletRequest request,
			HttpServletResponse response) {
		String ucsid = this.getUCSID(request, response);
		ApplicationSession as = getApplicationSession(ucsid);
		if (as == null) {
			return "";
		}
		// CS-717
		logger.debug("Request (" + request.getRequestURI() + ") : ucsid=("
				+ ucsid + "), as=(" + as + ")");
		return as.getNickName();
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#getUserId(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public int getUserId(HttpServletRequest request,
			HttpServletResponse response) {
		String ucsid = this.getUCSID(request, response);
		ApplicationSession as = getApplicationSession(ucsid);
		if (as == null) { // 解决CS-901
			logger.info("Request (" + request.getRequestURI() + ") : ucsid=("
					+ ucsid + ") without ApplicationSession.");
			return -1;
		}
		logger.debug("Request (" + request.getRequestURI() + ") : ucsid=("
				+ ucsid + "), as=(" + as.toString() + ")");
		return as.getUserId();
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#isVerified(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public boolean isVerified(HttpServletRequest request,
			HttpServletResponse response) {
		String verifyCode = request.getParameter(ATTR_VERIFY_CODE);
		if (StringHelper.isEmpty(verifyCode)) {
			return true;
		}
		// 判断是否验证过
		String ucsid = this.getUCSID(request, response);
		ApplicationSession as = getApplicationSession(ucsid);
		logger.debug("Verify verifyCode (" + as.getVerifyCode()
				+ ") with verifyCode/parameter(" + verifyCode + ").");
		return verifyCode.equalsIgnoreCase(as.getVerifyCode());
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#setVerifyCode(javax.servlet.http.HttpServletRequest,
	 *      java.lang.String)
	 */
	@Override
	public void setVerifyCode(HttpServletRequest request,
			HttpServletResponse response, String verifyCode) {
		String ucsid = this.getUCSID(request, response);
		ApplicationSession as = this.getApplicationSession(ucsid);
		as.setVerifyCode(verifyCode);
		logger.debug("ApplicationSession (" + as.toString()
				+ ") updated with verifyCode(" + verifyCode + ").");
		applicationSessionUpdated(as);
	}

	/**
	 * 应用会话已更新的通知
	 * 
	 * @param as
	 * @since fangxiang @ Dec 6, 2010
	 */
	protected abstract void applicationSessionUpdated(ApplicationSession as);

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#isOnline(java.lang.String)
	 * @since fangxiang @ Oct 19, 2010
	 */
	@Override
	public boolean isOnline(String userName) {
		return false;
	}

	/**
	 * 根据UCSID构造新的应用会话
	 * 
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	protected ApplicationSession buildApplicationSession(String ucsid,
			String remoteAddr) {
		ApplicationSession as = ApplicationSession
				.buildAnonymousApplicationSession(ucsid, remoteAddr);
		as.setHostAddress(getHostAddress());
		applicationSessionCreated(as);
		return as;
	}

	/**
	 * 获取主机信息
	 * 
	 * @return
	 * @since fangxiang @ Jan 22, 2011
	 */
	protected String getHostAddress() {
		return this.hostAddress;
	}

	/**
	 * 应用会话已经创建的通知
	 * 
	 * @param as
	 * @since fangxiang @ Dec 8, 2010
	 */
	protected abstract void applicationSessionCreated(ApplicationSession as);

	/**
	 * @param session
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	private String createUCSID() {
		return new SessionIdGenerator(getUCSIDSuffix()).generateSessionId();
	}

	/**
	 * 
	 * @return
	 * @since fangxiang @ Jan 25, 2011
	 */
	protected String getUCSIDSuffix() {
		return sessionIdSuffix;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#statistic()
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	public Map<String, Object> statistic() {
		Map<String, Object> statistic = new HashMap<String, Object>();
		return statistic;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#getApplicationSession(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse, boolean)
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	public ApplicationSession getApplicationSession(HttpServletRequest request,
			HttpServletResponse response, boolean create) {
		// 流量控制措施
		addressLimit(request, response);
		// 根据Cookie的UCSID里面获取ApplicationSession
		CookieHelper cookieHelper = new CookieHelper(request, response,
				getDomain());
		ApplicationSession as = null;
		String ucsid = cookieHelper.getValue(UCSID_COOKIE_NAME);
		logger.debug("Found UCSID(" + ucsid + ") Cookie with Request(" + request.getServletPath() + ") by ContextPath(" + request.getContextPath() + ").");
		//
		if (!StringHelper.isEmpty(ucsid)) {
			as = this.getApplicationSession(ucsid);
		}
		sessionLimit(request, response, as);
		// 从Request的Attribute里面获取ApplicationSession
		as = (as == null) ? (ApplicationSession) request
				.getAttribute(UCSID_REQUEST_ATTR) : as;
		// 创建新的ApplicationSession
		String requestUrl = RequestUtil.getRelativePath(request);
		if (create && (as == null)) {
			ucsid = this.createUCSID();
			String remoteAddr = RequestUtil.getClientIP(request);
			logger.debug("New UCSID (" + ucsid + ") created for remoteAddr(" + remoteAddr + ") with Request(" + request.getServletPath() + ") by ContextPath("
					+ request.getContextPath() + ").");
			as = this.buildApplicationSession(ucsid, remoteAddr);
			as.setConsole(requestUrl.startsWith("/console")); // 设置控制台属性
			cookieHelper.addCookie(UCSID_COOKIE_NAME, as.getId());
			request.setAttribute(UCSID_REQUEST_ATTR, as);
		}
		return as;
	}

	/**
	 * @param request
	 * @param response
	 * @since TRS @ Feb 13, 2012
	 */
	protected void sessionLimit(HttpServletRequest request, HttpServletResponse response, ApplicationSession appSession) {
	}

	/**
	 * @param request
	 * @param response
	 * @since TRS @ Feb 13, 2012
	 */
	protected void addressLimit(HttpServletRequest request, HttpServletResponse response) {
	}

	/**
	 * 判断Url是否属于会话限制的
	 * 
	 * @param remoteAddr
	 * @param requestUrl
	 * @return
	 * @since fangxiang @ Jan 18, 2011
	 */
	protected boolean isSessionLimitUrl(String remoteAddr, String requestUrl) {
		String[] limitUrlPrefixes = getSessionLimitUrlPrefixes();
		if (limitUrlPrefixes.length <= 0) // 没有设置忽略列表，则直接返回false表示不是忽略的Url
			return false;
		//
		for (String limitUrlPrefix : limitUrlPrefixes) {
			if (requestUrl.startsWith(limitUrlPrefix)) { // 以指定的URL开头
				logger.debug("RequestUrl(" + requestUrl + ") starts with ("
						+ limitUrlPrefix + ").");
				return true;
			} else {
				logger.debug("RequestUrl(" + requestUrl + ") not starts with ("
						+ limitUrlPrefix + ").");
			}
		}
		return false;
	}

	/**
	 * @return
	 * @since fangxiang @ Jan 18, 2011
	 */
	protected String[] getSessionLimitUrlPrefixes() {
		return new String[] {};
	}

	/**
	 * 获得违反最小时间间隔时重定向的URL
	 * 
	 * @return 重定向的URL
	 * @since fangxiang @ Dec 22, 2010
	 */
	protected String getRedirectUrl(String reason) {
		return "";
	}

	/**
	 * 会话是否符合最小时间间隔
	 * 
	 * @param applicationSessionId
	 *            应用会话编号
	 * @return true表示符合最小时间间隔设置，false表示不符合最小时间间隔设置
	 * @since fangxiang @ Dec 22, 2010
	 */
	protected boolean assertDuration(String applicationSessionId) {
		return true;
	}

	/**
	 * 获取域名
	 * 
	 * @return
	 * @since fangxiang @ Dec 13, 2010
	 */
	protected String getDomain() {
		return null;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#updateLastModified(com.trs.dev4.jdk16.session.impl.ApplicationSession)
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	public void updateLastModified(ApplicationSession as) {
		as.access();
		this.applicationSessionUpdated(as);
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#getUser(javax.servlet.http.HttpServletRequest)
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	public T getUser(HttpServletRequest request) {
		String ucsid = getUCSID(request, null);
		ApplicationSession as = getApplicationSession(ucsid);
		logger.debug("Request (" + request.getRequestURI() + ") : ucsid=("
				+ ucsid + "), as=(" + as + ")");
		return (as != null) ? getUser(as.getUserName()) : null;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#getApplicationSessionId(javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse, boolean)
	 * @since fangxiang @ Dec 8, 2010
	 */
	@Override
	public String getApplicationSessionId(HttpServletRequest request,
			HttpServletResponse response, boolean create) {
		return getUCSID(request, response, create);
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#ignoreUrl(javax.servlet.ServletRequest)
	 */
	@Override
	public boolean ignoreUrl(HttpServletRequest request,
			HttpServletResponse response) {
		String[] ignoreUrls = getIgnoreUrls();
		if (ignoreUrls == null || ignoreUrls.length <= 0) // 没有设置忽略列表，则直接返回false表示不是忽略的Url
			return false;
		//
		String requestUrl = RequestUtil.getRelativePath(request);
		for (String ignoreUrl : ignoreUrls) {
			if (StringHelper.isEmpty(ignoreUrl)) {
				continue;
			}
			if (requestUrl.startsWith(ignoreUrl)) { // 以指定的URL开头
				logger.debug("RequestUrl(" + requestUrl + ") starts with ("
						+ ignoreUrl + ").");
				return true;
			} else {
				logger.debug("RequestUrl(" + requestUrl + ") not starts with ("
						+ ignoreUrl + ").");
			}
		}
		return false;
	}

	/**
	 * 获取忽略路径列表
	 * 
	 * @return
	 * @since fangxiang @ Jan 13, 2011
	 */
	protected String[] getIgnoreUrls() {
		return new String[] {};
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#countTotalUsers()
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public int countTotalUsers() {
		return 0;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#countLoginedUsers()
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public int countLoginedUsers() {
		return 0;
	}
}
