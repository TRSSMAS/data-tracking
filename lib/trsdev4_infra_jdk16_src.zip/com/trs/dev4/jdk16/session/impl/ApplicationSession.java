/*
 * Created: fangxiang@Nov 25, 2010 9:58:11 PM
 */
package com.trs.dev4.jdk16.session.impl;

import java.io.Serializable;

import com.trs.dev4.jdk16.utils.DateUtil;

/**
 * 应用会话
 */
public class ApplicationSession implements Serializable {
	/**
	 * @since fangxiang @ Nov 25, 2010
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 会话编号；
	 */
	private String id;
	/**
	 * 创建时间
	 */
	private long createdTime = DateUtil.getCurrentTimeMillis();
	/**
	 * 访问时间
	 */
	private long visitedTime;
	/**
	 * 控制台登录
	 */
	private boolean console;
	/**
	 * 主机名
	 */
	private String hostAddress;
	/**
	 * 用户编号
	 */
	private int userId;
	/**
	 * 用户名
	 */
	private String userName;
	/**
	 * 昵称
	 */
	private String nickName;
	/**
	 * 远程地址
	 */
	private String remoteAddr;
	/**
	 * 验证码
	 */
	private String verifyCode;
	/**
	 * 最后更新时间
	 */
	private long lastModifiedTime = DateUtil.getCurrentTimeMillis();

	/**
	 * 
	 * 
	 * @since fangxiang @ Dec 6, 2010
	 */
	public final static ApplicationSession buildAnonymousApplicationSession(
			String ucsid, String remoteAddr) {
		ApplicationSession as = new ApplicationSession(ucsid);
		as.setNickName("anonymous");
		as.setUserId(-1);
		as.setUserName("anonymous");
		as.setRemoteAddr(remoteAddr);
		as.setCreatedTime(DateUtil.getCurrentTimeMillis());
		return as;
	}

	/**
	 * 
	 */
	public ApplicationSession() {
	}

	/**
	 * 
	 * @param ucsid
	 */
	public ApplicationSession(String ucsid) {
		this.id = ucsid;
	}

	/**
	 * @return the {@link #id}
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the {@link #id} to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the {@link #createdTime}
	 */
	public long getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime
	 *            the {@link #createdTime} to set
	 */
	public void setCreatedTime(long createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return the {@link #visitedTime}
	 */
	public long getVisitedTime() {
		return visitedTime;
	}

	/**
	 * @param visitedTime
	 *            the {@link #visitedTime} to set
	 */
	public void setVisitedTime(long visitedTime) {
		this.visitedTime = visitedTime;
	}

	/**
	 * @return the {@link #userId}
	 */
	public int getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the {@link #userId} to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}

	/**
	 * @return the {@link #userName}
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the {@link #userName} to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the {@link #nickName}
	 */
	public String getNickName() {
		return nickName;
	}

	/**
	 * @param nickName
	 *            the {@link #nickName} to set
	 */
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	/**
	 * @return the {@link #remoteAddr}
	 */
	public String getRemoteAddr() {
		return remoteAddr;
	}

	/**
	 * @param removeAddr
	 *            the {@link #remoteAddr} to set
	 */
	public void setRemoteAddr(String removeAddr) {
		this.remoteAddr = removeAddr;
	}

	/**
	 * @return the {@link #verifyCode}
	 */
	public String getVerifyCode() {
		return verifyCode;
	}

	/**
	 * @param verifyCode
	 *            the {@link #verifyCode} to set
	 */
	public void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode;
	}

	/**
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	public boolean isLogined() {
		return this.userId != -1;
	}

	/**
	 * 
	 * @since fangxiang @ Dec 6, 2010
	 */
	public void access() {
		this.lastModifiedTime = DateUtil.getCurrentTimeMillis();
	}

	/**
	 * @return the {@link #lastModifiedTime}
	 */
	public long getLastModifiedTime() {
		return lastModifiedTime;
	}

	/**
	 * 
	 * @see java.lang.Object#toString()
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[id=").append(id).append(",userName=").append(userName)
				.append(",lastModified=").append(lastModifiedTime).append("]");
		return builder.toString();
	}

	/**
	 * 已经存活的时长
	 * 
	 * @return
	 * @since fangxiang @ Dec 16, 2010
	 */
	public long duration() {
		return DateUtil.getCurrentTimeMillis() - this.lastModifiedTime;
	}

	/**
	 * 是否已经失效
	 * 
	 * @param anonymousTTL
	 *            匿名的生存周期
	 * @param loginedTTL
	 *            登录用户的生存周期
	 * @return true表示已经失效，false表示尚未失效
	 * @since fangxiang @ Dec 16, 2010
	 */
	public boolean isTimeouted(long anonymousTTL, long loginedTTL) {
		boolean isTimeouted = false;
		if (this.isLogined()) {// 登录用户
			isTimeouted = this.duration() > loginedTTL;
		} else {// 匿名用户
			isTimeouted = this.duration() > anonymousTTL;
		}
		return isTimeouted;
	}

	/**
	 * @return the {@link #console}
	 */
	public boolean isConsole() {
		return console;
	}

	/**
	 * @param console
	 *            the {@link #console} to set
	 */
	public void setConsole(boolean console) {
		this.console = console;
	}

	/**
	 * @return the {@link #hostAddress}
	 */
	public String getHostAddress() {
		return hostAddress;
	}

	/**
	 * @param hostAddress
	 *            the {@link #hostAddress} to set
	 */
	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}
}
