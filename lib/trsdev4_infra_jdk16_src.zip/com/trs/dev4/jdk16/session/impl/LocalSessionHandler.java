/*
 * Created: fangxiang@Dec 7, 2010 4:23:52 PM
 */
package com.trs.dev4.jdk16.session.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.trs.dev4.jdk16.cacheserver.ICacheServer;
import com.trs.dev4.jdk16.cacheserver.impl.LocalCacheServer;
import com.trs.dev4.jdk16.model.Configuration;
import com.trs.dev4.jdk16.model.IConfigurable;
import com.trs.dev4.jdk16.model.IConfigurationManager;
import com.trs.dev4.jdk16.model.IModuleLifecycle;
import com.trs.dev4.jdk16.model.ValidationErrors;
import com.trs.dev4.jdk16.servlet24.RequestUtil;
import com.trs.dev4.jdk16.session.ApplicationSessionException;
import com.trs.dev4.jdk16.session.ISessionUser;
import com.trs.dev4.jdk16.thread.DaemonThreadControllor;
import com.trs.dev4.jdk16.thread.DaemonThreadFactory;
import com.trs.dev4.jdk16.thread.IThreadWorkload;
import com.trs.dev4.jdk16.utils.CollectionUtil;
import com.trs.dev4.jdk16.utils.DateUtil;
import com.trs.dev4.jdk16.utils.StringHelper;

/**
 * 本地会话管理
 */
public class LocalSessionHandler<T extends ISessionUser> extends BaseSessionHandler<T> implements IConfigurable, IModuleLifecycle, ApplicationContextAware {
	/**
	 *
	 */
	private final static Logger logger = Logger
			.getLogger(LocalSessionHandler.class);
	/**
	 * 登录用户名集合，UserName <==> UCSID
	 */
	protected Map<String, List<String>> loginedUserNames = new HashMap<String, List<String>>();
	/**
	 *
	 */
	private DaemonThreadControllor sessionTimeoutThread;
	/**
	 * 
	 */
	private IConfigurationManager configurationManager;
	/**
	 * 每小时最高登录用户计数
	 */
	protected TimestampCounter hourlyLoginedUsers = new TimestampCounter();

	/**
	 * 每小时最高访问用户技术
	 */
	protected TimestampCounter hourlyVisitedUsers = new TimestampCounter();

	/**
	 * 每天最高登录用户计数
	 */
	protected TimestampCounter dailyLoginedUsers = new TimestampCounter();

	/**
	 * 每天最高访问用户计数
	 */
	protected TimestampCounter dailyVisitedUsers = new TimestampCounter();

	/**
	 * 应用会话集合 ，UCSID <==> ApplicationSession
	 */
	protected Map<String, ApplicationSession> applicationSessions = new ConcurrentHashMap<String, ApplicationSession>();
	/**
	 * 管理台会话集合，UCSID<==>UserName
	 */
	protected Map<String, String> consoleSessions = new ConcurrentHashMap<String, String>();
	/**
	 * 按小时定时器
	 */
	private DaemonThreadControllor hourlyTimer;
	/**
	 * 按天定时器
	 */
	private DaemonThreadControllor dailyTimer;

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#countLoginedUsers()
	 */
	@Override
	public int countLoginedUsers() {
		return this.loginedUserNames.size();
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#countTotalUsers()
	 */
	@Override
	public int countTotalUsers() {
		return this.applicationSessions.size();
	}

	/**
	 *
	 * @param userName
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	protected T getUser(String userName) {
		return null;
	}

	/**
	 * @param ucsid
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	protected void userLogout(T user, ApplicationSession applicationSession) {
		removeLoginedUserName(applicationSession);
		logger.debug("User (" + user.getNickName() + ") logouted.");
	}

	/**
	 * @param as
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	protected void applicationSessionUpdated(ApplicationSession as) {
		logger.debug("ApplicationSession (" + as + ") updated.");
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#isOnline(java.lang.String)
	 * @since fangxiang @ Oct 19, 2010
	 */
	@Override
	public boolean isOnline(String userName) {
		return this.isLogined(userName);
	}

	/**
	 * @param ucsid
	 * @return
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	public ApplicationSession getApplicationSession(String ucsid) {
		ApplicationSession as = applicationSessions.get(ucsid);
		if (logger.isDebugEnabled()) {
			logger.debug("Found ApplicationSession(" + as + ") with ucsid(" + ucsid + "),applicationSessions(" + CollectionUtil.toString(applicationSessions)
				+ ") in this(" + this.hashCode() + ").");
		}
		return as;
	}

	/**
	 * @param request
	 * @param response
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	protected void sessionLimit(HttpServletRequest request, HttpServletResponse response, ApplicationSession appSession) {
		if (appSession == null)
			return;
		// 判断是否符合会话数目限制，/console开始的不计算会话，保证后台可以登录访问
		String requestUrl = RequestUtil.getRelativePath(request);
		if (!usingSessionLimit() || !requestUrl.startsWith("/console")) {
			return;
		}
		if (this.countTotalUsers() >= this.getMaxTotalSessions()) {
			throw new ApplicationSessionException(BaseSessionHandler.SESSION_DENY_COUNT_MAX,getRedirectUrl(SESSION_DENY_COUNT_MAX));
		}
		//
		if ((System.currentTimeMillis() - appSession.getLastModifiedTime()) < getMinSessionDuration() * 1000L) {
			throw new ApplicationSessionException(BaseSessionHandler.SESSION_DENY_DURATION, getRedirectUrl(SESSION_DENY_COUNT_MAX));
		}
	}

	/**
	 * 是否启用会话限制
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected boolean usingSessionLimit() {
		if (getConfigurationManager() != null) {
			return getConfigurationManager().getConfigurationAsBoolean(this, "usingSessionLimit", false);
		}
		return false;
	}

	/**
	 * 总会话数
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected int getMaxTotalSessions() {
		if (getConfigurationManager() != null) {
			return getConfigurationManager().getConfigurationAsInt(this, "maxTotalSessions", 100);
		}
		return 100;
	}

	/**
	 * 会话最小访问间隔
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected long getMinSessionDuration() {
		return 1;
	}

	/**
	 * 获取统计信息
	 * 
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#statistic()
	 * @since fangxiang @ Dec 6, 2010
	 */
	@Override
	public Map<String, Object> statistic() {
		Map<String, Object> statistic = new HashMap<String, Object>();
		statistic.put("totalUsers", this.applicationSessions.size());
		statistic.put("applicationSessions", this.applicationSessions);
		statistic.put("loginedUserNames", this.loginedUserNames);
		statistic.put("dailyLoginedUsers", dailyLoginedUsers);
		statistic.put("dailyVisitedUsers", dailyVisitedUsers);
		statistic.put("hourlyLoginedUsers", hourlyLoginedUsers);
		statistic.put("hourlyVisitedUsers", hourlyVisitedUsers);
		return statistic;
	}

	/**
	 * @param user
	 * @since fangxiang @ Dec 7, 2010
	 */
	@Override
	protected void userLogin(T user, ApplicationSession applicationSession) {
		updateLoginedUserName(applicationSession);
		// 小时登录用户量增加
		this.hourlyLoginedUsers.count();
		// 每天登录用户量增加
		this.dailyLoginedUsers.count();
	}

	/**
	 * @see com.trs.dev4.jdk16.session.impl.BaseSessionHandler#applicationSessionCreated(com.trs.dev4.jdk16.session.impl.ApplicationSession)
	 * @since fangxiang @ Dec 7, 2010
	 */
	@Override
	protected void applicationSessionCreated(ApplicationSession as) {
		applicationSessions.put(as.getId(), as);
		if (logger.isDebugEnabled()) {
			logger.debug("Put applicationSession(" + as + ") to applicationSessions(" + applicationSessions.size() + ") with key(" + as.getId() + ") in this("
					+ this.hashCode() + ").");
		}
		// 小时访问用户量增加
		this.hourlyVisitedUsers.count();
		// 每天访问用户量增加
		this.dailyVisitedUsers.count();
	}

	/**
	 * @param request
	 * @param response
	 * @since TRS @ Feb 13, 2012
	 */
	@Override
	protected void addressLimit(HttpServletRequest request, HttpServletResponse response) {
		if (!usingAddressLimit()) {// 如果没有启用访问流量限制，则直接返回
			return;
		}
		//
		ICacheServer addressCacheServer = LocalCacheServer.getInstance("addressCacheServer");
		// 判断是否属于允许的地址范围
		String remoteAddr = RequestUtil.getClientIP(request);
		if (!allowedRemoteAddress(remoteAddr)) {
			throw new ApplicationSessionException(ADDRESS_DENIED, getRedirectUrl(ADDRESS_DENIED));
		}
		Integer[] visitedCounter = (Integer[]) addressCacheServer.get(remoteAddr);
		if (visitedCounter == null) {
			visitedCounter = new Integer[] { (int) System.currentTimeMillis(), 1 };
			addressCacheServer.add(remoteAddr, 60, visitedCounter);
		} else {
			if (visitedCounter[1] >= getMaxVisitPerAddress()) {
				throw new ApplicationSessionException(ADDRESS_MAX_VISIT_AS_ADDRESS, getRedirectUrl(ADDRESS_MAX_VISIT_AS_ADDRESS));
			}
			if ((System.currentTimeMillis() - visitedCounter[0]) < getMinAddressDuration() * 1000L) {
				throw new ApplicationSessionException(ADDRESS_MIN_DURATION, getRedirectUrl(ADDRESS_MIN_DURATION));
			}
			addressCacheServer.set(remoteAddr, visitedCounter[1] + 1);
		}
	}

	/**
	 * 判断地址是否在允许范围内，如果不在则直接抛出一场
	 * 
	 * @param remoteAddr
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected boolean allowedRemoteAddress(String remoteAddr) {
		return false;
	}

	/**
	 * 每个地址最小时间间隔，单位秒
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected long getMinAddressDuration() {
		return 1;
	}

	/**
	 * 每个地址最大访问次数，每分钟
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected int getMaxVisitPerAddress() {
		return 10;
	}

	/**
	 * 是否启用地址限制
	 * 
	 * @return
	 * @since TRS @ Feb 13, 2012
	 */
	protected boolean usingAddressLimit() {
		return false;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.impl.BaseSessionHandler#applicationSessionDeleted(com.trs.dev4.jdk16.session.impl.ApplicationSession)
	 * @since fangxiang @ Dec 8, 2010
	 */
	@Override
	protected void applicationSessionDeleted(ApplicationSession as) {
		if (as == null) {
			return;
		}
		applicationSessions.remove(as.getId());
		// 删除登录用户
		List<String> applicationSessionIds = loginedUserNames.get(as
				.getUserName());
		if (applicationSessionIds != null) {
			applicationSessionIds.remove(as.getId());
			if (applicationSessionIds.size() <= 0) {
				loginedUserNames.remove(as.getUserName());
			}
		}
		logger.debug("ApplicationSession (" + as.toString() + ") removed.");
	}

	/**
	 * 带有时间戳的统计计数器
	 *
	 */
	protected class TimestampCounter {
		/**
		 * 统计计数值
		 */
		private long counterValue = 0;
		/**
		 * 发生时间点
		 */
		private long timestamp = 0;

		/**
		 * 计数
		 *
		 * @since fangxiang @ Dec 16, 2010
		 */
		public void count() {
			this.counterValue = this.counterValue + 1;
			this.timestamp = DateUtil.getCurrentTimeMillis();
		}

		/**
		 * 归零
		 *
		 * @since fangxiang @ Dec 16, 2010
		 */
		public void rotate() {
			this.counterValue = 0;
			this.timestamp = 0;
		}

		/**
		 * @return the {@link #timestamp}
		 */
		public long getTimestamp() {
			return timestamp;
		}

		/**
		 * @return the {@link #counterValue}
		 */
		public long getCounterValue() {
			return counterValue;
		}

		/**
		 * @see java.lang.Object#toString()
		 * @since fangxiang @ Dec 22, 2010
		 */
		@Override
		public String toString() {
			return "TimestampCounter [counterValue=" + counterValue
					+ ", timestamp=" + timestamp + "]";
		}
	}

	/**
	 * 清理超时的ApplicationSession的内部线程类
	 *
	 */
	protected class BackgroundProcessorSession implements Runnable {
		public void run() {
			while (!isRunning()) {
				try {
					Thread.sleep(5 * 60 * 1000L); // 1分钟
				} catch (InterruptedException e) {
					logger.warn("interrrupted when sleep in BackgroundProcessorLogin.");
				}
				try {
					applicationSessionTimeout();
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
	}

	/**
	 * 线程是否执行
	 *
	 * @return true表示执行，false表示停止
	 * @since fangxiang @ Dec 16, 2010
	 */
	protected boolean isRunning() {
		return true;
	}

	/**
	 * 匿名用户的有效期
	 *
	 * @return 默认是30分钟
	 * @since fangxiang @ Dec 16, 2010
	 */
	protected long getAnonymousTTL() {
		return 30;
	}

	/**
	 * 登录用户的有效期
	 *
	 * @return 默认是120分钟
	 * @since fangxiang @ Dec 16, 2010
	 */
	protected long getLoginedTTL() {
		return 120;
	}

	/**
	 * 
	 * @param as
	 * @since fangxiang @ Jan 22, 2011
	 */
	private void removeLoginedUserName(ApplicationSession applicationSession) {
		List<String> applicationSessionIds = loginedUserNames
				.get(applicationSession.getUserName());
		if (applicationSessionIds != null) {
			applicationSessionIds.remove(applicationSession.getId());
			if (applicationSessionIds.size() <= 0) {
				loginedUserNames.remove(applicationSession.getUserName());
			}
		}
		// 处理管理台登录
		if (applicationSession.isConsole()) {
			consoleSessions.remove(applicationSession.getId());
		}
	}

	/**
	 * 
	 * @param as
	 * @since fangxiang @ Jan 22, 2011
	 */
	private void updateLoginedUserName(ApplicationSession applicationSession) {
		String userName = applicationSession.getUserName();
		List<String> applicationSessionIds = loginedUserNames.get(userName);
		if (applicationSessionIds == null) {
			applicationSessionIds = new ArrayList<String>();
			loginedUserNames.put(userName, applicationSessionIds);
		}
		applicationSessionIds.add(applicationSession.getId());
		logger.debug("UserName(" + userName + ") put to loginedUserNames.");
		// 管理台登录
		if (applicationSession.isConsole()) {
			if (null == consoleSessions.get(applicationSession.getId())) {
				consoleSessions.put(applicationSession.getId(),
						applicationSession.getUserName());
			}
		}
	}

	/**
	 * 超时
	 * 
	 * @param applicationSession
	 * @since fangxiang @ Dec 16, 2010
	 */
	protected void timeout(ApplicationSession applicationSession) {
		this.applicationSessions.remove(applicationSession.getId());
		removeLoginedUserName(applicationSession);
	}

	/**
	 * 会话时长的单位，分钟
	 *
	 * @return
	 * @since fangxiang @ Dec 16, 2010
	 */
	protected long getTTLUnit() {
		return 60 * 1000L;
	}

	/**
	 * 会话超时处理，对于已经超时的会话自动销毁
	 *
	 * @since fangxiang @ Dec 16, 2010
	 */
	protected void applicationSessionTimeout() {
		ApplicationSession[] applicationSessions = this.applicationSessions
				.values().toArray(new ApplicationSession[0]);
		//
		long timeoutSessionCount = 0;
		long beginTimeout = DateUtil.getCurrentTimeMillis();
		// 匿名会话有效时间
		long anonymousTTL = this.getAnonymousTTL() * this.getTTLUnit();
		// 登录会话有效时间
		long loginedTTL = this.getLoginedTTL() * this.getTTLUnit();
		if (logger.isDebugEnabled()) {
			logger.debug("loginedTTL:" + loginedTTL + ",anonymousTTL:" + anonymousTTL);
		}
		// 依次检查会话
		for (ApplicationSession applicationSession : applicationSessions) {
			if (applicationSession.isTimeouted(anonymousTTL,
					loginedTTL)) {
				timeout(applicationSession);
				timeoutSessionCount++;
				logger.debug("ApplicationSession (" + applicationSession
						+ ") timeouted.");
			} else {
				logger.debug("ApplicationSession (" + applicationSession
						+ ") continue lived.");
			}
		}
		long timeoutDuration = DateUtil.getCurrentTimeMillis() - beginTimeout;
		logger.debug("Have(" + timeoutSessionCount
				+ ")sessions timeouted elapsed (" + timeoutDuration
				+ ")ms of ("
				+ applicationSessions.length + ") sessions.");
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#getModuleName()
	 * @since fangxiang @ Dec 16, 2010
	 */
	@Override
	public String getModuleName() {
		return "localSessionHandler";
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#start()
	 * @since fangxiang @ Dec 16, 2010
	 */
	@Override
	public void start() {
		// 按分钟失效
		DaemonThreadFactory.getInstance().startThread("Session.Timeout.Thread", 60, 0,
				new IThreadWorkload() {
					@Override
					public void onExecute() {
						applicationSessionTimeout();
					}
				});
		
		// 定时发送消息
		DaemonThreadFactory.getInstance().startThread("Session.HourlyEvent.Thread", 3600, getHourlyDelay(),
				new IThreadWorkload() {
					@Override
					public void onExecute() {
						Calendar current = Calendar.getInstance();
						hourlyEvent(DateUtil.format2String(current.getTime(),
								"yyyy-MM-dd"), current
								.get(Calendar.HOUR_OF_DAY));
					}
				});
		DaemonThreadFactory.getInstance().startThread("Session.DailyEvent.Thread", 3600 * 24,
				getDailyDelay(),
				new IThreadWorkload() {
					@Override
					public void onExecute() {
						dailyEvent(DateUtil.format2String(Calendar
								.getInstance().getTime(), "yyyy-MM-dd"));
					}
				});
	}

	/**
	 * @return
	 * @since fangxiang @ Dec 23, 2010
	 */
	private long getDailyDelay() {
		long dayDuration = DateUtil.getDayDurationAsMillis(1);
		logger.debug("Day delay (" + dayDuration + ") ms.");
		return dayDuration;
	}

	/**
	 * @return
	 * @since fangxiang @ Dec 23, 2010
	 */
	private long getHourlyDelay() {
		long hourDuration = DateUtil.getHourDurationAsMillis(1);
		logger.debug("Hour delay (" + hourDuration + ") ms.");
		return hourDuration;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#stop()
	 * @since fangxiang @ Dec 16, 2010
	 */
	@Override
	public void stop() {
		if (sessionTimeoutThread != null) {
			sessionTimeoutThread.stop();
		}
		if (hourlyTimer != null) {
			hourlyTimer.stop();
		}
		if (dailyTimer != null) {
			dailyTimer.stop();
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IModuleLifecycle#restart()
	 * @since fangxiang @ Dec 16, 2010
	 */
	@Override
	public void restart() {

	}

	/**
	 *
	 *
	 * @since fangxiang @ Dec 23, 2010
	 */
	protected void dailyEvent(String day) {
		logger.debug("dailyVisitedUsers(" + dailyVisitedUsers
				+ ") and dailyLoginedUsers(" + dailyLoginedUsers
				+ ") rotated by daily.");
		this.dailyLoginedUsers.rotate();
		this.dailyVisitedUsers.rotate();
	}

	/**
	 * 每小时执行一次
	 *
	 */
	class HourlyTrigger extends TimerTask {

		/**
		 * @see java.util.TimerTask#run()
		 * @since fangxiang @ Dec 23, 2010
		 */
		@Override
		public void run() {
			Calendar current = Calendar.getInstance();
			hourlyEvent(
					DateUtil.format2String(current.getTime(), "yyyy-MM-dd"),
					current.get(Calendar.HOUR_OF_DAY));
			logger.debug("Hourly event Triggered.");
		}

	}

	/**
	 *
	 *
	 * @since fangxiang @ Dec 23, 2010
	 */
	protected void hourlyEvent(String day, int hour) {
		logger.debug("hourlyLoginedUsers(" + hourlyLoginedUsers
				+ ") and hourlyVisitedUsers(" + hourlyVisitedUsers
				+ ") rotated by hourly.");
		this.hourlyLoginedUsers.rotate();
		this.hourlyVisitedUsers.rotate();
	}

	/**
	 * 每天执行一次
	 *
	 */
	class DailyTrigger extends TimerTask {

		/**
		 * @see java.util.TimerTask#run()
		 * @since fangxiang @ Dec 23, 2010
		 */
		@Override
		public void run() {
			dailyEvent(DateUtil.format2String(Calendar.getInstance().getTime(),
					"yyyy-MM-dd"));
			logger.debug("Daily event Triggered.");
		}
	}

	/**
	 * @see com.trs.dev4.jdk16.session.impl.BaseSessionHandler#isLogined(String)
	 */
	@Override
	public boolean isLogined(String userName) {
		if (StringHelper.isEmpty(userName)) {
			return false;
		}
		return (loginedUserNames.get(userName) != null);
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#listSessionIds(java.lang.String)
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public List<ApplicationSession> listApplicationSessions(String userName) {
		List<ApplicationSession> applicationSessions = new ArrayList<ApplicationSession>();
		if (StringHelper.isEmpty(userName)) {
			return applicationSessions;
		}
		List<String> applicationSessionIds = loginedUserNames.get(userName);
		for (String applicationSessionId : applicationSessionIds) {
			applicationSessions
					.add(getApplicationSession(applicationSessionId));
		}
		return applicationSessions;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#countConsoleUsers()
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public int countConsoleUsers() {
		return this.consoleSessions.size();
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#getSessionLimit()
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public int getSessionLimit() {
		return 20000;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.ISessionHandler#countFreeSessions(boolean)
	 * @since fangxiang @ Jan 22, 2011
	 */
	@Override
	public int countFreeSessions(boolean consoleInclude) {
		if (consoleInclude) {
			return this.getSessionLimit() - this.applicationSessions.size();
		}
		return this.getSessionLimit() - this.countTotalUsers()
				+ this.countConsoleUsers();
	}

	/**
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		configurationManager = (IConfigurationManager) applicationContext.getBean("configurationManager");
	}

	/**
	 * @param configurationManager
	 *            the {@link #configurationManager} to set
	 */
	protected void setConfigurationManager(IConfigurationManager configurationManager) {
		this.configurationManager = configurationManager;
	}

	/**
	 * @see com.trs.dev4.jdk16.session.impl.BaseSessionHandler#getRedirectUrl(java.lang.String)
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	protected String getRedirectUrl(String reason) {
		return super.getRedirectUrl(reason);
	}

	/**
	 * @see com.trs.dev4.jdk16.session.impl.BaseSessionHandler#getIgnoreUrls()
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	protected String[] getIgnoreUrls() {
		if (getConfigurationManager() != null) {
			return StringHelper.split(getConfigurationManager().getConfiguration(this, "ignoreUrls"), ";");
		}
		return super.getIgnoreUrls();
	}

	/**
	 * 
	 * @return
	 * @since TRS @ Feb 14, 2012
	 */
	protected IConfigurationManager getConfigurationManager() {
		return configurationManager;
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#getPrefix()
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	public String getPrefix() {
		return this.getClass().getSimpleName();
	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#refreshConfigs()
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	public void refreshConfigs() {

	}

	/**
	 * @see com.trs.dev4.jdk16.model.IConfigurable#validateConfigs(java.util.Map)
	 * @since TRS @ Feb 14, 2012
	 */
	@Override
	public ValidationErrors validateConfigs(Map<String, Configuration> configs) {
		return null;
	}
}
