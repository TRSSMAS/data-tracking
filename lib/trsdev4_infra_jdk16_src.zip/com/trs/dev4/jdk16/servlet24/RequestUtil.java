/*
 * Created: liushen@2007-6-7 下午05:30:47
 */
package com.trs.dev4.jdk16.servlet24;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.trs.dev4.jdk16.servlet24.UserAgent.OS;
import com.trs.dev4.jdk16.utils.ReflectUtil;
import com.trs.dev4.jdk16.utils.StringHelper;
import com.trs.dev4.jdk16.xss.SafeHtmlUtil;

/**
 * 封装HttpRequest相关操作的通用工具类; 支持Servlet 2.4中新增的方法. <BR>
 * 需要JDK 1.5(由于使用了StringBuilder等).
 * 
 * <b>注意: </b>本类为通用工具类; TRSMAS MVC约定的参数获取方法则在View层的工具类
 * {@link com.trs.mam.view.util.RequestTranslator}中.
 * 
 * @author TRS信息技术有限公司
 */
public class RequestUtil {
	/**
	 * 日志
	 */
	private final static Logger LOG = Logger.getLogger(RequestUtil.class);

	/**
	 *
	 */
	private static final String PARAM_ID_ARRAY = "ids";
	/**
	 *
	 */
    public static final String HEADER_USER_AGENT = "user-agent";

    /**
     *
     */
    public static final String HEADER_REFER = "referer";

    /**
     *
     */
    public static final String NEWLINE = System.getProperty("line.separator");

	/**
	 * 获取指定request的指定参数的整数值.
	 * 
	 * @param request
	 *            指定request
	 * @param param
	 *            指定参数
	 * @return 参数值的整数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回0.
	 */
	public static int getParameterAsInt(HttpServletRequest request, String param) {
	    return getParameterAsInt(request, param, 0);
	}

	/**
	 * 获取指定request的指定参数的小数值.
	 * 
	 * @param request
	 *            指定request
	 * @param param
	 *            指定参数
	 * @return 参数值的小数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回0.
	 * 
	 * @creator fengjianhua @ 2009-4-8
	 */
	public static double getParameterAsDouble(HttpServletRequest request, String param) {
		return getParameterAsDouble(request, param, 0);
	}

	/**
	 * 获取指定request的指定参数的整数值. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 * 
	 * @param request
	 *            指定request
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            给定的默认值.
	 * @return 参数值的整数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 */
	public static int getParameterAsInt(HttpServletRequest request,
	        String param, int defValue) {
		String result = request.getParameter(param);
		if (result == null) {
			return defValue;
		}
		result = result.trim();
		if (result.length() == 0) {
			return defValue;
		}
		try {
			return Integer.parseInt(result);
		} catch (Exception e) {
			return defValue;
		}
	}

	/**
	 * 获取给定参数名的取值，以int数组返回.
	 * 
	 * @return int数组; 如该参数不存在或不是int序列，则返回<code>int[0]</code>.
	 * @since liushen @ Mar 28, 2011
	 */
	public static int[] getParameterAsIntArray(HttpServletRequest request,
			String param) {
		String[] valuesStr = request.getParameterValues(param);
		if (valuesStr == null) {
			return new int[0];
		}
	
		int[] valuesInt = new int[valuesStr.length];
		for (int i = 0; i < valuesStr.length; i++) {
			valuesInt[i] = Integer.parseInt(valuesStr[i]);
		}
		return valuesInt;
	}

	/**
	 * 获取指定request的指定参数的小数值. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 * 
	 * @param request
	 *            指定request
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            给定的默认值.
	 * @return 参数值的小数形式. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 * 
	 * @creator fengjianhua @ 2009-4-8
	 */
	public static double getParameterAsDouble(HttpServletRequest request,
			String param, double defValue) {
		String result = request.getParameter(param);
		if (result == null) {
			return defValue;
		}
		result = result.trim();
		if (result.length() == 0) {
			return defValue;
		}
		try {
			return Double.valueOf(result);
		} catch (Exception e) {
			return defValue;
		}
	}

	/**
	 * 以基本类型boolean值返回给定的Request对象中的指定参数的取值. 如果Request对象中找不到该指定参数, 则返回false.
	 * 
	 * @param request
	 *            给定的Request对象
	 * @param param
	 *            指定参数
	 * @return 给定的Request对象中的指定参数的boolean取值
	 * @see RequestUtil#getParameterAsBool(HttpServletRequest, String, boolean)
	 */
	public static boolean getParameterAsBool(HttpServletRequest request, String param) {
	    return getParameterAsBool(request, param, false);
	}

	/**
	 * 以基本类型boolean值返回给定的Request对象中的指定参数的取值. 如果Request对象中找不到该指定参数, 则返回给定的默认值. <BR>
	 * 表示布尔值的字符串大小写无关. 当且仅当表示布尔值的字符串为"true"时(忽略大小写), 返回true. 例如: <tt>"True"</tt>
	 * 返回 <tt>true</tt>.<br>
	 * 再如: <tt>"yes"</tt> 返回 <tt>false</tt>.
	 * 
	 * @param request
	 *            给定的Request对象
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            默认取值
	 * @return 给定的Request对象中的指定参数的boolean取值
	 */
	public static boolean getParameterAsBool(HttpServletRequest request,
	        String param, boolean defaultValue) {
	    boolean result = defaultValue;
	    String paramValue = request.getParameter(param);
	    if (paramValue != null) {
	        result = "true".equalsIgnoreCase(paramValue);
	    }
	    return result;
	}

	/**
	 * 返回给定的Request对象中的指定参数的取值(String值), <b>不做任何编码转换</b>. 如果Request对象中找不到该指定参数,
	 * 则返回给定的默认值.
	 * 
	 * @param request
	 *            给定的Request对象
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            默认取值
	 * @return 给定的Request对象中的指定参数的值
	 */
	public static String getParameter(HttpServletRequest request, String param, String defaultValue) {
		return getParameterAndTrim(request, param, defaultValue, -1);
	}

	/**
	 * 返回给定的Request对象中的指定参数的取值(String值), <b>不做任何编码转换</b>. 如果Request对象中找不到该指定参数,
	 * 则返回<code>""</code>.
	 * 
	 * @param request
	 *            给定的Request对象
	 * @param param
	 *            指定参数
	 * @return 给定的Request对象中的指定参数的值
	 * @creator liushen @ Jan 6, 2010
	 */
	public static String getParameterAvoidNull(HttpServletRequest request, String param) {
		return getParameter(request, param, "");
	}

	/**
	 * 获取指定request的指定参数的值并作trim处理. 如果不存在该参数, 返回"".
	 * 
	 * @return 指定参数的值并作trim处理
	 * @since ls@08.0107
	 */
	public static String getParameterAndTrim(HttpServletRequest req, String param) {
		return getParameterAndTrim(req, param, "", -1);
	}

	/**
	 * 获取指定request的指定参数的值并作trim处理. 如果不存在该参数, 返回"".
	 * 
	 * @return 指定参数的值并作trim处理
	 */
	public static String getParameterAndTrim(HttpServletRequest req,
			String param, String defaultValue, int maxLength) {
		String result = req.getParameter(param);
		result = (result == null) ? defaultValue : result.trim();
		if (maxLength != -1 && result.length() >= maxLength) {
			throw new IllegalArgumentException("Param[" + param
					+ "]'s value greater than maxLength(" + maxLength + ")");
		}
		return SafeHtmlUtil.getSafeHtml(result);
	}

	/**
	 * 返回给定的Request对象中的指定参数的取值(String值), 如果该参数不存在或该参数的值为空(包括trim后为空的情况),
	 * 则返回给定的默认值. <b>该方法不做任何编码转换</b>.
	 * 
	 * @param request
	 *            给定的Request对象
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            默认取值
	 * @since ls@08.0603
	 */
	public static String getParameterAsTrimed(HttpServletRequest request, String param, String defValue) {
		String result = request.getParameter(param);
		if (result == null) {
			return defValue;
		}
		result = result.trim();
		if (result.length() == 0) {
			return defValue;
		}
		return result;
	}

	/**
	 * 从HTTP请求中获取指定参数的值，以枚举对象返回.
	 * 
	 * @param <T>
	 * @param request
	 * @param param
	 *            参数名
	 * @param clazz
	 *            枚举对象的类型
	 * @return 枚举对象
	 * @since liushen @ Apr 19, 2011
	 */
	public static <T extends Enum<T>> T getParameterAsEnum(
			HttpServletRequest request, String param, Class<T> clazz) {
		String result = request.getParameter(param);
		if (result == null) {
			return null;
		}
		return ReflectUtil.getEnumFromString(clazz, result);
	}

	public static String getAttributeAsTrimStr(HttpServletRequest req, String attrName) {
	    return getAttributeAsTrimStr(req, attrName, "");
	}

	public static String getAttributeAsTrimStr(HttpServletRequest req, String attrName, String defValue) {
	    Object obj = req.getAttribute(attrName);
	    return (obj instanceof String) ? ((String) obj).trim() : defValue;
	}

	/**
	 * 获取表示给定HTTP请求的完整URL字符串(包括QueryString). <BR>
	 * 
	 * @deprecated liushen@Mar 20, 2011: use
	 *             {@link #getFullUrlWithGetStr(HttpServletRequest)}
	 */
	@Deprecated
	public static String getFullGetStr(HttpServletRequest req) {
	    final String qryStr = req.getQueryString();
	    if (qryStr == null) {
	        return req.getRequestURL().toString();
	    }
	    return req.getRequestURL().append('?').append(qryStr).toString();
	}

	/**
	 * 获取表示给定HTTP请求的完整URL字符串(包括QueryString).
	 * 
	 * @since liushen @ Mar 28, 2011
	 */
	public static String getFullUrlWithGetStr(HttpServletRequest request) {
		// String contextUrl = getContextUrlWithSlash(request);
		// return contextUrl + getClientRequestURL(request);
		return getClientRequestURL(request);
	}

	/**
	 * 返回页面文件名.比如访问的是http://xxx.com/app1/path1/path2/page3.jsp, 则该方法返回page3.jsp.
	 */
	public static String getCurrentPage(HttpServletRequest req) {
	    final String requestURI = req.getRequestURI();
	    return requestURI.substring(requestURI.lastIndexOf('/') + 1);
	}

	/**
	 * 
	 * @param req
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public static String getRequestInfo(HttpServletRequest req) {
		StringBuilder sb = new StringBuilder(320);
	    sb.append("[Req]");
	    sb.append(req.getClass().getName());
	    sb.append(": (").append(req.getScheme()).append(')').append(req.getServerName()).append(':').append(req.getServerPort());
	    sb.append(", ").append(req.getMethod()).append(' ').append(req.getProtocol());
	    sb.append(", uri=").append(req.getRequestURI());
	    sb.append(", ctx=").append(req.getContextPath());
	    sb.append(", servlet=").append(req.getServletPath());
	    sb.append(", qryStr=").append(req.getQueryString());
	    sb.append(", refer=").append(req.getHeader(HEADER_REFER));
	    sb.append(", useragt=").append(req.getHeader(HEADER_USER_AGENT));
	    sb.append(", ip=").append(req.getRemoteAddr());
	    sb.append(", encoding=").append(req.getCharacterEncoding());
	    return sb.toString();
	}

	/**
	 * 获取给定的request中全部的Header信息.
	 * 
	 * @param req
	 *            给定的request
	 * @return 全部Header信息构成的字符串.
	 */
	public static String getAllHeadersStr(HttpServletRequest req) {
		StringBuilder sb = new StringBuilder(256);
	    String header = null;
		for (Enumeration<?> headers = req.getHeaderNames(); headers
				.hasMoreElements();) {
	        header = (String) headers.nextElement();
	        sb.append(header);
	        sb.append("=");
	        sb.append(req.getHeader(header));
	        sb.append("\r\n");
	    }
	    return sb.toString();
	}

	/**
	 *
	 * @param request
	 * @return
	 * @creator liushen @ Feb 19, 2010
	 */
	public static Map<String, Object> getAllAttributes(HttpServletRequest request) {
		return getAllAttributesByPrefix(request, null);
	}

	/**
	 * 
	 * @param request
	 * @param prefix
	 * @return
	 * @since liushen @ Feb 20, 2012
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getAllAttributesByPrefix(HttpServletRequest request, String prefix) {
		Map<String, Object> attrsMap = new HashMap<String, Object>();
		if (prefix == null) {
			prefix = "";
		}
		for (Enumeration<String> enu = request.getAttributeNames(); enu.hasMoreElements();) {
			String key = enu.nextElement();
			if (key.startsWith(prefix)) {
				attrsMap.put(key, request.getAttribute(key));
			}
		}
		return attrsMap;
	}

	/**
	 * 
	 * @param request
	 * @return
	 */
	public static String getAllParameters(HttpServletRequest request) {
		Enumeration<?> parameterNames = request.getParameterNames();
		StringBuilder buffer = new StringBuilder();
		for ( ; parameterNames.hasMoreElements() ; ){
			String parameterName = (String)parameterNames.nextElement();
			buffer.append(parameterName).append("=").append(RequestUtil.getParameterAndTrim(request, parameterName)).append(";");
		}
		return buffer.toString();
	}

	/**
	 * 
	 * @param request
	 * @creator liushen @ Feb 19, 2010
	 */
	public static void dumpAllAttrsToStdout(HttpServletRequest request) {
		dumpAttrs(request, System.out, null);
	}

	/**
	 * 
	 * @param request
	 * @since liushen @ Feb 20, 2012
	 */
	public static void dumpJSTLConfigAttrsToStdout(HttpServletRequest request) {
		dumpAttrs(request, System.out, "javax.servlet.jsp.jstl");
	}

	/**
	 * @param request
	 * @return 包含请求参数信息的字符串.
	 * @since liushen @ Aug 11, 2010
	 */
	@SuppressWarnings("unchecked")
	public static String dumpParameters(HttpServletRequest request) {
		StringBuilder sb = new StringBuilder();
		sb.append("parameters in request ").append(request.getRequestURI())
				.append(":\n");
		int total = 0;
		for (Enumeration<String> params = request.getParameterNames(); params
				.hasMoreElements();) {
			String name = params.nextElement();
			sb.append(name).append(" = ").append(request.getParameter(name));
			sb.append("\n");
			total++;
		}
		sb.append("; total ").append(total).append("parameters.\n");
		if (LOG.isDebugEnabled()) {
			LOG.debug(sb.toString());
		}
		return sb.toString();
	}

	private static void dumpAttrs(HttpServletRequest request, PrintStream out, String prefix) {
		StringBuilder sb = new StringBuilder(128);
		sb.append(new java.sql.Timestamp(System.currentTimeMillis())).append(
				'\t');
		sb.append(request.getRequestURI());
		out.println(sb);
		Map<String, Object> attrs = getAllAttributesByPrefix(request, prefix);
		if (prefix == null) {
			out.println(attrs.size() + " Attributes(all): ");
		} else {
			out.println(attrs.size() + " Attributes(startsWith [" + prefix + "]): ");
		}
		for (String key : attrs.keySet()) {
			out.println(key + "=" + attrs.get(key));
		}
		out.println();
	}

	/**
	 *
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 14, 2010
	 */
	public static boolean isRobotRequest(HttpServletRequest request) {
		String userAgent = getUserAgent(request);
		if (userAgent == null)
			return false;

		userAgent = userAgent.toLowerCase();

		if (userAgent.contains("spider")) {
			return true;
		} else if (userAgent.contains("bot")) {
			return true;
		} else if (userAgent.contains("nutch")) {
			return true;
		} else if (userAgent.contains("yahoo")) {
			return true;
		} else if (userAgent.contains("gougou")) {
			return true;
		} else if (userAgent.contains("scooter")) {
			return true;
		} else if (userAgent.contains("lilina")) {
			return true;
		}

		return false;
	}

	/**
	 * @param request
	 * @return
	 * @since liushen @ Mar 28, 2011
	 */
	public static String getUserAgent(HttpServletRequest request) {
		return request.getHeader(HEADER_USER_AGENT);
	}

	/**
	 * 获取给定的request的客户端IP、encoding信息和全部的Header信息.
	 * 
	 * @since ls@07-0915
	 */
	public static String getClientAndHeaders(HttpServletRequest request) {
		StringBuilder sb = new StringBuilder(256);
	    sb.append("request clientIP=").append(request.getRemoteAddr());
	    sb.append(", encoding=").append(request.getCharacterEncoding());
	    sb.append(". request headers:").append(NEWLINE);
	    String header = null;
		for (Enumeration<?> headers = request.getHeaderNames(); headers
				.hasMoreElements();) {
			header = (String) headers.nextElement();
	        sb.append(header);
	        sb.append('=');
	        sb.append(request.getHeader(header));
	        sb.append(NEWLINE);
	    }
	    return sb.toString();
	}

	/**
	 * 获取给定request的Header中的user-agent头和Cookie信息. <BR>
	 * 主要用于调试等场合.
	 * 
	 * @param req
	 *            给定的request
	 * @return user-agent头和Cookie信息构成的字符串.
	 */
	public static String getUserAgentAndCookies(HttpServletRequest req) {
		StringBuilder sb = new StringBuilder(256);
	    sb.append(HEADER_USER_AGENT).append('=').append(req.getHeader(HEADER_USER_AGENT))
	            .append(';');

	    sb.append("cookies: ");
	    Cookie[] cookies = req.getCookies();
	    if (cookies != null) {
	        for (int i = 0; i < cookies.length; i++) {
	            sb.append(cookies[i].getName()).append('=').append(
	                    cookies[i].getValue());
	            sb.append(';');
	        }
	    }
	    return sb.toString();
	}

	/**
	 * 获取给定的Http请求的Referer URL, 即上一个页面. <BR>
	 * 
	 * @param req
	 *            给定的Http请求
	 * @return 给定Http请求的referer头的值. 如果不存在, 返回""而不是null.
	 */
	public static String getReferUrl(HttpServletRequest req) {
	    String referUrl = req.getHeader(HEADER_REFER);
	    return (referUrl == null) ? "" : referUrl;
	}

	/**
	 * 获取给定字符串在给定请求的URL(相对于该应用)中的位置. <BR>
	 * 对动态页面,等价于<code>req.getServletPath().indexOf(someUri)</code> 例子:
	 * requestURI: /app/login.htm; ctx: /app; uri: /login.htm; return: 0
	 * 
	 * @param req
	 *            给定请求
	 * @param someUri
	 *            给定字符串
	 * @return 给定字符串在请求URL中的位置. 如果给定字符串(someUri)为null或"", 返回-2.
	 */
	    public static int getPageUriPosInRequest(HttpServletRequest req, String someUri) {
	        if (someUri == null || someUri.trim().length() == 0) {
	            return -2;
	        }
	        return getRelativePath(req).indexOf(someUri);
	    }

	/**
	 * for Dynamic Pages, this method as same as
	 * <code>req.getServletPath()</code>, but the method also valid for Static
	 * Content, such as html, gif, css etc.<br>
	 * Example:<br>
	 * if request "http://localhost:8080/app1/dir1/page1.jsp", the method return
	 * "/dir1/page1.jsp".
	 *
	 * @param req
	 *            the spec request
	 * @return the relative url
	 */
	public static String getRelativePath(HttpServletRequest req) {
	    // ls@2005-11-02 req.getRequestURI().substring(req.getContextPath().length()) == req.getServletPath() ? NO! i.e.WebLogic!
	    return req.getRequestURI().substring(req.getContextPath().length());
	}

	/**
	 * @param application
	 * @return ServletContainerInfo
	 */
	public static String getServletContainerInfo(final ServletContext application) {
		StringBuilder sb = new StringBuilder(64);
	    sb.append(application.getServerInfo());
	    sb.append(" (Servlet ").append(application.getMajorVersion())
	            .append('.').append(application.getMinorVersion()).append(')');
	    return sb.toString();
	}

	/**
	 * 获取客户端原始请求的URL(包括QueryString).
	 * 
	 * @creator liushen @ Mar 20, 2009
	 */
	public static String getClientRequestURL(HttpServletRequest request) {
		Object obj = request.getAttribute("javax.servlet.forward.request_uri");
		String uri = (obj instanceof String) ? (String) obj : request
				.getRequestURI();
		String qryStr = request.getQueryString();
		if (LOG.isDebugEnabled()) {
			LOG.debug("uri:" + uri + ",queryString:"
					+ request.getQueryString() + ",qryStr:" + qryStr);
		}
		if (StringHelper.isEmpty(qryStr)) {
			return uri;
		}
		return uri + "?" + qryStr;
	}

	/**
	 * 
	 * @param request
	 * @return
	 * @since liushen @ Feb 3, 2012
	 */
	public static String getCurrentDirWithSlash(HttpServletRequest request) {
		final String relativePath = RequestUtil.getRelativePath(request);
		String result = relativePath.substring(0, relativePath.lastIndexOf('/') + 1);
		return result;
	}

	/**
	 * 可用在动态自适应JSTL Fmt标签的basename等场合。
	 * 
	 * @param request
	 * @return
	 * @since liushen @ Feb 21, 2012
	 */
	public static String getCurrentBasename(HttpServletRequest request) {
		final String relativePath = RequestUtil.getRelativePath(request);
		String result = relativePath.substring(0, relativePath.lastIndexOf('.') + 1);
		return result;
	}

	/**
	 * 是否是一个Forward过来的请求.
	 * 
	 * @since liushen @ Jul 5, 2011
	 */
	public static boolean isForward(HttpServletRequest request) {
		return request.getAttribute("javax.servlet.forward.request_uri") instanceof String;
	}

	/**
	 * 获取所有名为“checkbox”元素的value，其值不要求为整数
	 * 
	 * @param request
	 * @param param
	 * @return 字符串数组形式返回所有名为“checkbox”元素的value，如果没有此元素，返回一个长度为0的字符串数组
	 * @creator changpeng @ 2009-4-10
	 */
	public static String[] getCheckBoxValues(HttpServletRequest request, String param){
		String[] values = request.getParameterValues(param) ;
		if(values == null){
			values = new String[0] ;
		}
		return values ;
	}

	/**
	 * 获取所有名为“checkbox”元素的value，以整数数组表示
	 * 
	 * @param request
	 * @param param
	 * @return
	 * @creator changpeng @ 2009-4-10
	 * @deprecated liushen@Mar 28, 2011: 命名不规范；改用
	 *             {@link #getParameterAsIntArray(HttpServletRequest, String)}
	 */
	@Deprecated
	public static int[] getCheckBoxValuesAsInt(HttpServletRequest request, String param){
		return getParameterAsIntArray(request, param);
	}

	/**
	 * 获取多个值，以int数组的形式保存
	 * @creator changpeng @ 2009-4-14
	 * @deprecated liushen@Mar 28, 2011: 命名不规范；改用
	 *             {@link #getParameterAsIntArray(HttpServletRequest, String)}
	 */
	@Deprecated
	public static int[] getParameterValuesAsInt(HttpServletRequest request, String param){
		return getParameterAsIntArray(request, param);
	}

	/**
	 * 获取当前应用的上下文, 总以<code>/</code>结束.
	 * 
	 * @param request
	 * @return
	 * @creator liushen @ Apr 16, 2009
	 */
	public static final String getContextPathWithSlash(
			HttpServletRequest request) {
		String contextPath = request.getContextPath();
		return StringHelper.smartAppendSlashToEnd(contextPath);
	}

	/**
	 * 
	 * @param request
	 * @return
	 * @since liushen @ Mar 28, 2011
	 */
	public static final String getContextPath(HttpServletRequest request) {
		return request.getContextPath();
	}

	/**
	 * @creator liushen @ Jan 18, 2010
	 * @deprecated liushen@Mar 28, 2011: 命名不确切，改用
	 *             {@link #getContextUrlWithSlash(HttpServletRequest)}
	 */
	@Deprecated
	public static final String getContextRootWithSlash(
			HttpServletRequest request) {
		return getContextUrlWithSlash(request);
	}

	/**
	 * 返回当前请求应用的根URL，总是以<code>/</code>结束，以便和html
	 * head内的&lt;base&gt;标签搭配使用，简化页面链接.
	 * 
	 * @param request
	 *            当前请求
	 * @return 应用的根URL；例: 对于请求
	 *         <code>"http://localhost:8080/app1/dir1/page1.jsp"</code> , 该方法返回
	 *         <code>"http://localhost:8080/app1/"</code> .
	 * @see #getContextUrl(HttpServletRequest)
	 * @since liushen @ Mar 28, 2011
	 */
	public static final String getContextUrlWithSlash(HttpServletRequest request) {
		String contextRoot = getContextUrl(request);
		return StringHelper.smartAppendSlashToEnd(contextRoot);
	}

	/**
	 * 返回应用的根URL，兼容存在Apache mod_proxy反向代理的情况.<br>
	 * @deprecated liushen@Mar 28, 2011: 命名不确切，改用
	 *             {@link #getContextUrl(HttpServletRequest)}
	 */
	@Deprecated
	public static String getContextRoot(HttpServletRequest request) {
		return getContextUrl(request);
	}

	/**
	 * 返回应用的根URL，包含结尾的<code>/</code>。兼容存在Apache
	 * mod_proxy反向代理的情况：首先判断是否有x-forwarded-host头，如有则从中得出原始请求的HOST头，再计算.
	 * (详见http://httpd.apache.org/docs/2.2/mod/mod_proxy.html) <b>例子</b>: if
	 * request "http://localhost:8080/app1/dir1/page1.jsp", the method return
	 * "http://localhost:8080/app1".
	 * 
	 * @since liushen @ Mar 28, 2011
	 */
	public static String getContextUrl(HttpServletRequest request) {
		String xForwardedHost = request.getHeader("X-Forwarded-Host");
		String scheme = request.getScheme();
		String host = StringHelper.isEmpty(xForwardedHost) ? request
				.getHeader("Host") : xForwardedHost;

		return scheme + "://" + host + getContextPathWithSlash(request);
	}

	/**
	 * 获取客户端IP. 在有X-Forwarded-For/X-HOST等头的情况下，则从这些头中提取原始IP地址。
	 * X-Forwarded-For值的例子(注意顺序)： X-Forwarded-For: client1, proxy1, proxy2
	 * 详见http://en.wikipedia.org/wiki/X-Forwarded-For
	 * 
	 * @creator chuchanglin @ 2009-12-11
	 */
	public static final String getClientIP(HttpServletRequest request) {
		String xForwardedFor = request.getHeader("X-Forwarded-For");
		String remoteAddr = request.getRemoteAddr();
		if (xForwardedFor != null && xForwardedFor.length() > 4) {
			int index = xForwardedFor.indexOf(",");
			if (index != -1) {
				remoteAddr = xForwardedFor.substring(0, index);
			} else {
				remoteAddr = xForwardedFor;
			}
		}
		return remoteAddr;
	}

	/**
	 *
	 * @param request
	 * @return
	 * @since liushen @ Feb 28, 2010
	 */
	public static final boolean isMultipartRequest(HttpServletRequest request) {
		// Check the content type to make sure it's "multipart/form-data"
		// Access header two ways to work around WebSphere oddities
		String type = null;
		String type1 = request.getHeader("Content-Type");
		String type2 = request.getContentType();
		// If one value is null, choose the other value
		if (type1 == null && type2 != null) {
			type = type2;
		} else if (type2 == null && type1 != null) {
			type = type1;
		}
		// If neither value is null, choose the longer value
		else if (type1 != null && type2 != null) {
			type = (type1.length() > type2.length() ? type1 : type2);
		}

		if (type == null
				|| !type.toLowerCase().startsWith("multipart/form-data")) {
			return false;
		}

		return true;
	}

	/**
	 * 获取Http请求的对象编号
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public static final int getId(HttpServletRequest request) {
		return getParameterAsInt(request, "id", 0);
	}

	/**
	 * 获取Http请求的页记录数
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public static final int getPageSize(HttpServletRequest request) {
		return getParameterAsInt(request, "ps", 20);
	}

	/**
	 * 获取Http请求的页码数
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 17, 2010
	 */
	public static final int getPageNo(HttpServletRequest request) {
		return getParameterAsInt(request, "pn", 1);
	}

	/**
	 * 获取ID集合列表
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Apr 20, 2010
	 */
	public static final int[] getIds(HttpServletRequest request) {
		String ids = RequestUtil.getParameterAndTrim(request, PARAM_ID_ARRAY);
		return StringHelper.split2IntArray(ids);
	}

	/**
	 * 输出request所有主要内容，包括Headers、Parameters、Cookies
	 * 
	 * @param request
	 * @since fangxiang @ Oct 15, 2010
	 */
	public static final void dump(HttpServletRequest request) {
		if (LOG.isDebugEnabled()) {
			dumpHeaders(request);
			dumpParameters(request);
			dumpCookies(request);
		}
	}

	/**
	 * @param request
	 * @since fangxiang @ Oct 15, 2010
	 */
	private static void dumpCookies(HttpServletRequest request) {
		StringBuilder cookieBuffer = new StringBuilder("Request("
				+ request.getRequestURI() + ") 's cookies:");
		Cookie[] cookies = request.getCookies();
		for (int i = 0; i < cookies.length; i++) {
			cookieBuffer.append(cookies[i].getName()).append("=")
					.append(cookies[i].getValue());
			cookieBuffer.append(",path=").append(cookies[i].getPath())
					.append(",domain=").append(cookies[i].getDomain())
					.append(";");
		}
		cookieBuffer.append("total ").append(cookies.length)
				.append(" cookies.");
		LOG.info(cookieBuffer.toString());
	}

	/**
	 * @param request
	 * @since fangxiang @ Oct 15, 2010
	 */
	private static void dumpHeaders(HttpServletRequest request) {
		StringBuilder headerBuffer = new StringBuilder("Request("
				+ request.getRequestURI() + ") 's headers:");
		Enumeration<?> e = request.getHeaderNames();
		int countHeader = 0;
		for (; e.hasMoreElements();countHeader++) {
			String headerName = (String) e.nextElement();
			headerBuffer.append(headerName).append("=")
					.append(request.getHeader(headerName)).append(";");
		}
		headerBuffer.append("total ").append(countHeader)
				.append(" headers.");
		LOG.info(headerBuffer.toString());
	}

	/**
	 * 获取请求的远程地址
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Nov 24, 2010
	 * @deprecated liushen@Dec 29, 2010: 建议换成
	 *             {@link #getClientIP(HttpServletRequest)}，还能兼容X-Forward等情况
	 */
	@Deprecated
	public static String getRemoteAddr(HttpServletRequest request) {
		return request.getRemoteAddr();
	}

	/**
	 * 获取请求的查询串
	 * 
	 * @param request
	 * @return
	 * @since fangxiang @ Nov 24, 2010
	 */
	public static String getQueryString(HttpServletRequest request) {
		return request.getQueryString();
	}

	/**
	 * 根据x-requested-with头判断是否为AJAX请求；兼容jquery、prototype等常见js框架.
	 * 
	 * @return 如果是Ajax请求，则返回<code>true</code>.
	 * @since liushen @ Dec 29, 2010
	 */
	public static boolean isAjaxRequest(HttpServletRequest request) {
		return "XMLHttpRequest".equals(request.getHeader("x-requested-with"));
	}

	/**
	 * 注意：虽然根据HttpServletRequest可以获取到ServletContext，但这个过程会不必要的创建HttpSession；因此，
	 * 调用本方法时需要提供ServletContext。
	 * 
	 * @param application
	 *            需要这个参数的原因见上面的描述.
	 * @param request
	 * @return
	 * @since liushen @ Mar 3, 2011
	 */
	public static File getRealFile(ServletContext application,
			HttpServletRequest request) {
		String relativeURI = request.getServletPath();
		return getRealFile(application, relativeURI);
	}

	/**
	 * Returns a String containing the real path for a given virtual path. For
	 * example, the path "/index.html" returns the absolute file path on the
	 * server's filesystem would be served by a request for
	 * "http://host/contextPath/index.html", where contextPath is the context
	 * path of this ServletContext.. The real path returned will be in a form
	 * appropriate to the computer and operating system on which the servlet
	 * container is running, including the proper path separators. This method
	 * returns null if the servlet container cannot translate the virtual path
	 * to a real path for any reason (such as when the content is being made
	 * available from a .war archive).
	 * 
	 * @param application
	 * @param relativeURI
	 *            a String specifying a virtual path
	 * @return a File specifying the real path, or null if the translation
	 *         cannot be performed
	 * @since liushen @ Mar 7, 2011
	 */
	public static File getRealFile(ServletContext application,
			String relativeURI) {
		String realPath = application.getRealPath(relativeURI);
		return (realPath == null) ? null : new File(realPath);
	}

	/**
	 * 请求是否来自于苹果iOS设备.
	 * 
	 * @param request
	 * @return
	 * @since liushen @ Jul 11, 2011
	 */
	public static boolean fromIOS(HttpServletRequest request) {
		String userAgent = request.getHeader(HEADER_USER_AGENT);
		return new UserAgent(userAgent).getOperationSystem() == OS.iOS;
	}

	/**
	 * 获取指定request的指定参数的整数值. 如果该参数不存在或者解析整数时发生了异常, 则返回给定的默认值.
	 * 
	 * @param request
	 *            指定request
	 * @param param
	 *            指定参数
	 * @param defaultValue
	 *            给定的默认值.
	 * @return 参数值的整数数组形式. 如果该参数不存在返回int[0]；解析整数时发生了异常, 则设定为默认值.
	 */
	public static int[] getParameterAsIntArray(HttpServletRequest request, String param, int defaultValue) {
		String[] values = request.getParameterValues(param);

		if (values == null) {
			return new int[0];
		}

		int[] ints = new int[values.length];

		for (int i = 0; i < values.length; i++) {
			String value = values[i];

			if (value == null) {
				ints[i] = defaultValue;
				continue;
			}

			value = value.trim();
			if (value.length() == 0) {
				ints[i] = defaultValue;
				continue;
			}

			try {
				ints[i] = Integer.parseInt(value);
			} catch (Exception e) {
				LOG.warn("err=" + e + "! param=" + param + ", value=" + value + "! return " + defaultValue);
				ints[i] = defaultValue;
			}

		}

		return ints;
	}

	/**
	 * 
	 * @param request
	 * @return
	 */
	public static String getRequestRealIP(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("clientip-idsknown");
		}

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		int pos = ip.indexOf(",");
		int startPos = 0;

		while (pos > 0) {
			String ip1 = ip.substring(startPos, pos).trim();

			if (ip1.length() > 0 && !"unknown".equalsIgnoreCase(ip1)) {
				return ip1;
			}

			startPos = pos + 1;
			pos = ip.indexOf(",", startPos);
		}

		return ip;
	}

	/**
	 * 获取指定request的指定参数的字符串值. 对表单中的中文字符串进行处理(原串采用ISO-8859-1字符集编码,
	 * 获得的字符串采用GBK编码).
	 * 
	 * @param req
	 *            指定request
	 * @param param
	 *            指定参数
	 * @return 如果不存在该参数, 返回空串而不是null.
	 */
	public static String getParameterAsGBK(HttpServletRequest req, String param) {
		return getParamByEncoding(req, param, "ISO-8859-1", "GBK");
	}

	/**
	 * 获取指定request的指定参数的字符串值. 对表单中的中文字符串进行处理: 原串采用给定的字符集编码, 获得的字符串采用GBK字符集编码.
	 * 
	 * @param req
	 *            指定的request
	 * @param param
	 *            指定的参数
	 * @param originEncoding
	 *            给定的字符集
	 * @return 如果不存在该参数, 返回空串而不是null.
	 */
	public static String getParameterAsGBK(HttpServletRequest req, String param, String originEncoding) {
		return getParamByEncoding(req, param, originEncoding, "GBK");
	}

	/**
	 * 
	 * @param req
	 * @param attrName
	 * @param defValue
	 * @return
	 */
	public static int getAttributeAsInt(HttpServletRequest req, String attrName, int defValue) {
		Object obj = req.getAttribute(attrName);
		return (obj instanceof Integer) ? ((Integer) obj).intValue() : defValue;
	}

	/**
	 * 检验是否存在指定的参数项.
	 * 
	 * @param req
	 *            指定的request(Http请求)
	 * @param param
	 *            指定的参数项
	 * @return 存在返回true, 否则返回false
	 */
	public static boolean existParameter(HttpServletRequest req, String param) {
		if (param == null) {
			return false;
		}
		return req.getParameter(param) != null;
	}

	/**
	 * 
	 * @param req
	 * @return
	 * @since fangxiang @ 2011-9-13 , From com.trs.common.util.RequestUtil
	 */
	public static String getCurPageWithQryStr(HttpServletRequest req) {
		return getCurPageWithQryStr(req, null);
	}

	/**
	 * 
	 * @param req
	 * @param param
	 * @return
	 * @since fangxiang @ 2011-9-13 , From com.trs.common.util.RequestUtil
	 */
	public static String getCurPageWithQryStr(HttpServletRequest req, String param) {
		String qryStr = removeQryParam(req.getQueryString(), param);
		if (qryStr == null) {
			return getCurrentPage(req);
		}
		return new StringBuilder(getCurrentPage(req)).append('?').append(qryStr).toString();
	}

	/**
	 * 
	 * @param qryStr
	 * @param param
	 * @return
	 * @since fangxiang @ 2011-09-13 , From com.trs.common.util.RequestUtil
	 */
	public static String removeQryParam(String qryStr, String param) {
		if (qryStr == null || param == null) {
			return qryStr;
		}
		String[] params = qryStr.split("&");
		StringBuilder sb = new StringBuilder(qryStr.length());
		for (int i = 0; i < params.length; i++) {
			if (params[i].startsWith(param + "=")) {
				continue;
			}
			sb.append(params[i]).append('&');
		}
		return (sb.length() > 0) ? sb.deleteCharAt(sb.length() - 1).toString() : null;
	}

	/**
	 * 
	 * @param req
	 * @return
	 * @since fangxiang @ 2011-9-13 , From com.trs.common.util.RequestUtil
	 */
	public static String getRequestBrief(HttpServletRequest req) {
		StringBuilder sb = new StringBuilder(320);
		sb.append("[Req]");
		sb.append(req.getMethod()).append(' ');
		sb.append(req.getRequestURI());
		return sb.toString();
	}

	/**
	 * 获取指定request的完整URL请求, 包括全部参数项和值(GET方式和POST方式都适用). 该方法会影响request中的编码.
	 * 
	 * @param rq
	 *            指定的request
	 * @return 表示URL请求的字符串, 包括完整URL和提交的全部参数项和值
	 * @see #getParamString(HttpServletRequest)
	 */
	public static String getFullRequestStr(HttpServletRequest rq) {
		return new StringBuilder(256).append(rq.getRequestURL()).append(getParamString(rq)).toString();
	}

	/**
	 * 获取指定request的全部参数项和值. 该方法会影响request中的编码.
	 * 
	 * @param rq
	 *            指定的request
	 * @return 全部参数项和值构成的字符串
	 */
	@SuppressWarnings("unchecked")
	public static String getParamString(HttpServletRequest rq) {
		StringBuilder sb = new StringBuilder(256);
		int i = 0;
		for (Enumeration<String> params = rq.getParameterNames(); params.hasMoreElements();) {
			String param = params.nextElement();
			sb.append((++i) == 1 ? "?" : "&").append(param).append("=").append(rq.getParameter(param));
		}
		return sb.toString();
	}

	/**
	 * 获取指定request的指定参数的指定编码字符串值. <BR>
	 * <BR>
	 * 提供给子类使用的工具方法.
	 * 
	 * @param req
	 *            给定Http请求对象
	 * @param param
	 *            指定参数
	 * @param originEncoding
	 *            参数值的原始编码
	 * @param toEncoding
	 *            解析参数值的指定编码
	 * @return 给定参数的取值, 如果为null则返回"".
	 */
	public static String getParamByEncoding(HttpServletRequest req, String param, String originEncoding, String toEncoding) {
		if (param == null) {
			return "";
		}
		String result = req.getParameter(param);
		try {
			return (result == null) ? "" : new String(result.getBytes(originEncoding), toEncoding);
		} catch (UnsupportedEncodingException e) {
			LOG.error("unspport encoding! origin=" + originEncoding + ", to=" + toEncoding, e);
		}
		return "";
	}

	/**
	 * 
	 * @param req
	 * @return
	 * @since fangxiang @ 2011-9-13 , From com.trs.common.util.RequestUtil
	 */
	public static String getRelativePathWithQryStr(HttpServletRequest req) {
		final String qryStr = req.getQueryString();
		final String relativePath = getRelativePath(req);
		if (qryStr == null) {
			return relativePath;
		} else {
			return new StringBuilder(relativePath.length() + qryStr.length() + 1).append(relativePath).append('?').append(qryStr).toString();
		}
	}

	/**
	 * simple log method for jsp page.
	 * 
	 * @param obj
	 * @param req
	 * 
	 * @since fangxiang @ 2011-09-13 , From com.trs.common.util.RequestUtil
	 */
	public static void log(Object obj, HttpServletRequest req) {
		StringBuilder sb = new StringBuilder(256);
		sb.append(new java.sql.Timestamp(System.currentTimeMillis()));
		if (req != null) {
			sb.append('\t').append(req.getRequestURI());
		}
		sb.append('\t').append(obj);
		System.out.println(sb);
	}

	/**
	 * simple log method for jsp page.
	 * 
	 * @param req
	 * @since fangxiang @ 2011-09-13 , From com.trs.common.util.RequestUtil
	 */
	public static void log(HttpServletRequest req) {
		log(getRequestInfo(req), null);
	}

	/**
	 * 服务端转发，核心动作是
	 * <code>request.getRequestDispatcher(uri).forward(request, response)</code>
	 * ，该工具方法主要封装了对于null的判断和明确的异常信息.
	 * 
	 * @throws ServletException
	 *             if the target resource throws this exception
	 * @throws IOException
	 *             if the target resource throws this exception
	 * @see javax.servlet.ServletRequest.getRequestDispatcher(java.lang.String)
	 * @see 
	 *      javax.servlet.RequestDispatcher.forward(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse)
	 * @since liushen @ Dec 9, 2011
	 */
	public static void forward(HttpServletRequest request,
			HttpServletResponse response, String uri) throws ServletException,
			IOException {
		RequestDispatcher rd = request.getRequestDispatcher(uri);
		if (rd != null) {
			rd.forward(request, response);
			return;
		}
		throw new ServletException("the RequestDispatcher is null: [" + uri
				+ "]!");
	}

}