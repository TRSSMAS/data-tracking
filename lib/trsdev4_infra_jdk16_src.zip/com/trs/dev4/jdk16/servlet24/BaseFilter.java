/*
 * Created: liushen@Jul 3, 2011 3:23:21 AM
 */
package com.trs.dev4.jdk16.servlet24;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;

/**
 * MAS应用中，Servlet Filter的基类；封装了对由 {@link com.trs.mam.view.servlet.DBSetupper}
 * 触发Spring启动情况下的生命周期支持. <br>
 * 
 * @author TRS信息技术股份有限公司
 */
public abstract class BaseFilter implements Filter {

	private static final Logger LOG = Logger.getLogger(BaseFilter.class);

	protected FilterConfig filterConfig;

	private boolean initSucceed;

	/**
	 * @param sreq
	 * @param sresp
	 * @param chain
	 * @since liushen @ Jul 3, 2011
	 */
	protected abstract void doFilterInternal(ServletRequest sreq,
			ServletResponse sresp, FilterChain chain) throws IOException,
			ServletException;

	// TODO: liushen@Feb 2, 2012:
	// 返回值应为void更合理，参见MAS的com.trs.mam.view.filter.BaseFilter(该类将合并进来)；改为boolean的缘由找于洪奇
	/**
	 * @param config
	 * @since liushen @ Jul 3, 2011
	 */
	protected abstract boolean initInternal(FilterConfig config)
			throws ServletException;

	/**
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 * @since liushen @ Jul 3, 2011
	 */
	@Override
	public final void doFilter(ServletRequest sreq, ServletResponse sresp,
			FilterChain chain) throws IOException, ServletException {
		if (false == initSucceed) {
			initSucceed = initInternal(filterConfig);
			LOG.info("init(Internal) [" + filterConfig.getFilterName()
					+ "] OK.");
		}
		doFilterInternal(sreq, sresp, chain);
	}

	/**
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 * @since liushen @ Jul 3, 2011
	 */
	@Override
	public final void init(FilterConfig config) {
		LOG.info("init [" + config.getFilterName() + "] ...");
		this.filterConfig = config;
		try {
			initSucceed = initInternal(config);
			LOG.info("init [" + filterConfig.getFilterName() + "] OK.");
		} catch (Throwable e) {
			LOG.warn("init [" + filterConfig.getFilterName() + "] failed.", e);
		}
	}

	/**
	 * @see javax.servlet.Filter#destroy()
	 * @since liushen @ Jul 3, 2011
	 */
	@Override
	public final void destroy() {
		try {
			destroyInternal();
		} catch (Throwable e) {
			LOG.warn("fail to destroy filter " + filterConfig.getFilterName(),
					e);
		} finally {
			filterConfig = null;
			initSucceed = false;
		}
	}

	/**
	 * 
	 * @since liushen @ Jul 3, 2011
	 */
	protected abstract void destroyInternal();

}
