/*
 * Created: liushen@Feb 26, 2011 5:17:01 PM
 */
package com.trs.dev4.jdk16.servlet24;

/**
 * 从HTTP UserAgent头中提取客户端浏览器、操作系统、设备等信息的工具类. <br>
 * Resources:<br>
 * Have a look at RFC 1945 and RFC 2068 for the User agent string syntax. (http://www.faqs.org/rfcs/rfc2068.html, 14.42 User-Agent)
 * <a href="http://www.useragentstring.com">User Agent String.Com</a><br>
 * <a href="http://www.user-agents.org">List of User-Agents</a><br>
 * <a href="http://www.zytrax.com/tech/web/browser_ids.htm">Browser ID (User-Agent) Strings</a><br>
 * <a href="http://www.zytrax.com/tech/web/mobile_ids.html">Mobile Browser ID (User-Agent) Strings</a><br>
 * <a href="http://www.joergkrusesweb.de/internet/browser/user-agent.html">Browser-Kennungen</a><br>
 * <a href="http://deviceatlas.com/devices">Device Atlas - Mobile Device Intelligence</a><br>
 * <a href="http://mobileopera.com/reference/ua">Mobile Opera user-agent strings</a><br>
 * <a href="http://en.wikipedia.org/wiki/S60_platform">S60 platform</a><br>
 * <a href="http://msdn.microsoft.com/en-us/library/ms537503.aspx">Understanding User-Agent Strings</a><br>
 * <a href="http://developer.sonyericsson.com/site/global/docstools/browsing/p_browsing.jsp">Sony Ericsson Web Docs & Tools</a><br>
 * <a href="http://developer.apple.com/internet/safari/faq.html#anchor2">What is the Safari user-agent string</a><br>
 * <a href="http://www.pgts.com.au/pgtsj/pgtsj0208c.html">List of User Agent Strings</a><br>
 * <a href="http://blogs.msdn.com/iemobile/archive/2006/08/03/Detecting_IE_Mobile.aspx">Detecting Internet Explorer Mobile's User-Agent on the server</a>
 */
public class UserAgent {

	private Device device;

	private Browser browser;

	private OS os;

	/**
	 * 
	 */
	public UserAgent(String strUserAgent) {
		if (strUserAgent.indexOf("(iPad;") > 0) {
			device = Device.iPad;
			os = OS.iOS;
		} else if (strUserAgent.indexOf("(iPod;") > 0) {
			device = Device.iTouch;
			os = OS.iOS;
		} else if (strUserAgent.indexOf("(iPhone;") > 0) {
			device = Device.iPhone;
			os = OS.iOS;
		}
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Feb 26, 2011
	 */
	public Browser getBrowser() {
		return browser;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Jul 11, 2011
	 */
	public OS getOperationSystem() {
		return os;
	}

	/**
	 * 
	 * @return
	 * @since liushen @ Jul 5, 2011
	 */
	public Device getDevice() {
		return device;
	}

	public static enum Browser {
		IE, FF, Chrome, Safari, Opera;
	}

	public static enum Device {
		iPad, iPhone, iTouch, OTHER, MAC;
	}

	public static enum OS {
		iOS, Android, S60, WM, PC, MAC;
	}

}
